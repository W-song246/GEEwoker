"""安装时生成服务器私有配置和登录信息；文件不会上传到 GitHub。"""

import json
import os
import secrets
import tempfile
from pathlib import Path

from dotenv import dotenv_values


def private_write(path, content):
    descriptor, temporary = tempfile.mkstemp(prefix=".private_", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as file:
            file.write(content)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def configure(folder):
    folder = Path(folder)
    path = folder / "platform.env"
    config = dict(dotenv_values(path)) if path.exists() else {}
    config.setdefault("GEE_WORKER_URL", "https://geewoker.onrender.com")
    config.setdefault("WORKER_TOKEN", "")
    bootstrap = os.getenv("BOOTSTRAP_WORKER_TOKEN", "").strip()
    if bootstrap and not config.get("WORKER_TOKEN"):
        config["WORKER_TOKEN"] = bootstrap
    config.setdefault("ZHIPU_API_KEY", "")
    config.setdefault("ZHIPU_MODEL", "glm-4-flash")
    config["PLATFORM_USERNAME"] = config.get("PLATFORM_USERNAME") or "admin"
    config["PLATFORM_PASSWORD"] = config.get("PLATFORM_PASSWORD") or secrets.token_urlsafe(18)
    config["PORT"] = "7860"
    config["GRADIO_ANALYTICS_ENABLED"] = "False"
    private_write(path, "".join(f"{key}={json.dumps(value or '', ensure_ascii=False)}\n"
                                for key, value in config.items()))
    private_write(folder / "登录信息.txt",
                  "平台地址：http://121.5.5.98\n"
                  f"账号：{config['PLATFORM_USERNAME']}\n密码：{config['PLATFORM_PASSWORD']}\n\n"
                  "请自己保存登录信息，不用截图或发给其他人。\n"
                  "连接口令和智谱密钥保存在同目录的 platform.env 文件中。\n")
    print("登录账号已生成。请在文件管理器中打开 登录信息.txt 查看，密码不会打印到终端。")
    print("取数口令：" + ("已保存，等待实际查询验证。" if config.get("WORKER_TOKEN")
                            else "尚未填写，请稍后编辑 platform.env 的 WORKER_TOKEN。"))
    return config


if __name__ == "__main__":
    configure(Path(__file__).resolve().parent)
