"""国内服务器上的 Gradio 界面；GEE 计算由已经部署好的取数服务完成。"""

import base64
import calendar
import csv
import json
import os
import re
import shutil
import tempfile
import time
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / "platform.env")
os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")
os.environ.setdefault("MPLBACKEND", "Agg")

import gradio as gr
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import requests

WORKER_URL = os.getenv("GEE_WORKER_URL", "https://geewoker.onrender.com").rstrip("/")
WORKER_TOKEN = os.getenv("WORKER_TOKEN", "").strip()
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", str(BASE_DIR / "data"))).resolve()
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
COORDS = {
    "合肥": (117.22, 31.82, "Hefei"), "北京": (116.40, 39.90, "Beijing"),
    "上海": (121.47, 31.23, "Shanghai"), "广州": (113.26, 23.13, "Guangzhou"),
    "深圳": (114.05, 22.55, "Shenzhen"), "武汉": (114.30, 30.60, "Wuhan"),
    "成都": (104.06, 30.67, "Chengdu"), "南京": (118.79, 32.06, "Nanjing"),
    "杭州": (120.15, 30.28, "Hangzhou"), "西安": (108.94, 34.34, "Xian"),
    "重庆": (106.55, 29.56, "Chongqing"), "哈尔滨": (126.63, 45.75, "Harbin"),
    "三亚": (109.51, 18.25, "Sanya"), "乌鲁木齐": (87.68, 43.77, "Urumqi"),
    "拉萨": (91.11, 29.65, "Lhasa"),
}


def 提示(文字, 状态):
    return 文字, None, gr.update(interactive=False), gr.update(visible=False), 状态


def 解析输入(文字, 状态):
    """常规年月直接解析；设置智谱密钥后也可辅助理解城市和年份。"""
    city = next((name for name, value in COORDS.items()
                 if name in 文字 or re.search(rf"\b{value[2]}\b", 文字, re.I)), None)
    match = re.search(r"(?<!\d)(20\d{2})(?!\d)", 文字)
    year = int(match.group(1)) if match else None
    match = re.search(r"(?<!\d)(\d{1,2})\s*月", 文字)
    if match is None:
        match = re.search(r"20\d{2}[-/](\d{1,2})(?!\d)", 文字)
    month = int(match.group(1)) if match else None
    months = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
              "七": 7, "八": 8, "九": 9, "十": 10, "十一": 11, "十二": 12}
    if month is None:
        match = re.search(r"(十二|十一|十|[一二三四五六七八九])月", 文字)
        if match:
            month = months[match.group(1)]
    if month is None:
        for number in range(1, 13):
            if re.search(rf"\b({calendar.month_name[number]}|{calendar.month_abbr[number]})\b", 文字, re.I):
                month = number
                break
    now = datetime.now(ZoneInfo("Asia/Shanghai"))
    if "本月" in 文字 or "这个月" in 文字:
        month, year = now.month, year or now.year
    api_key = os.getenv("ZHIPU_API_KEY", "").strip()
    if api_key and city is None:
        try:
            from zhipuai import ZhipuAI
            response = ZhipuAI(api_key=api_key, timeout=45, max_retries=1).chat.completions.create(
                model=os.getenv("ZHIPU_MODEL", "glm-4-flash"), temperature=0.1,
                messages=[{"role": "user", "content":
                    "提取中文城市、年份。未明确说出的字段填null。只输出JSON，"
                    '格式为{"city":"北京","year":2026}。\n用户说：' + 文字}],
            )
            raw = response.choices[0].message.content.strip().replace("```json", "").replace("```", "")
            result = json.loads(raw)
            city = (result.get("city") or "").replace("市", "") or None
            year = year or (int(result["year"]) if result.get("year") else None)
        except Exception as error:
            print("智谱辅助解析未完成：", type(error).__name__, flush=True)
    return city or 状态.get("city"), year or 状态.get("year") or now.year, month


@lru_cache(maxsize=16)
def 取得数据(lon, lat, year, month, 缓存时段):
    if not WORKER_TOKEN:
        raise RuntimeError("尚未配置取数服务口令，请管理员填写平台连接配置。")
    try:
        response = requests.post(
            WORKER_URL + "/temperature", headers={"Authorization": "Bearer " + WORKER_TOKEN},
            json={"longitude": lon, "latitude": lat, "year": year, "month": month,
                  "include_map": True}, timeout=(15, 240))
    except requests.Timeout:
        raise RuntimeError("取数等待超时。免费取数服务首次唤醒较慢，请稍后再试。") from None
    except requests.RequestException:
        raise RuntimeError("暂时无法连接取数服务，请稍后再试。") from None
    if response.status_code == 401:
        raise RuntimeError("取数口令验证失败，请管理员检查 WORKER_TOKEN。")
    if response.status_code == 429:
        raise RuntimeError("取数服务正在处理其他查询，请稍后再试。")
    if response.status_code != 200:
        raise RuntimeError("取数服务尚未完成请求，请稍后重试；管理员可在 Render 查看日志。")
    data = response.json()
    if data.get("dataset") != "MODIS/061/MOD11A1":
        raise RuntimeError("取数结果的数据集标识异常，请管理员检查服务。")
    return data


def 清理旧文件():
    for folder in OUTPUT_DIR.glob("temperature_*"):
        if folder.is_dir() and not folder.is_symlink() and folder.stat().st_mtime < time.time() - 3 * 86400:
            shutil.rmtree(folder)


def 温度文字(value):
    return "缺测" if value is None else f"{value:.2f}℃"


def 查询温度(文字, 状态):
    状态 = 状态 or {}
    文字 = (文字 or "").strip()
    if not 文字:
        return 提示("请输入城市和月份，例如：北京2026年9月的温度。", 状态)
    if 文字.lower() in ("是", "对", "yes", "ok") and 状态.get("建议月份"):
        city, year, month = 状态["city"], 状态["year"], 状态["建议月份"]
    elif 文字.lower() in ("不是", "不对", "no") and 状态.get("建议月份"):
        return 提示("好的，请告诉我你要查询几月。", 状态)
    else:
        city, year, month = 解析输入(文字, 状态)
    now = datetime.now(ZoneInfo("Asia/Shanghai"))
    if not city:
        return 提示("你想查询哪个城市的温度？", 状态)
    if city not in COORDS:
        return 提示("目前支持的城市：" + "、".join(COORDS), 状态)
    if month is None:
        return 提示(f"你是要查询{city}{year}年{now.month}月的温度吗？也可以直接说“9月”。",
                    {"city": city, "year": year, "建议月份": now.month})
    if not 2000 <= year <= now.year or not 1 <= month <= 12:
        return 提示("请输入2000年以后的有效年份，月份为1到12月。", 状态)
    if (year, month) > (now.year, now.month):
        return 提示("这个月份还没有到，暂时不能查询。", 状态)
    状态 = {"city": city, "year": year}
    lon, lat, english_city = COORDS[city]
    data = 取得数据(lon, lat, year, month, int(time.time() // 900))
    if data.get("status") == "no_images":
        return 提示(f"{city}{year}年{month}月没有查询到影像记录。", 状态)
    stats = data["statistics"]
    text = (f"{city}{year}年{month}月白天地表温度\n"
            f"中心50公里平均：{温度文字(stats.get('center_mean'))}\n"
            f"中心50公里空间最高／最低：{温度文字(stats.get('center_max'))}／{温度文字(stats.get('center_min'))}\n"
            f"外围50至100公里平均：{温度文字(stats.get('outer_mean'))}\n"
            f"中心与外围温差：{温度文字(stats.get('difference'))}\n"
            "注：这是卫星地表温度；中心／外围按距离划分。保留原始有效像元，未附加严格QC筛选。\n"
            "空值显示为缺测，折线保留缺口；无影像记录与未来日期另行标注。")
    if (year, month) == (now.year, now.month):
        text += "\n本月尚未结束，只统计目前已发布的影像。"
    清理旧文件()
    folder = Path(tempfile.mkdtemp(prefix="temperature_", dir=OUTPUT_DIR))
    statuses = {"available": "有有效数据", "missing_pixels": "部分区域无有效像元",
                "no_image": "无影像记录", "future": "日期未到"}
    rows = []
    daily = data.get("daily", [])
    for item in daily:
        def cell(value):
            if item.get("status") == "future":
                return "日期未到"
            return "缺测" if value is None else f"{value:.2f}"
        rows.append([item["date"], cell(item.get("center")), cell(item.get("outer")),
                     statuses.get(item.get("status"), "待核对")])
    csv_path = folder / "daily.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["日期", "中心50公里均温℃", "外围50至100公里均温℃", "数据状态"])
        writer.writerows(rows)
    fig, ax = plt.subplots(figsize=(8, 4))
    dates = [item["date"] for item in daily]
    ax.plot(dates, [item.get("center") for item in daily], marker="o", label="Center 0-50 km")
    ax.plot(dates, [item.get("outer") for item in daily], marker="o", label="Outer 50-100 km")
    ax.set(title=f"{english_city} {year}-{month:02d} Daily LST", ylabel="Daytime land surface temperature (C)")
    ax.set_xticks(dates[::max(1, len(dates) // 6)])
    ax.tick_params(axis="x", labelrotation=45)
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    line_path = folder / "daily_line.png"
    fig.savefig(line_path, dpi=140)
    plt.close(fig)
    map_path = None
    encoded = data.get("map_png_base64")
    if encoded:
        content = base64.b64decode(encoded, validate=True)
        if len(content) > 4 * 1024 * 1024 or not content.startswith(b"\x89PNG\r\n\x1a\n"):
            raise RuntimeError("温度图像格式异常，请稍后重试。")
        map_path = folder / "temperature_map.png"
        map_path.write_bytes(content)
    else:
        text += "\n数值已取回，本次温度图暂未生成。"
    状态.update(rows=rows, csv=str(csv_path), line=str(line_path), png=str(map_path) if map_path else None)
    return text, 状态["png"], gr.update(interactive=True), gr.update(visible=False), 状态


def 查温度(文字, 状态):
    try:
        return 查询温度(文字, 状态)
    except RuntimeError as error:
        return 提示(str(error), 状态 or {})
    except Exception as error:
        print("查询未完成：", type(error).__name__, flush=True)
        return 提示("本次查询未完成，请稍后重试。", 状态 or {})


def 查看本月数据(状态):
    if not 状态 or not 状态.get("rows"):
        return gr.update(visible=False), [], None, None, None, None
    return (gr.update(visible=True), 状态["rows"], 状态["line"], 状态["csv"], 状态["png"], 状态["line"])


with gr.Blocks(title="温度查询系统", analytics_enabled=False, delete_cache=(86400, 259200)) as iface:
    gr.Markdown("# 温度查询系统")
    gr.Markdown("可输入：北京2026年9月的温度／合肥2025年7月的温度／Beijing temperature in September 2026")
    状态框 = gr.State({})
    问题框 = gr.Textbox(label="输入问题")
    查询按钮 = gr.Button("查询")
    with gr.Row():
        with gr.Column(scale=3):
            地图 = gr.Image(label="温度影像图", interactive=False)
        with gr.Column(scale=2):
            结果框 = gr.Textbox(label="结果与提示", lines=10)
            数据按钮 = gr.Button("查看本月逐日数据和下载", interactive=False)
            with gr.Column(visible=False) as 数据区:
                折线图 = gr.Image(label="日期与温度折线图", interactive=False)
                表格 = gr.Dataframe(headers=["日期", "中心50公里均温℃", "外围50至100公里均温℃", "数据状态"],
                                  datatype=["str", "str", "str", "str"], interactive=False,
                                  label="本月逐日温度数据")
                下载CSV = gr.DownloadButton(label="下载逐日温度数据 CSV")
                下载PNG = gr.DownloadButton(label="下载温度图 PNG")
                下载折线图 = gr.DownloadButton(label="下载折线图 PNG")
    查询输出 = [结果框, 地图, 数据按钮, 数据区, 状态框]
    查询按钮.click(查温度, inputs=[问题框, 状态框], outputs=查询输出)
    问题框.submit(查温度, inputs=[问题框, 状态框], outputs=查询输出)
    数据按钮.click(查看本月数据, inputs=状态框,
                 outputs=[数据区, 表格, 折线图, 下载CSV, 下载PNG, 下载折线图])


if __name__ == "__main__":
    username = os.getenv("PLATFORM_USERNAME", "").strip()
    password = os.getenv("PLATFORM_PASSWORD", "")
    if not username or not password:
        raise RuntimeError("请先设置平台登录账号 PLATFORM_USERNAME 和 PLATFORM_PASSWORD。")
    iface.queue(default_concurrency_limit=1, max_size=12)
    iface.launch(server_name=os.getenv("BIND_HOST", "127.0.0.1"), server_port=int(os.getenv("PORT", "7860")),
                 auth=(username, password), share=False, debug=False,
                 allowed_paths=[str(OUTPUT_DIR)],
                 blocked_paths=[str(BASE_DIR / "platform.env"), str(BASE_DIR / "登录信息.txt")],
                 theme=gr.themes.Default(font=["Arial", "sans-serif"], font_mono=["Consolas", "monospace"]))
