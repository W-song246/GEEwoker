"""浏览器不接触Worker口令；演示后端必须显式开启，生产异常不会回退模拟。"""
import base64
import hashlib
import io
import math
import random
import time
import threading
from datetime import date, timedelta

import requests
from PIL import Image

SCHEMA = "temperature-explorer-v1"
DATASET = "MODIS/061/MOD11A1"
PALETTE = ["173f96", "53b8e8", "9fe3cb", "ffe68a", "ef754e", "bb2847"]


class RemoteWorker:
    mode = "live"
    def __init__(self, url, token):
        self.url, self.token = url.rstrip("/"), token.strip()
        self._lock=threading.Lock()

    def request(self, operation, query):
        with self._lock:return self._request(operation,query)

    def _request(self,operation,query):
        if not self.token:
            raise ValueError("尚未找到原Worker配置。请沿用旧网页的server.env配置后启动新版。")
        for attempt in range(3):
            try:
                response = requests.post(self.url + "/research2/explorer/" + operation, json=query,
                                         headers={"Authorization":"Bearer " + self.token}, timeout=(15,240))
            except requests.RequestException:
                raise ValueError("暂时无法连接取数服务，已显示的结果保留，请稍后重试。") from None
            if response.status_code == 429 and attempt < 2:
                time.sleep(2 + attempt*2)
                continue
            if response.status_code == 404:
                raise ValueError("远端尚未安装新版双击查询接口，请先更新Render取数服务；旧网页仍可使用。")
            if response.status_code in (401,403):
                raise ValueError("Worker配置未通过验证，请核对沿用的server.env。")
            if response.status_code == 422:
                detail = response.json().get("detail")
                raise ValueError(detail if isinstance(detail,str) else "查询条件未通过远端校验。")
            if response.status_code != 200:
                raise ValueError(f"卫星取数暂未完成（HTTP {response.status_code}），请稍后重试。")
            data = response.json()
            keys = ("city","district","start","end") + (("longitude","latitude","radius_m") if operation=="point" else ())
            if (data.get("schema") != SCHEMA or data.get("dataset") != DATASET or
                    data.get("operation") != operation or any(data.get(k) != query.get(k) for k in keys)):
                raise ValueError("远端结果与当前地点、时间或接口版本不一致，已停止展示。")
            data["source_mode"] = "live"
            return data
        raise ValueError("取数服务繁忙，请稍后重试。")

    def region(self, query):
        return self.request("region",query)

    def point(self, query):
        return self.request("point",query)

    def history(self, query):
        return self.request('history',query)['history']


def demo_stats(values, total):
    return {"mean":sum(values)/len(values) if values else None,
            "min":min(values) if values else None,"max":max(values) if values else None,
            "count":len(values),"coverage":round(len(values)/total*100,1) if total else 0}


def demo_png(values, side=24):
    image = Image.new("RGBA",(side,side),(0,0,0,0))
    colors=[tuple(bytes.fromhex(c)) for c in PALETTE]
    for i,value in enumerate(values[:side*side]):
        if value is None: continue
        t=max(0,min(4.999,(value+20)/70*5)); k=int(t); f=t-k
        color=tuple(round(colors[k][j]*(1-f)+colors[k+1][j]*f) for j in range(3))
        image.putpixel((i%side,i//side),(*color,255))
    output=io.BytesIO()
    image.resize((480,480),Image.Resampling.NEAREST).save(output,format="PNG")
    return base64.b64encode(output.getvalue()).decode()


class DemoWorker:
    mode = "demo"
    def region(self, query):
        seed=int(hashlib.sha256(str(sorted(query.items())).encode()).hexdigest()[:8],16)
        rng=random.Random(seed)
        mean=24+int(query["start"][5:7])*0.4+rng.uniform(-2,2)
        samples=[rng.gauss(mean,2.5) for _ in range(500)]
        first,last=date.fromisoformat(query["start"]),date.fromisoformat(query["end"])
        daily=[]
        for i in range((last-first).days+1):
            day=(first+timedelta(days=i)).isoformat()
            vals=[] if i%5==2 else [rng.gauss(mean+2*math.sin(i/6),2.5) for _ in range(450)]
            daily.append({"date":day,**demo_stats(vals,576)})
        shift=0.12 if query.get("district")=="包河区" else 0
        bounds=[[31.76,117.08+shift],[31.96,117.30+shift]]
        s,w=bounds[0];n,e=bounds[1]
        feature={"type":"Feature","properties":{"name":query["city"]+(query.get("district") or "")},
                 "geometry":{"type":"Polygon","coordinates":[[[w,s],[e,s],[e,n],[w,n],[w,s]]]}}
        return {"schema":SCHEMA,"dataset":DATASET,"operation":"region",**query,"source_mode":"demo",
                "summary":demo_stats(samples,576),"daily":daily,"samples":samples,"sample_count":len(samples),
                "sample_limit":3000,"sample_basis":"演示合成像元，非真实卫星观测", "total":576,
                "feature":feature,"boundary_file":"演示矩形边界（不代表真实行政边界）", "image_count":len(daily),
                "bounds":bounds,"map_png_base64":demo_png(samples+[None]*76),
                "quality":"演示合成数据，未进行真实卫星质量筛选"}

    def point(self, query):
        base=self.region({k:query.get(k) for k in ("city","district","start","end")})
        lat,lon=query["latitude"],query["longitude"]
        half=0.0045; step=0.009
        center_lon=math.floor(lon/step)*step+half;center_lat=math.floor(lat/step)*step+half
        ring=[[center_lon-half,center_lat-half],[center_lon+half,center_lat-half],
              [center_lon+half,center_lat+half],[center_lon-half,center_lat+half],[center_lon-half,center_lat-half]]
        value=round(24+4*math.sin(lon*10)+2*math.cos(lat*10),3)
        local=[value-1,value,value+1,value+0.3]
        base["samples"]=local;base["sample_count"]=len(local);base["total"]=5
        base["summary"]=demo_stats(local,5)
        base["bounds"]=[[lat-0.01,lon-0.012],[lat+0.01,lon+0.012]]
        base["map_png_base64"]=demo_png([local[(i//12)%4] if 4<i%24<20 else None for i in range(576)])
        return {"schema":SCHEMA,"dataset":DATASET,"operation":"point",**query,"source_mode":"demo",
                "point":{"value":value,"pixel_geometry":{"type":"Polygon","coordinates":[ring]},
                         "daily":[{"date":r["date"],"value":None if r["mean"] is None else value+math.sin(i/5)}
                                  for i,r in enumerate(base["daily"])],"statistic":"演示示意网格，非真实MODIS像元边框"},
                "neighborhood":base}

    def history(self,query):
        year=int(query["start"][:4])
        return [{"year":y,"mean":None if y==year-3 else 25+math.sin(y),"coverage":80,"count":500}
                for y in range(year-9,year+1)]
