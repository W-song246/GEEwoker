"""浏览器不接触Worker口令；演示后端必须显式开启，生产异常不会回退模拟。"""
import base64
import hashlib
import io
import math
import random
import time
import threading
from datetime import date, timedelta

import requests
from PIL import Image
from metrics import METRICS, metric_of, rows_of
from paired_statistics import summarize_pairs

SCHEMA = "temperature-explorer-v1"
DATASET = "MODIS/061/MOD11A1"
PALETTE = ["173f96", "53b8e8", "9fe3cb", "ffe68a", "ef754e", "bb2847"]


class RemoteWorker:
    mode = "live"
    def __init__(self, url, token):
        self.url, self.token = url.rstrip("/"), token.strip()
        self._lock=threading.Lock()

    def request(self, operation, query):
        with self._lock:return self._request(operation,query)

    def _request(self,operation,query):
        if not self.token:
            raise ValueError("尚未找到原Worker配置。请沿用旧网页的server.env配置后启动新版。")
        for attempt in range(4):
            try:
                response = requests.post(self.url + "/research2/explorer/" + operation, json=query,
                                         headers={"Authorization":"Bearer " + self.token}, timeout=(15,240))
            except requests.RequestException:
                raise ValueError("暂时无法连接取数服务，已显示的结果保留，请稍后重试。") from None
            if response.status_code == 429 and attempt < 3:
                retry = getattr(response, 'headers', {}).get('Retry-After', '5')
                time.sleep(min(15, max(2, int(retry))) if retry.isdigit() else 5)
                continue
            if response.status_code == 404:
                raise ValueError("远端尚未安装新版双击查询接口，请先更新Render取数服务；旧网页仍可使用。")
            if response.status_code in (401,403):
                raise ValueError("Worker配置未通过验证，请核对沿用的server.env。")
            if response.status_code == 422:
                detail = response.json().get("detail")
                raise ValueError(detail if isinstance(detail,str) else "查询条件未通过远端校验。")
            if response.status_code != 200:
                raise ValueError(f"卫星取数暂未完成（HTTP {response.status_code}），请稍后重试。")
            data = response.json()
            keys = ("city","district","start","end") + (("longitude","latitude","radius_m") if operation=="point" else ())
            metric = query.get('metric', 'temperature')
            if (data.get("schema") != SCHEMA or data.get("dataset") != METRICS[metric]['dataset'] or
                    data.get('metric', 'temperature') != metric or
                    data.get("operation") != operation or any(data.get(k) != query.get(k) for k in keys)):
                raise ValueError("远端结果与当前地点、时间或接口版本不一致，已停止展示。")
            data["source_mode"] = "live"
            return data
        raise ValueError("取数服务繁忙，请稍后重试。")

    def region(self, query):
        return self.request("region",query)

    def point(self, query):
        return self.request("point",query)

    def history(self, query):
        return self.request('history',query)['history']

    def relationship(self,query):
        return self.request('relationship',{k:v for k,v in {**query,'metric':'temperature'}.items() if k!='radius_m'})


def demo_stats(values, total):
    return {"mean":sum(values)/len(values) if values else None,
            "min":min(values) if values else None,"max":max(values) if values else None,
            "count":len(values),"coverage":round(len(values)/total*100,1) if total else 0}


def demo_png(values, side=24, metric='temperature'):
    image = Image.new("RGBA",(side,side),(0,0,0,0))
    colors=[tuple(bytes.fromhex(c)) for c in (PALETTE if metric == 'temperature' else
             ['d6c2a0','f4edcc','c1da9a','7db86b','3c884b','155d36'])]
    for i,value in enumerate(values[:side*side]):
        if value is None: continue
        t=max(0,min(4.999,((value+20)/70 if metric == 'temperature' else (value+.2)/1.2)*5)); k=int(t); f=t-k
        color=tuple(round(colors[k][j]*(1-f)+colors[k+1][j]*f) for j in range(3))
        image.putpixel((i%side,i//side),(*color,255))
    output=io.BytesIO()
    image.resize((480,480),Image.Resampling.NEAREST).save(output,format="PNG")
    return base64.b64encode(output.getvalue()).decode()


class DemoWorker:
    mode = "demo"
    def region(self, query):
        seed=int(hashlib.sha256(str(sorted(query.items())).encode()).hexdigest()[:8],16)
        rng=random.Random(seed)
        metric = query.get('metric', 'temperature')
        ndvi = metric == 'ndvi'
        mean = .55+rng.uniform(-.12,.12) if ndvi else 24+int(query["start"][5:7])*0.4+rng.uniform(-2,2)
        samples=[max(-.2,min(1,rng.gauss(mean,.1))) if ndvi else rng.gauss(mean,2.5) for _ in range(500)]
        first,last=date.fromisoformat(query["start"]),date.fromisoformat(query["end"])
        daily=[]
        for i in range((last-first).days+1):
            day=(first+timedelta(days=i)).isoformat()
            vals=[] if i%5==2 else [rng.gauss(mean+2*math.sin(i/6),2.5) for _ in range(450)]
            daily.append({"date":day,**demo_stats(vals,576)})
        shift=0.12 if query.get("district")=="包河区" else 0
        bounds=[[31.76,117.08+shift],[31.96,117.30+shift]]
        s,w=bounds[0];n,e=bounds[1]
        feature={"type":"Feature","properties":{"name":query["city"]+(query.get("district") or "")},
                 "geometry":{"type":"Polygon","coordinates":[[[w,s],[e,s],[e,n],[w,n],[w,s]]]}}
        observations = []
        if ndvi:
            candidate = date(first.year, 1, 1)
            while candidate <= last:
                end = min(candidate+timedelta(days=15), date(candidate.year,12,31))
                if candidate<=last and end>=first:
                    start_in=max(candidate,first);end_in=min(end,last)
                    observations.append({'date':start_in.isoformat(),'period_start':start_in.isoformat(),
                                         'period_end':end_in.isoformat(),'source_period_start':candidate.isoformat(),
                                         'source_period_end':end.isoformat(),**demo_stats(samples,576)})
                candidate = date(candidate.year+1,1,1) if end.month == 12 and end.day == 31 else end+timedelta(days=1)
            daily = []
        return {"schema":SCHEMA,"dataset":METRICS[metric]['dataset'],"operation":"region",**query,"source_mode":"demo",
                'metric':metric,'unit':'NDVI' if ndvi else 'degC','nominal_resolution_m':250 if ndvi else 1000,
                "summary":demo_stats(samples,576),"daily":daily,"samples":samples,"sample_count":len(samples),
                'observations':observations, 'actual_periods':[{'start':r['period_start'],'end':r['period_end']} for r in observations],
                'temporal_note':'16天产品演示：仅统计所选范围内观测，区间外像元已排除。' if ndvi else '',
                "sample_limit":3000,"sample_basis":"演示合成像元，非真实卫星观测", "total":576,
                "feature":feature,"boundary_file":"演示矩形边界（不代表真实行政边界）", "image_count":len(observations) if ndvi else len(daily),
                "bounds":bounds,"map_png_base64":demo_png(samples+[None]*76,metric=metric),
                "quality":"演示合成数据，未进行真实卫星质量筛选"}

    def point(self, query):
        metric = query.get('metric', 'temperature')
        base=self.region({**{k:query.get(k) for k in ("city","district","start","end")},'metric':metric})
        lat,lon=query["latitude"],query["longitude"]
        half=0.001125 if metric == 'ndvi' else 0.0045; step=half*2
        center_lon=math.floor(lon/step)*step+half;center_lat=math.floor(lat/step)*step+half
        ring=[[center_lon-half,center_lat-half],[center_lon+half,center_lat-half],
              [center_lon+half,center_lat+half],[center_lon-half,center_lat+half],[center_lon-half,center_lat-half]]
        value=round(.55+.1*math.sin(lon*10) if metric == 'ndvi' else 24+4*math.sin(lon*10)+2*math.cos(lat*10),3)
        delta=.03 if metric == 'ndvi' else 1
        local=[value-delta,value,value+delta,value+delta*.3]
        base["samples"]=local;base["sample_count"]=len(local);base["total"]=5
        base["summary"]=demo_stats(local,5)
        base["bounds"]=[[lat-0.01,lon-0.012],[lat+0.01,lon+0.012]]
        base["map_png_base64"]=demo_png([local[(i//12)%4] if 4<i%24<20 else None for i in range(576)],metric=metric)
        point_rows=[{**{k:r[k] for k in ('date','period_start','period_end') if k in r},
                     'value':None if r['mean'] is None else value+delta*.2*math.sin(i/5)} for i,r in enumerate(rows_of(base))]
        return {"schema":SCHEMA,"dataset":METRICS[metric]['dataset'],"operation":"point",**query,"source_mode":"demo",
                'metric':metric,'feature':base['feature'],'boundary_file':base['boundary_file'],
                'nominal_resolution_m':250 if metric=='ndvi' else 1000,
                "point":{"value":value,"pixel_geometry":{"type":"Polygon","coordinates":[ring]},
                         "daily":point_rows if metric=='temperature' else [],
                         'observations':point_rows if metric=='ndvi' else [],'metric':metric,
                         "statistic":"演示示意网格，非真实MODIS像元边框"},
                "neighborhood":base}

    def history(self,query):
        year=int(query["start"][:4])
        return [{"year":y,"mean":None if y==year-3 else (.55+.08*math.sin(y) if query.get('metric')=='ndvi' else 25+math.sin(y)),"coverage":80,"count":500}
                for y in range(year-9,year+1)]

    def relationship(self,query):
        rng=random.Random(str(sorted(query.items())))
        rows=[]
        for _ in range(4 if query.get('longitude') is not None else 450):
            ndvi=rng.uniform(.2,.85);rows.append({'NDVI':ndvi,'LST_C':36-12*ndvi+rng.gauss(0,2)})
        result=summarize_pairs(rows);base=self.region({k:v for k,v in query.items() if k not in ('longitude','latitude')})
        palette=[(140,172,196,255),(213,134,102,255),(81,157,133,255),(181,163,99,255)]
        canvas=Image.new('RGBA',(24,24));output=io.BytesIO()
        for index in range(576):
            row=rows[index%len(rows)];category=2*int(row['NDVI']>=result['ndvi_median'])+int(row['LST_C']>=result['temperature_median'])
            canvas.putpixel((index%24,index//24),palette[category])
        canvas.resize((480,480),Image.Resampling.NEAREST).save(output,format='PNG')
        return {**result,'metric':'temperature','schema':SCHEMA,'operation':'relationship','dataset':DATASET,
                'source_mode':'demo','scope':'point_neighborhood' if query.get('longitude') is not None else 'region',
                'note':'合成演示配对样本，仅验证关系图，不能作为实际温度与植被的研究结论。',
                'bounds':base['bounds'],'map_png_base64':base64.b64encode(output.getvalue()).decode(), 'paired_grid_count':len(rows)}
