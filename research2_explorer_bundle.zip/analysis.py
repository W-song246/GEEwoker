"""可审计的数据概况及真实模型解读，二者明确区分。"""
import json
import math
from datetime import date


def quantiles(values):
    values=sorted(v for v in values if v is not None and math.isfinite(v))
    if not values:return {}
    def pick(p):
        i=(len(values)-1)*p; lower=int(i); upper=min(lower+1,len(values)-1)
        return round(values[lower]+(values[upper]-values[lower])*(i-lower),3)
    return {"sample_count":len(values),"q25":pick(.25),"median":pick(.5),"q75":pick(.75)}


def series_facts(rows, value_key="mean"):
    valid=[r for r in rows if r.get(value_key) is not None]
    facts={"requested_days":len(rows),"valid_days":len(valid),"missing_days":len(rows)-len(valid)}
    if not valid:return facts
    low=min(valid,key=lambda r:r[value_key]);high=max(valid,key=lambda r:r[value_key])
    facts.update(lowest_valid_day={"date":low["date"],"value":low[value_key]},
                 highest_valid_day={"date":high["date"],"value":high[value_key]})
    if len(valid)>=3:
        first=date.fromisoformat(valid[0]["date"])
        xs=[(date.fromisoformat(r["date"])-first).days for r in valid]
        ys=[r[value_key] for r in valid]
        xm,ym=sum(xs)/len(xs),sum(ys)/len(ys)
        den=sum((x-xm)**2 for x in xs)
        if den:
            facts["observed_daily_slope_c_per_day"]=round(sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/den,5)
    return facts


def evidence(results,point=None):
    facts={"dataset":"NASA MOD11A1 V6.1 daytime LST", "unit":"°C", "cases":[]}
    for result in results:
        if "summary" not in result:continue
        facts["cases"].append({"label":result["label"],"query":result["query"],
            "summary":result["summary"],"time_series":series_facts(result.get("daily",[])),
            "daily":result.get("daily",[]),"spatial_sample":quantiles(result.get("samples",[])),
            "sample_basis":"QC-valid pixels of period pixel-mean image; seeded sample, not daily regional means"})
    means=[r for r in facts["cases"] if r["summary"]["mean"] is not None]
    if len(means)>1:
        high=max(means,key=lambda r:r["summary"]["mean"]);low=min(means,key=lambda r:r["summary"]["mean"])
        facts["comparison"]={"highest":high["label"],"lowest":low["label"],
                             "difference_c":round(high["summary"]["mean"]-low["summary"]["mean"],4),
                             "same_period":len({(x['query']['start'],x['query']['end']) for x in means})==1}
    if point:
        facts["selected_point"]={k:point[k] for k in ("longitude","latitude","radius_m")}
        facts['selected_point']['within_selected_region']=point.get('within_selected_region')
        facts["selected_point"].update(native_pixel_value=point["point"]["value"],
            native_pixel_daily=point["point"]["daily"],
            native_pixel_time_series=series_facts(point["point"]["daily"],"value"),
            neighborhood_summary=point["neighborhood"]["summary"],
            neighborhood_time_series=series_facts(point["neighborhood"]["daily"]))
    return facts


def overview(facts):
    lines=[]
    for item in facts["cases"]:
        stats=item["summary"];series=item["time_series"]
        if stats["mean"] is None:
            lines.append(f"{item['label']}：缺少有效像元，不能据此判断温度高低。")
            continue
        lines.append(f"{item['label']}：区域均温{stats['mean']:.2f}℃，有效像元空间覆盖率{stats['coverage']:.1f}%，"
                     f"{series['requested_days']}天中{series['valid_days']}天有值。")
        if series.get("highest_valid_day") and series["requested_days"]>1:
            high=series["highest_valid_day"]
            lines.append(f"有值日期中，{high['date']}的区域均温最高，为{high['value']:.2f}℃。")
        if "observed_daily_slope_c_per_day" in series:
            slope=series["observed_daily_slope_c_per_day"]
            lines.append(f"有效日期日均值的拟合变化率约{slope:+.3f}℃/日，仅描述本次观测，不代表长期气候趋势。")
    comp=facts.get("comparison")
    if comp:
        lines.append(f"本次结果中，{comp['highest']}均温高于{comp['lowest']}约{comp['difference_c']:.2f}℃。"
                     "比较时还需结合各组覆盖率和缺测日期。")
    point=facts.get("selected_point")
    if point:
        value=point["native_pixel_value"]
        lines.insert(0,f"选点({point['longitude']:.5f}, {point['latitude']:.5f})所在像元温度："
                     +(f"{value:.2f}℃。" if value is not None else "缺测，未用邻近像元替代。"))
        lines.append(f"周边统计范围为半径{point['radius_m']}米的圆，与单像元值分别展示。")
    return "\n\n".join(lines) or "本次没有可用于分析的有效观测。"


def analyze(client,model,results,point=None,demo=False):
    facts=evidence(results,point)
    fallback={"kind":"statistics","text":overview(facts),"facts":facts}
    if demo:return {**fallback,"notice":"演示数据仅用于验证页面交互，未调用AI分析真实卫星数据。"}
    if client is None:return {**fallback,"notice":"未配置AI模型。以下为真实数据的自动统计概况，可沿用旧智谱配置后重试。"}
    rules=("你是卫星地表温度分析助手。根据给出的真实数据用中文写简洁分析，不只复述数值。"
           "关注本次观测的时间变化、区域/时期差异、像元分布和数据完整性。每个结论都须有提供的数据支持。"
           "最多3个短段落，约200至400字。仅引用给出的数值；空值为缺测，不能当0。"
           "有效日期少于3天不得判断时间趋势；短时段拟合不称气候趋势。"
           "区分时段像元均值合成后的空间统计、逐日区域均温、点位原生像元、半径1公里周边圆。"
           "within_selected_region为false时，点击坐标在原区域之外，不能把该点说成属于原城市或区。"
           "空间极值不是日内气象最高最低温，地表温度不是气温。不同时间的区域不能归因于区域差异。"
           "缺测和低覆盖影响可比性。可能原因须标为待验证解释，不能声称已证明热岛、建筑用途或因果。"
           "不要假设拥有未提供的地物、气象或植被数据；不编造模型置信区间、显著性或预测。")
    try:
        reply=client.chat.completions.create(model=model,temperature=.15,
            messages=[{"role":"system","content":rules},{"role":"user","content":json.dumps(facts,ensure_ascii=False)}])
        content=reply.choices[0].message.content
        if not content or not content.strip():raise ValueError("empty reply")
        return {"kind":"model","text":content.strip(),"notice":"智谱AI分析，基于本次查询的真实统计与有效观测。"}
    except Exception as error:
        notice="AI当前限流，可稍后单独重试。" if "429" in str(error) else "AI暂未生成分析，可稍后单独重试。"
        return {**fallback,"notice":notice+" 已保留数据与图表，以下为自动统计概况。"}
