"""依据真实指标和时间口径整理事实，统计概况与模型生成分开呈现。"""
import json
import math
from datetime import date
from metrics import METRICS, metric_of, rows_of
from query_summary import query_summary


def quantiles(values):
    values=sorted(v for v in values if v is not None and math.isfinite(v))
    if not values:return {}
    def pick(p):
        i=(len(values)-1)*p;lower=int(i);upper=min(lower+1,len(values)-1)
        return round(values[lower]+(values[upper]-values[lower])*(i-lower),3)
    return {'sample_count':len(values),'q25':pick(.25),'median':pick(.5),'q75':pick(.75)}


def series_facts(rows,value_key='mean'):
    valid=[r for r in rows if r.get(value_key) is not None]
    facts={'requested_days':len(rows),'valid_days':len(valid),'missing_days':len(rows)-len(valid)}
    if not valid:return facts
    low=min(valid,key=lambda r:r[value_key]);high=max(valid,key=lambda r:r[value_key])
    facts.update(lowest_valid_day={'date':low['date'],'value':low[value_key]},highest_valid_day={'date':high['date'],'value':high[value_key]})
    if len(valid)>=3:
        first=date.fromisoformat(valid[0]['date']);xs=[(date.fromisoformat(r['date'])-first).days for r in valid]
        ys=[r[value_key] for r in valid];xm,ym=sum(xs)/len(xs),sum(ys)/len(ys);den=sum((x-xm)**2 for x in xs)
        if den:facts['observed_daily_slope_c_per_day']=round(sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/den,5)
    return facts


def temporal_facts(data,metric,value_key='mean'):
    facts=series_facts(rows_of(data,metric),value_key)
    if metric=='ndvi':
        facts={key.replace('days','periods').replace('day','period'):value for key,value in facts.items() if key!='observed_daily_slope_c_per_day'}
        facts['cadence']='16-day source composite; rows are observation windows clipped to the query, not daily observations'
    return facts


def evidence(results,point=None,requested=None):
    facts={'cases':[],'comparisons':[], 'cross_metric_note':'Use spatial_relationship only for paired spatial association. Raw case summaries are unpaired; correlation does not establish causation.'}
    for result in results:
        if 'summary' not in result:continue
        metric=metric_of(result);definition=METRICS[metric]
        item={'label':result['label'],'query':result['query'],'metric':metric,'dataset':definition['dataset'],'unit':definition['unit'],
              'scope':result.get('scope','region'),'summary':result['summary'],'time_series':temporal_facts(result,metric),
              'daily':result.get('daily',[]),'observations':result.get('observations',[]),'actual_periods':result.get('actual_periods',[]),
              'temporal_note':result.get('temporal_note','Daily daytime LST observations'),
              'spatial_sample':quantiles(result.get('samples',[])),
              'sample_basis':result.get('sample_basis','QC-valid native pixels of period pixel-mean image')}
        if result.get('point_result'):
            item['selected_point']={**result['focus'],'native_pixel_value':result['point_result']['point']['value'],
                                    'radius_m':1000,'within_selected_region':result['point_result'].get('within_selected_region')}
        if result.get('relationship'):
            relation=result['relationship']
            item['spatial_relationship']={k:relation.get(k) for k in ('status','sample_count','pearson_r','slope_c_per_ndvi','note','temporal_alignment')}
        facts['cases'].append(item)
    for metric in METRICS:
        means=[r for r in facts['cases'] if r['metric']==metric and r['summary']['mean'] is not None]
        if len(means)>1:
            high=max(means,key=lambda r:r['summary']['mean']);low=min(means,key=lambda r:r['summary']['mean'])
            difference=round(high['summary']['mean']-low['summary']['mean'],5)
            facts['comparisons'].append({'metric':metric,'highest':high['label'],'lowest':low['label'],'difference':difference,
                'unit':METRICS[metric]['unit'],**({'difference_c':difference} if metric=='temperature' else {}),
                'same_period':len({(x['query']['start'],x['query']['end']) for x in means})==1})
    if len(facts['comparisons'])==1:facts['comparison']=facts['comparisons'][0]
    if point:
        metric=metric_of(point)
        facts['selected_point']={k:point[k] for k in ('longitude','latitude','radius_m')}
        facts['selected_point'].update(metric=metric,unit=METRICS[metric]['unit'],within_selected_region=point.get('within_selected_region'),
            native_pixel_value=point['point']['value'],native_pixel_daily=point['point'].get('daily',[]),
            native_pixel_observations=point['point'].get('observations',[]),native_pixel_time_series=temporal_facts(point['point'],metric,'value'),
            neighborhood_summary=point['neighborhood']['summary'],neighborhood_time_series=temporal_facts(point['neighborhood'],metric))
        facts['additional_selected_points']=[{'metric':metric_of(item),'unit':METRICS[metric_of(item)]['unit'],
            'native_pixel_value':item['point']['value'],'observations':rows_of(item['point'],metric_of(item)),
            'neighborhood_summary':item['neighborhood']['summary'],'neighborhood_observations':rows_of(item['neighborhood'],metric_of(item)),
            'within_selected_region':item.get('within_selected_region')} for item in point.get('comparison',[])]
        if point.get('relationship'):
            facts['selected_point']['spatial_relationship']={k:point['relationship'].get(k) for k in ('status','sample_count','pearson_r','note')}
    summary_results=results
    if point:
        summary_results=[]
        for selected in [point,*point.get('comparison',[])]:
            parent=next((r for r in results if r.get('id')==selected.get('case_id')),None)
            parent=parent or next((r for r in results if metric_of(r)==metric_of(selected)),results[0])
            item={**selected['neighborhood'],'query':parent['query'],'metric':metric_of(selected),
                  'label':parent['label'],'scope':'point','focus':{k:point[k] for k in ('longitude','latitude')}}
            if selected.get('relationship'):item['relationship']=selected['relationship']
            summary_results.append(item)
        requested=None
    summary=query_summary(summary_results,requested)
    facts.update(period_groups=summary['groups'],query_trends=summary['query_trends'],query_overview=summary['text'])
    queries=requested or [r['query'] for r in summary_results]
    facts['requested_scope']={'start':min(q['start'] for q in queries),'end':max(q['end'] for q in queries),
        'requested_cases':len(queries),'available_cases':len(summary_results),
        'instruction':'Analyse this entire query range. The map-selected month does not restrict the overall analysis.'}
    return facts


def overview(facts):
    lines=[facts.get('query_overview','')]
    point=facts.get('selected_point')
    if point:
        value=point['native_pixel_value'];unit=point['unit']
        lines.insert(0,f"选点({point['longitude']:.5f}, {point['latitude']:.5f})所在像元："+(f'{value:.3f} {unit}。' if value is not None else '缺测，未使用邻近像元替代。'))
        lines.append(f"周边统计范围为半径{point['radius_m']}米，与所在像元分别展示。")
    return '\n\n'.join(lines) or '本次没有可用于分析的有效观测。'


def analyze(client,model,results,point=None,demo=False,requested=None):
    facts=evidence(results,point,requested);summary=overview(facts)
    fallback={'kind':'statistics','text':summary,'overview':summary,'facts':facts,'model':model,
              'scope_metrics':sorted({metric_of(result) for result in results}),
              'period_analyses':[],'analysis_scope':facts['requested_scope']}
    if demo:return {**fallback,'ai_status':'demo','notice':'当前为合成数据演示，没有调用AI。'}
    if client is None:return {**fallback,'ai_status':'not_configured','notice':'AI未配置，可沿用原智谱配置后重试。'}
    rules=('你是卫星温度与植被数据分析助手。只返回JSON：'
           '{"overall":"完整查询范围的总体解读，2至3段，约250至450字",'
           '"period_analyses":[{"id":"period_groups中的原始id","text":"该时段的联合解读，约50至90字"}]}。'
           '必须先分析requested_scope的完整年份或多月范围，以query_trends的所有月份为依据，不能只分析地图默认选中的1月份。'
           '年度变化应描述季节性升降、峰谷月份和波动，不能把全年简单概括为一个直线斜率，也不能逐月逐指标罗列24条数据。'
           'overall把温度与植被放在一起讨论，说明它们的峰谷是否同步，结合空间配对关系和覆盖率解释分析的限度。'
           'period_analyses按period_groups每个地区时段只写一条，同月温度和植被必须在同一条文字中讨论，不得拆成两条。'
           '只查询单个指标时，分析实际存在的指标；只有一个月时分析该月，不假称全年趋势。'
           '分析时段变化、同指标的区域或时期差异、空间分布和数据完整性，结论必须有数据支持。'
           '温度是白天地表温度℃，不是气温；NDVI是无量纲植被指数，不是覆盖百分比或生态质量评分。'
           'NDVI是16天源产品合成，观测段按查询范围裁剪，不是每日观测。'
           'NDVI已按DayOfYear筛选观测日期，只使用查询范围内的产品选中观测；不能称每日完整观测。'
           'spatial_relationship是同一时段汇总、共同有效温度网格的实际配对样本，可据其r、斜率和样本数讨论空间关联。'
           '观测日不一定逐日相同，不能称同日因果；样本不足不推断稳定关系；空间自相关使r不能当显著性证明。'
           '各指标独立单位，不能把℃与NDVI相减，也不能把负相关直接解释成植被导致降温。'
           '有效温度日期或NDVI产品期少于三个，不拟合或推断时间趋势；短时段不能称长期气候趋势。'
           '空值是缺测而非0；区分区域、原生像元与半径1公里邻域；scope=point的统计只代表邻域。'
           'within_selected_region=false时，点在原区域外。空间极值不是日内最高最低气温。'
           '区域时间不同不能归因为区域差异；可能原因标明待验证，不编造地物、气象、显著性或预测。')
    try:
        compact={k:facts[k] for k in ('requested_scope','query_trends','period_groups','comparisons','cross_metric_note')}
        for key in ('selected_point','additional_selected_points'):
            if key in facts:compact[key]=facts[key]
        reply=client.chat.completions.create(model=model,temperature=.15,
            messages=[{'role':'system','content':rules},{'role':'user','content':json.dumps(compact,ensure_ascii=False)}])
        content=reply.choices[0].message.content
        if not content or not content.strip():raise ValueError('empty reply')
        text=content.strip();periods=[]
        if text.startswith('{') or text.startswith('```'):
            parsed=json.loads(text[text.index('{'):text.rindex('}')+1]);text=parsed['overall'].strip()
            if not text:raise ValueError('empty overall')
            allowed={g['id'] for g in facts['period_groups']};seen=set()
            for row in parsed.get('period_analyses',[]):
                if row.get('id') in allowed and row['id'] not in seen and isinstance(row.get('text'),str) and row['text'].strip():
                    periods.append({'id':row['id'],'text':row['text'].strip(),'source':'model'});seen.add(row['id'])
        return {'kind':'model','ai_status':'ready','text':text,'overview':summary,'model':model,
                'period_analyses':periods,'analysis_scope':facts['requested_scope'],
                'scope_metrics':fallback['scope_metrics'],'notice':'智谱AI基于本次真实结果生成，仅辅助理解。'}
    except Exception as error:
        status=getattr(error,'status_code',None) or getattr(getattr(error,'response',None),'status_code',None)
        limited=status==429 or '429' in str(error)
        return {**fallback,'ai_status':'rate_limited' if limited else 'unavailable',
                'notice':'AI请求频率受限，请稍后重试。' if limited else 'AI暂未生成解读，可稍后重试；数据与图表已保留。'}
