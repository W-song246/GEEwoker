"""依据真实指标和时间口径整理事实，统计概况与模型生成分开呈现。"""
import json
import math
from datetime import date
from metrics import METRICS, metric_of, rows_of


def quantiles(values):
    values=sorted(v for v in values if v is not None and math.isfinite(v))
    if not values:return {}
    def pick(p):
        i=(len(values)-1)*p;lower=int(i);upper=min(lower+1,len(values)-1)
        return round(values[lower]+(values[upper]-values[lower])*(i-lower),3)
    return {'sample_count':len(values),'q25':pick(.25),'median':pick(.5),'q75':pick(.75)}


def series_facts(rows,value_key='mean'):
    valid=[r for r in rows if r.get(value_key) is not None]
    facts={'requested_days':len(rows),'valid_days':len(valid),'missing_days':len(rows)-len(valid)}
    if not valid:return facts
    low=min(valid,key=lambda r:r[value_key]);high=max(valid,key=lambda r:r[value_key])
    facts.update(lowest_valid_day={'date':low['date'],'value':low[value_key]},highest_valid_day={'date':high['date'],'value':high[value_key]})
    if len(valid)>=3:
        first=date.fromisoformat(valid[0]['date']);xs=[(date.fromisoformat(r['date'])-first).days for r in valid]
        ys=[r[value_key] for r in valid];xm,ym=sum(xs)/len(xs),sum(ys)/len(ys);den=sum((x-xm)**2 for x in xs)
        if den:facts['observed_daily_slope_c_per_day']=round(sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/den,5)
    return facts


def temporal_facts(data,metric,value_key='mean'):
    facts=series_facts(rows_of(data,metric),value_key)
    if metric=='ndvi':
        facts={key.replace('days','periods').replace('day','period'):value for key,value in facts.items() if key!='observed_daily_slope_c_per_day'}
        facts['cadence']='16-day composite; dates are product starts, not daily observations'
    return facts


def evidence(results,point=None):
    facts={'cases':[],'comparisons':[], 'cross_metric_note':'Different grids and cadence: do not infer correlation or causation from unpaired temperature/NDVI summaries.'}
    for result in results:
        if 'summary' not in result:continue
        metric=metric_of(result);definition=METRICS[metric]
        item={'label':result['label'],'query':result['query'],'metric':metric,'dataset':definition['dataset'],'unit':definition['unit'],
              'scope':result.get('scope','region'),'summary':result['summary'],'time_series':temporal_facts(result,metric),
              'daily':result.get('daily',[]),'observations':result.get('observations',[]),'actual_periods':result.get('actual_periods',[]),
              'temporal_note':result.get('temporal_note','Daily daytime LST observations'),
              'spatial_sample':quantiles(result.get('samples',[])),
              'sample_basis':result.get('sample_basis','QC-valid native pixels of period pixel-mean image')}
        if result.get('point_result'):
            item['selected_point']={**result['focus'],'native_pixel_value':result['point_result']['point']['value'],
                                    'radius_m':1000,'within_selected_region':result['point_result'].get('within_selected_region')}
        facts['cases'].append(item)
    for metric in METRICS:
        means=[r for r in facts['cases'] if r['metric']==metric and r['summary']['mean'] is not None]
        if len(means)>1:
            high=max(means,key=lambda r:r['summary']['mean']);low=min(means,key=lambda r:r['summary']['mean'])
            difference=round(high['summary']['mean']-low['summary']['mean'],5)
            facts['comparisons'].append({'metric':metric,'highest':high['label'],'lowest':low['label'],'difference':difference,
                'unit':METRICS[metric]['unit'],**({'difference_c':difference} if metric=='temperature' else {}),
                'same_period':len({(x['query']['start'],x['query']['end']) for x in means})==1})
    if len(facts['comparisons'])==1:facts['comparison']=facts['comparisons'][0]
    if point:
        metric=metric_of(point)
        facts['selected_point']={k:point[k] for k in ('longitude','latitude','radius_m')}
        facts['selected_point'].update(metric=metric,unit=METRICS[metric]['unit'],within_selected_region=point.get('within_selected_region'),
            native_pixel_value=point['point']['value'],native_pixel_daily=point['point'].get('daily',[]),
            native_pixel_observations=point['point'].get('observations',[]),native_pixel_time_series=temporal_facts(point['point'],metric,'value'),
            neighborhood_summary=point['neighborhood']['summary'],neighborhood_time_series=temporal_facts(point['neighborhood'],metric))
        facts['additional_selected_points']=[{'metric':metric_of(item),'unit':METRICS[metric_of(item)]['unit'],
            'native_pixel_value':item['point']['value'],'observations':rows_of(item['point'],metric_of(item)),
            'neighborhood_summary':item['neighborhood']['summary'],'neighborhood_observations':rows_of(item['neighborhood'],metric_of(item)),
            'within_selected_region':item.get('within_selected_region')} for item in point.get('comparison',[])]
    return facts


def overview(facts):
    lines=[]
    for item in facts['cases']:
        stats=item['summary'];series=item['time_series'];ndvi=item['metric']=='ndvi'
        if stats['mean'] is None:
            lines.append(f"{item['label']}：没有通过质量筛选的有效像元，保留缺测。")
            continue
        unit=' NDVI' if ndvi else '℃';label='平均植被指数' if ndvi else '均温';scope='选点周边1公里' if item['scope']=='point' else '区域'
        valid=series.get('valid_periods' if ndvi else 'valid_days',0);count=series.get('requested_periods' if ndvi else 'requested_days',0)
        lines.append(f"{item['label']}：{scope}{label}{stats['mean']:.3f}{unit}，空间有效覆盖率{stats['coverage']:.1f}%；"
                     +(f'{count}个产品期中{valid}期有值。' if ndvi else f'{count}天中{valid}天有值。'))
        if not ndvi and 'observed_daily_slope_c_per_day' in series:
            lines.append(f"有效日均值的拟合变化率约{series['observed_daily_slope_c_per_day']:+.3f}℃/日，仅描述本次有效观测。")
    for comp in facts.get('comparisons',[]):
        lines.append(f"{comp['highest']}的均值比{comp['lowest']}高{comp['difference']:.3f} {comp['unit']}；比较须结合有效覆盖和实际时段。")
    point=facts.get('selected_point')
    if point:
        value=point['native_pixel_value'];unit=point['unit']
        lines.insert(0,f"选点({point['longitude']:.5f}, {point['latitude']:.5f})所在像元："+(f'{value:.3f} {unit}。' if value is not None else '缺测，未使用邻近像元替代。'))
        lines.append(f"周边统计范围为半径{point['radius_m']}米，与所在像元分别展示。")
    return '\n\n'.join(lines) or '本次没有可用于分析的有效观测。'


def analyze(client,model,results,point=None,demo=False):
    facts=evidence(results,point);summary=overview(facts)
    fallback={'kind':'statistics','text':summary,'overview':summary,'facts':facts,'model':model,
              'scope_metrics':sorted({metric_of(result) for result in results})}
    if demo:return {**fallback,'ai_status':'demo','notice':'当前为合成数据演示，没有调用AI。'}
    if client is None:return {**fallback,'ai_status':'not_configured','notice':'AI未配置，可沿用原智谱配置后重试。'}
    rules=('你是卫星温度与植被数据分析助手，根据提供的真实数据，用中文给出最多三个短段落的分析，约200至400字。'
           '分析时段变化、同指标的区域或时期差异、空间分布和数据完整性，结论必须有数据支持。'
           '温度是白天地表温度℃，不是气温；NDVI是无量纲植被指数，不是覆盖百分比或生态质量评分。'
           'NDVI是16天合成，observations和actual_periods为实际产品期，不是每日观测。'
           '产品起始月归组可能跨月；单日植被结果是覆盖该日的合成期，不是当天实测。'
           '各指标分别比较，不能把℃与NDVI相减，也不能由两类汇总便断言相关或植被降温因果。'
           '有效温度日期或NDVI产品期少于三个，不拟合或推断时间趋势；短时段不能称长期气候趋势。'
           '空值是缺测而非0；区分区域、原生像元与半径1公里邻域；scope=point的统计只代表邻域。'
           'within_selected_region=false时，点在原区域外。空间极值不是日内最高最低气温。'
           '区域时间不同不能归因为区域差异；可能原因标明待验证，不编造地物、气象、显著性或预测。')
    try:
        reply=client.chat.completions.create(model=model,temperature=.15,
            messages=[{'role':'system','content':rules},{'role':'user','content':json.dumps(facts,ensure_ascii=False)}])
        content=reply.choices[0].message.content
        if not content or not content.strip():raise ValueError('empty reply')
        return {'kind':'model','ai_status':'ready','text':content.strip(),'overview':summary,'model':model,
                'scope_metrics':fallback['scope_metrics'],'notice':'智谱AI基于本次真实结果生成，仅辅助理解。'}
    except Exception as error:
        status=getattr(error,'status_code',None) or getattr(getattr(error,'response',None),'status_code',None)
        limited=status==429 or '429' in str(error)
        return {**fallback,'ai_status':'rate_limited' if limited else 'unavailable',
                'notice':'AI请求频率受限，请稍后重试。' if limited else 'AI暂未生成解读，可稍后重试；数据与图表已保留。'}
