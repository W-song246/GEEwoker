"""按完整查询时段概括趋势，同一月份的指标在同一组内解释。"""
import math
from metrics import METRICS,metric_of,rows_of


def finite(value):
    return isinstance(value,(int,float)) and math.isfinite(value)


def period_label(start,end):
    if start[:7]==end[:7] and start.endswith('-01'):
        return f'{start[:4]}年{int(start[5:7])}月'
    return start if start==end else start+'—'+end


def identity(query,scope='region',focus=None):
    return (query['city'],query.get('district') or '',scope,
            (focus or {}).get('longitude'),(focus or {}).get('latitude'))


def grouped_periods(results,requested=None):
    by_key={}
    focus=next((r.get('focus') for r in results if r.get('focus')),None)
    scope='point' if focus else 'region'
    for query in requested or [r['query'] for r in results]:
        key=(*identity(query,scope,focus),query['start'],query['end'])
        group=by_key.setdefault(key,{'location':query['city']+(query.get('district') or '全市'),
            'scope':scope,'focus':focus,'start':query['start'],'end':query['end'],'metrics':{}})
        group['metrics'].setdefault(query.get('metric','temperature'),{'status':'unavailable','mean':None})
    for result in results:
        q=result['query'];key=(*identity(q,result.get('scope','region'),result.get('focus')),q['start'],q['end'])
        group=by_key.setdefault(key,{'location':q['city']+(q.get('district') or '全市'),'scope':result.get('scope','region'),
            'focus':result.get('focus'),'start':q['start'],'end':q['end'],'metrics':{}})
        metric=metric_of(result);rows=rows_of(result,metric);summary=result['summary']
        group['metrics'][metric]={'status':'ready' if finite(summary.get('mean')) else 'missing',
            'mean':summary.get('mean'),'coverage':summary.get('coverage'),
            'valid_observations':sum(finite(r.get('mean')) for r in rows),'requested_observations':len(rows),
            'unit':METRICS[metric]['unit']}
        valid_rows=sorted((r for r in rows if finite(r.get('mean'))),key=lambda r:r['date'])
        if valid_rows:
            brief=lambda row:{k:row[k] for k in ('date','period_start','period_end','mean') if k in row}
            group['metrics'][metric]['observed_changes']={
                'first':brief(valid_rows[0]),'last':brief(valid_rows[-1]),
                'highest':brief(max(valid_rows,key=lambda r:r['mean'])),
                'lowest':brief(min(valid_rows,key=lambda r:r['mean']))}
        if result.get('relationship'):
            group['spatial_relationship']={k:result['relationship'].get(k) for k in ('status','sample_count','pearson_r','note','temporal_alignment')}
    groups=sorted(by_key.values(),key=lambda g:(g['location'],g['start'],g['end']))
    for i,group in enumerate(groups):
        group['id']='period-'+str(i);group['period_label']=period_label(group['start'],group['end'])
        group['label']=group['location']+' · '+group['period_label']
        group['text']=joint_period_text(group)
        group['by_metric']={m:joint_period_text({**group,'metrics':{m:group['metrics'][m]},'spatial_relationship':{}}) for m in group['metrics']}
    return groups


def joint_period_text(group):
    parts=[];coverage=[]
    for metric in ('temperature','ndvi'):
        item=group['metrics'].get(metric)
        if not item:continue
        name='温度' if metric=='temperature' else 'NDVI'
        if item['status']!='ready':
            parts.append(name+('未取得结果' if item['status']=='unavailable' else '缺测'));continue
        value=f"{item['mean']:.2f}℃" if metric=='temperature' else f"{item['mean']:.3f}"
        parts.append(f"{name}均值{value}")
        coverage.append(f"{name}{item['coverage']:.1f}%")
    if coverage:parts.append('有效覆盖：'+'、'.join(coverage))
    relation=group.get('spatial_relationship',{})
    if relation.get('status')=='ready' and finite(relation.get('pearson_r')):
        parts.append(f"同月空间关联r={relation['pearson_r']:.3f}")
    return '；'.join(parts)+'。'


def trend_facts(groups):
    locations={}
    for group in groups:
        key=(group['location'],group['scope'],str(group.get('focus')))
        locations.setdefault(key,[]).append(group)
    trends=[]
    for entries in locations.values():
        start=min(g['start'] for g in entries);end=max(g['end'] for g in entries)
        info={'location':entries[0]['location'],'scope':entries[0]['scope'],'start':start,'end':end,
              'period_count':len(entries),'metrics':{},'focus':entries[0].get('focus')}
        for metric in ('temperature','ndvi'):
            rows=[{'start':g['start'],'end':g['end'],'label':g['period_label'],**g['metrics'][metric]} for g in entries if metric in g['metrics']]
            if not rows:continue
            valid=[r for r in rows if finite(r.get('mean'))]
            item={'periods':rows,'valid_periods':len(valid),'requested_periods':len(rows),
                  'valid_observations':sum(r.get('valid_observations',0) for r in rows),
                  'requested_observations':sum(r.get('requested_observations',0) for r in rows)}
            if valid:
                low=min(valid,key=lambda r:r['mean']);high=max(valid,key=lambda r:r['mean'])
                item.update(lowest=low,highest=high,first=valid[0],last=valid[-1],
                    first_to_last_change=round(valid[-1]['mean']-valid[0]['mean'],5))
                if len(valid)>=3:
                    first,last=valid[0]['mean'],valid[-1]['mean'];peak=valid.index(high);trough=valid.index(low)
                    if 0<peak<len(valid)-1 and high['mean']>max(first,last):shape='先升后降'
                    elif 0<trough<len(valid)-1 and low['mean']<min(first,last):shape='先降后升'
                    elif last>first:shape='波动上升'
                    elif last<first:shape='波动下降'
                    else:shape='波动'
                    item['pattern']=shape
            info['metrics'][metric]=item
        both=info['metrics']
        associations=[{'period':g['period_label'],'start':g['start'],**g['spatial_relationship']} for g in entries if g.get('spatial_relationship',{}).get('status')=='ready']
        if associations:
            info['spatial_associations']={'periods':associations,'negative_periods':sum(r.get('pearson_r',0)<0 for r in associations),
                'positive_periods':sum(r.get('pearson_r',0)>0 for r in associations),
                'note':'每项是该月共同有效网格的空间关系，不将多月样本混合成一个年度因果系数。'}
        if all(both.get(m,{}).get('valid_periods',0)>=3 for m in ('temperature','ndvi')):
            t,n=both['temperature']['highest'],both['ndvi']['highest']
            info['joint_timing']={'temperature_peak':t['label'],'ndvi_peak':n['label'],
                'same_peak_period':(t['start'],t['end'])==(n['start'],n['end']),
                'note':'时间上共同升降不等于空间相关，更不能据此推断植被造成温度变化。'}
        trends.append(info)
    return trends


def overview_text(groups,trends,metric_filter=None):
    lines=[]
    for trend in trends:
        relevant=[m for m in ('temperature','ndvi') if m in trend['metrics'] and (not metric_filter or metric_filter==m)]
        if not relevant:continue
        label=trend['location']+(' · 选点周边1公里' if trend['scope']=='point' else '')+' · '+trend['start']+'—'+trend['end']
        if trend['period_count']==1:
            group=next(g for g in groups if g['location']==trend['location'] and g['start']==trend['start'] and g['scope']==trend['scope'])
            selected={**group,'metrics':{m:group['metrics'][m] for m in relevant}}
            if metric_filter:selected.pop('spatial_relationship',None)
            lines.append(label+'：'+joint_period_text(selected));continue
        parts=[]
        for metric in relevant:
            info=trend['metrics'][metric];name='温度' if metric=='temperature' else 'NDVI';unit='℃' if metric=='temperature' else ''
            decimals=2 if metric=='temperature' else 3
            if not info['valid_periods']:parts.append(name+'暂无有效时段');continue
            high,low=info['highest'],info['lowest'];pattern=info.get('pattern')
            text=name+(('总体'+pattern+'，') if pattern else f"仅{info['valid_periods']}个有效时段，暂不判断总趋势；")
            text+=f"{high['label']}最高{high['mean']:.{decimals}f}{unit}，{low['label']}最低{low['mean']:.{decimals}f}{unit}（{info['valid_periods']}/{info['requested_periods']}个时段有值）"
            parts.append(text)
        timing=trend.get('joint_timing')
        if timing and not metric_filter:
            parts.append('两者峰值'+('出现在同一时段' if timing['same_peak_period'] else '出现在不同时段，季节变化并非完全同步'))
        association=trend.get('spatial_associations')
        if association and not metric_filter:
            parts.append(f"{len(association['periods'])}个时段完成空间配对，其中{association['negative_periods']}个负向、{association['positive_periods']}个正向关联，不能据此认定因果")
        lines.append(label+'：'+'；'.join(parts)+'。')
    return '\n\n'.join(lines) or '本次没有可用于概括趋势的有效观测。'


def query_summary(results,requested=None):
    groups=grouped_periods(results,requested);trends=trend_facts(groups)
    return {'text':overview_text(groups,trends),'groups':groups,'query_trends':trends,
            'by_metric':{m:overview_text(groups,trends,m) for m in METRICS}}
