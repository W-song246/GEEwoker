"""独立温度交互网页。默认真实Worker；--demo显式运行合成数据交互预览。"""
import argparse
import base64
import csv
import io
import json
import math
import os
import secrets
import threading
import time
import re
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from typing import Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi.staticfiles import StaticFiles
from PIL import Image
from pydantic import BaseModel, ConfigDict, Field

from analysis import analyze
from backend import DemoWorker, RemoteWorker
from query_parser import case_label, normalize_plan, parse_query, parse_with_model
from metrics import METRICS, metric_of, rows_of
from query_summary import query_summary

BASE=Path(__file__).resolve().parent
TTL=4*60*60


class QueryRequest(BaseModel):
    model_config=ConfigDict(extra="forbid",allow_inf_nan=False)
    text:str=Field(min_length=1,max_length=2000)
    auto_ai:bool=True
    preserve_selection:bool=False


class ResultRequest(BaseModel):
    model_config=ConfigDict(extra="forbid",allow_inf_nan=False)
    job_id:str=Field(pattern=r"^[0-9a-f]{32}$")
    case_id:int=Field(ge=0,le=23)


class PointRequest(ResultRequest):
    longitude:float=Field(ge=-180,le=180)
    latitude:float=Field(ge=-85,le=85)
    sequence:int=Field(ge=1,le=100000000)
    peer_case_id:int|None=Field(default=None,ge=0,le=23)


class AnalysisRequest(BaseModel):
    model_config=ConfigDict(extra="forbid")
    job_id:str=Field(pattern=r"^[0-9a-f]{32}$")
    sequence:int|None=Field(default=None,ge=1)
    metric:Literal['temperature','ndvi']|None=None


def month_tables(result):
    groups={}
    for row in rows_of(result):groups.setdefault(row["date"][:7],[]).append(row)
    suffix = ' · 植被合成期数据' if metric_of(result)=='ndvi' else ' · 逐日数据'
    return [{"title":result.get('label',case_label(result["query"]))+suffix+("（"+month+"）" if len(groups)>1 else ""),
             "month":month,"rows":rows} for month,rows in groups.items()]


def csv_bytes(rows,metric='temperature'):
    stream=io.StringIO(newline="");writer=csv.writer(stream)
    keys = ('period_start','period_end','min','mean','max','count','coverage') if metric=='ndvi' else ('date','min','mean','max','count','coverage')
    writer.writerow(['观测范围开始','观测范围结束','最低NDVI','平均NDVI','最高NDVI','有效像元','空间覆盖率%'] if metric=='ndvi'
                    else ["日期","空间最低℃","区域均温℃","空间最高℃","有效像元","空间覆盖率%"])
    for row in rows:writer.writerow([row.get(k) for k in keys])
    return stream.getvalue().encode("utf-8-sig")


def inside_geometry(geometry,longitude,latitude):
    def ring_contains(ring):
        inside=False
        for a,b in zip(ring,ring[1:]+ring[:1]):
            if (a[1]>latitude)!=(b[1]>latitude) and longitude<(b[0]-a[0])*(latitude-a[1])/(b[1]-a[1])+a[0]:
                inside=not inside
        return inside
    polygons=geometry['coordinates'] if geometry['type']=='MultiPolygon' else [geometry['coordinates']]
    return any(ring_contains(p[0]) and not any(ring_contains(hole) for hole in p[1:]) for p in polygons)


def point_csv_bytes(point,month=None):
    stream=io.StringIO(newline='');writer=csv.writer(stream)
    metric=metric_of(point)
    writer.writerow(['观测范围开始','观测范围结束','所在像元NDVI','周边最低NDVI','周边平均NDVI','周边最高NDVI','周边有效像元','周边覆盖率%'] if metric=='ndvi' else
                    ['日期','所在像元温度℃','周边空间最低℃','周边均温℃','周边空间最高℃','周边有效像元','周边覆盖率%'])
    by_day={r['date']:r['value'] for r in rows_of(point['point'],metric)}
    for row in rows_of(point['neighborhood'],metric):
        if month is None or row['date'].startswith(month+'-'):
            dates=[row['period_start'],row['period_end']] if metric=='ndvi' else [row['date']]
            writer.writerow([*dates,by_day.get(row['date']),*[row.get(k) for k in ('min','mean','max','count','coverage')]])
    return stream.getvalue().encode('utf-8-sig')


def create_app(backend=None,client=None,model="glm-4.7-flash",cache_dir=None):
    backend=backend or RemoteWorker(os.getenv("GEE_WORKER_URL","https://geewoker.onrender.com"),os.getenv("WORKER_TOKEN",""))
    root=Path(cache_dir or BASE/".cache");root.mkdir(parents=True,exist_ok=True)
    demo=backend.mode=="demo"
    sessions={};jobs={};images={};lock=threading.RLock()
    pool=ThreadPoolExecutor(max_workers=3,thread_name_prefix="temperature")
    @asynccontextmanager
    async def lifecycle(application):
        yield
        pool.shutdown(wait=False,cancel_futures=True)
    web=FastAPI(title="温度交互查询",docs_url=None,redoc_url=None,lifespan=lifecycle)
    web.state.backend=backend;web.state.jobs=jobs

    @web.exception_handler(RequestValidationError)
    async def validation_error(request,error):
        # 不回显Pydantic的原始input（NaN/Inf无法JSON序列化，也无需回显用户载荷）。
        details=[{"field":".".join(str(v) for v in e["loc"]),"message":e["msg"]} for e in error.errors()]
        return JSONResponse(status_code=422,content={"detail":"查询条件格式不正确，请核对坐标、日期和参数。","fields":details})

    def session(request,response=None):
        now=time.monotonic()
        with lock:
            for sid in [s for s,v in sessions.items() if now-v["touched"]>TTL]:sessions.pop(sid,None)
            for jid in [j for j,v in jobs.items() if now-v["created"]>TTL]:jobs.pop(jid,None)
            for fid in [f for f,v in images.items() if now-v["created"]>TTL]:
                record=images.pop(fid);record["path"].unlink(missing_ok=True)
            sid=request.cookies.get("temperature_session")
            if sid not in sessions:
                if len(sessions)>=64:raise HTTPException(503,"当前访问较多，请稍后再试。")
                sid=secrets.token_hex(24)
                sessions[sid]={"state":{},"active":None,"point_seq":0,"point":None,"touched":now}
                if response is not None:response.set_cookie("temperature_session",sid,httponly=True,samesite="strict",max_age=TTL)
            sessions[sid]["touched"]=now
            return sid,sessions[sid]

    def owned_job(request,jid):
        sid,state=session(request)
        with lock:job=jobs.get(jid)
        if not job or job["owner"]!=sid:raise HTTPException(404,"查询记录已过期，请重新查询。")
        return job,state

    def case_of(job,index):
        result=next((r for r in job["results"] if r["id"]==index),None)
        if not result:raise HTTPException(404,"该组结果尚未生成。")
        return result

    def store_image(data,owner):
        encoded=data.pop("map_png_base64",None)
        data["png_url"]=None
        if not encoded:return
        if len(encoded)>6*1024*1024:raise ValueError("影像文件超过展示限制。")
        content=base64.b64decode(encoded,validate=True)
        if not content.startswith(b"\x89PNG\r\n\x1a\n"):raise ValueError("影像格式异常。")
        with Image.open(io.BytesIO(content)) as image:
            if max(image.size)>2048:raise ValueError("影像尺寸超过展示限制。")
            image.verify()
        fid=secrets.token_hex(16);path=root/(fid+".png");path.write_bytes(content)
        with lock:
            if len(images)>=512:
                old=images.pop(next(iter(images)));old["path"].unlink(missing_ok=True)
            images[fid]={"owner":owner,"path":path,"created":time.monotonic()}
        data["png_url"]="/api/images/"+fid

    def run_query(job,auto_ai):
        for index,query in enumerate(job["plan"]["cases"]):
            with lock:
                job["progress"]=f"正在读取第{index+1}/{len(job['plan']['cases'])}组：{case_label(query)}"
            try:
                # Worker缓存命中的对象也需复制，保存图片不能修改缓存中的原始PNG字段。
                if job.get('focus'):
                    selected=json.loads(json.dumps(backend.point({**query,**job['focus'],'radius_m':1000}),allow_nan=False))
                    selected['within_selected_region']=inside_geometry(selected['feature']['geometry'],selected['longitude'],selected['latitude'])
                    store_image(selected['neighborhood'],job['owner'])
                    data={**{k:v for k,v in selected.items() if k not in ('point','neighborhood')},
                          **selected['neighborhood'],'point_result':selected,'scope':'point','focus':job['focus']}
                else:
                    data=json.loads(json.dumps(backend.region(query),allow_nan=False))
                    store_image(data,job["owner"])
                result={**data,"id":index,"label":case_label(query),"query":query}
                if job.get('focus'):
                    result['label']=f"选点({job['focus']['longitude']:.5f}, {job['focus']['latitude']:.5f}) · "+case_label(query)
                result["tables"]=month_tables(result)
                with lock:job["results"].append(result);job['revision']+=1
            except Exception as error:
                message=str(error) if isinstance(error,ValueError) else f"该组取数未完成（{type(error).__name__}）。"
                with lock:job["errors"].append({"id":index,"label":case_label(query),"message":message});job['revision']+=1
        for result in job['results']:
            if metric_of(result)!='temperature':continue
            query=result['query']
            if not any(metric_of(peer)=='ndvi' and all(peer['query'][k]==query[k] for k in ('city','district','start','end')) for peer in job['results']):continue
            with lock:job['progress']='正在计算温度与植被的同网格空间关系…'
            try:
                relation=json.loads(json.dumps(backend.relationship({**query,**(job.get('focus') or {})}),allow_nan=False))
                store_image(relation,job['owner'])
                with lock:result['relationship']=relation;job['revision']+=1
            except Exception as error:
                with lock:
                    result['relationship_error']=str(error) if isinstance(error,ValueError) else '关系计算暂未完成，可单独重试。'
                    job['revision']+=1
        with lock:job["progress"]="图表数据已就绪，正在生成AI分析。" if auto_ai else "查询完成。"
        if auto_ai and job["results"]:
            analysis=analyze(client,model,job["results"],demo=demo,requested=job['plan']['cases'])
            with lock:job["analysis"]=analysis;job['revision']+=1
        with lock:
            job["status"]="done";job["progress"]="查询完成。" if job["results"] else "本次未取得有效结果，请查看提示。"
            job['revision']+=1

    @web.middleware("http")
    async def same_origin(request,call_next):
        if request.method=="POST" and request.headers.get("sec-fetch-site")=="cross-site":
            return Response("不接受跨站查询请求",status_code=403)
        return await call_next(request)

    @web.get("/")
    def index():return FileResponse(BASE/"static"/"index.html",headers={'Cache-Control':'no-store'})

    @web.get("/api/status")
    def status(request:Request,response:Response):
        session(request,response)
        return {"mode":backend.mode,"ai_configured":bool(client),"worker_configured":demo or bool(getattr(backend,"token",None)),
                "dataset":"MODIS/061/MOD11A1","metrics":METRICS,"model":model,"version":"eco-explorer-2026.11.11-eco.4"}

    @web.post("/api/query")
    def query(body:QueryRequest,request:Request,response:Response):
        sid,state=session(request,response)
        with lock:
            active=jobs.get(state.get("active"))
            if active and active["status"]!="done":raise HTTPException(409,"上次查询仍在处理，请等待完成后再提交。")
            previous=dict(state["state"])
            state["query_revision"]=state.get("query_revision",0)+1
            revision=state["query_revision"]
        plan=parse_with_model(body.text,previous,client,model)
        with lock:
            if revision!=state["query_revision"]:raise HTTPException(409,"查询已改变，请以最新输入为准。")
            active=jobs.get(state.get("active"))
            if active and active["status"]!="done":raise HTTPException(409,"上次查询仍在处理，请等待完成后再提交。")
            if plan["action"]=="clarify":
                state["state"]=plan["state"];state["active"]=None;state["point"]=None
                return {"kind":"clarify","reply":plan["reply"]}
            focus=state.get('selection') if (body.preserve_selection or re.search(r'这里|这个点|该点|同一位置|刚才的点',body.text)) else None
            if not focus:state['selection']=None
            state["state"]=plan["state"];jid=secrets.token_hex(16)
            state["active"]=jid;state["point"]=None
            # 每个会话只保留最近8个任务，避免反复查询累积样本数组。
            old=[j for j,v in jobs.items() if v["owner"]==sid]
            for old_id in old[:-7]:jobs.pop(old_id,None)
            job={"owner":sid,"id":jid,"created":time.monotonic(),"status":"running","plan":plan,'focus':focus,
                 "progress":"正在解析查询条件。","results":[],"errors":[],"analysis":None,'revision':0}
            jobs[jid]=job
        pool.submit(run_query,job,body.auto_ai)
        return {"kind":"query","job_id":jid,"focus":focus,"metrics":plan.get('metrics',['temperature']),
                "labels":[case_label(c) for c in plan["cases"]],
                "cases":[{"id":i,**case} for i,case in enumerate(plan["cases"])]}

    @web.get("/api/jobs/{jid}")
    def job_status(jid:str,request:Request,since:int|None=None):
        job,_=owned_job(request,jid)
        with lock:
            if since==job['revision']:
                return {'id':job['id'],'revision':job['revision'],'status':job['status'],'progress':job['progress'],'unchanged':True}
            snapshot=json.loads(json.dumps({k:job[k] for k in ('id','revision','status','progress','results','errors','analysis')},allow_nan=False))
            requested=job['plan']['cases']
        snapshot['summary']=query_summary(snapshot['results'],requested)
        return snapshot

    @web.post("/api/point")
    async def query_point(body:PointRequest,request:Request):
        import asyncio
        job,state=owned_job(request,body.job_id);case=case_of(job,body.case_id)
        with lock:
            if state["active"]!=body.job_id or body.sequence<=state["point_seq"]:
                raise HTTPException(409,"选点已更新，本次旧请求已忽略。")
            state["point_seq"]=body.sequence;state["point"]=None
        payload={**case["query"],"longitude":body.longitude,"latitude":body.latitude,"radius_m":1000}
        try:data=await asyncio.to_thread(backend.point,payload)
        except ValueError as error:raise HTTPException(422,str(error)) from None
        except Exception as error:raise HTTPException(502,f"选点查询暂未完成（{type(error).__name__}）。") from None
        data=json.loads(json.dumps(data,allow_nan=False))
        data['comparison']=[]
        if body.peer_case_id is not None:
            peer=case_of(job,body.peer_case_id)
            if any(peer['query'].get(k)!=case['query'].get(k) for k in ('city','district','start','end')) or metric_of(peer)==metric_of(case):
                raise HTTPException(422,'对照选点必须属于同一地点、同一查询时段的不同指标。')
            with lock:
                if state['point_seq']!=body.sequence:raise HTTPException(409,'选点已更新，本次旧结果已忽略。')
            try:
                other=await asyncio.to_thread(backend.point,{**peer['query'],'longitude':body.longitude,'latitude':body.latitude,'radius_m':1000})
                other=json.loads(json.dumps(other,allow_nan=False))
                other.update(case_id=peer['id'],label=peer['label'],sequence=body.sequence)
                other['within_selected_region']=inside_geometry(peer['feature']['geometry'],body.longitude,body.latitude)
                data['comparison'].append(other)
            except ValueError as error:
                data['comparison_error']=str(error)
        if data['comparison']:
            try:
                data['relationship']=await asyncio.to_thread(backend.relationship,{**case['query'],'longitude':body.longitude,'latitude':body.latitude})
            except ValueError as error:data['relationship_error']=str(error)
        with lock:
            if state["active"]!=body.job_id or body.sequence!=state["point_seq"]:
                raise HTTPException(409,"选点已更新，本次旧结果已忽略。")
            store_image(data["neighborhood"],job["owner"])
            for other in data['comparison']:store_image(other['neighborhood'],job['owner'])
            if data.get('relationship'):store_image(data['relationship'],job['owner'])
            data.update(sequence=body.sequence,case_id=body.case_id,label=case["label"])
            data['within_selected_region']=inside_geometry(case['feature']['geometry'],body.longitude,body.latitude)
            state['selection']={'longitude':body.longitude,'latitude':body.latitude}
            state["point"]=data
        return data

    @web.post("/api/analysis")
    async def query_analysis(body:AnalysisRequest,request:Request):
        import asyncio
        job,state=owned_job(request,body.job_id)
        point=None
        with lock:
            if body.sequence is None and job['status']!='done':
                raise HTTPException(409,'完整查询仍在取数，请等待全部时段完成后生成总体解读；已有图表可以继续查看。')
            if body.sequence is not None:
                point=state["point"]
                if state["active"]!=body.job_id or not point or point["sequence"]!=body.sequence:
                    raise HTTPException(409,"选点已改变，请以当前选点为准。")
                selected=[case_of(job,point["case_id"])]
                if body.metric and metric_of(point)!=body.metric:
                    point=next((item for item in point.get('comparison',[]) if metric_of(item)==body.metric),None)
                    if not point:raise HTTPException(422,'该指标的选点尚未取数。')
                    selected=[case_of(job,point['case_id'])]
                elif body.metric is None:
                    selected.extend(case_of(job,item['case_id']) for item in point.get('comparison',[]))
            else:selected=[r for r in job["results"] if body.metric is None or metric_of(r)==body.metric]
        if not selected:raise HTTPException(422,"请先完成卫星查询。")
        requested=[r['query'] for r in selected] if point else [q for q in job['plan']['cases'] if body.metric is None or q.get('metric','temperature')==body.metric]
        result=await asyncio.to_thread(analyze,client,model,selected,point,demo,requested)
        with lock:
            if body.sequence is not None and (state["active"]!=body.job_id or body.sequence!=state["point_seq"]):
                raise HTTPException(409,"旧选点的AI分析已忽略。")
            if body.sequence is None:job["analysis"]=result;job['revision']+=1
        return result

    @web.post("/api/history")
    async def query_history(body:ResultRequest,request:Request):
        import asyncio
        job,_=owned_job(request,body.job_id);case=case_of(job,body.case_id)
        try:rows=await asyncio.to_thread(backend.history,case["query"])
        except ValueError as error:raise HTTPException(422,str(error)) from None
        return {"label":case["label"],"history":rows,"source_mode":backend.mode}

    @web.get("/api/csv/{jid}/{case_id}")
    def download_csv(jid:str,case_id:int,request:Request,month:str|None=None):
        job,_=owned_job(request,jid);case=case_of(job,case_id)
        rows=[r for r in rows_of(case) if month is None or r["date"].startswith(month+"-")]
        return StreamingResponse(iter([csv_bytes(rows,metric_of(case))]),media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition":f'attachment; filename="{metric_of(case)}_{case_id}_{month or "all"}.csv"'})

    @web.get("/api/images/{fid}")
    def image(fid:str,request:Request):
        sid,_=session(request)
        with lock:record=images.get(fid)
        if not record or record["owner"]!=sid:raise HTTPException(404,"影像已过期，请重新查询。")
        return FileResponse(record["path"],media_type="image/png",filename="satellite_map.png")

    @web.get('/api/point-csv/{jid}/{sequence}')
    def point_csv(jid:str,sequence:int,request:Request,month:str|None=None,case_id:int|None=None):
        _,state=owned_job(request,jid)
        with lock:
            point=state['point']
            if state['active']!=jid or not point or point['sequence']!=sequence:
                raise HTTPException(404,'选点已改变，请下载当前选点的数据。')
            if case_id is not None and point['case_id']!=case_id:
                point=next((item for item in point.get('comparison',[]) if item['case_id']==case_id),None)
                if not point:raise HTTPException(404,'该选点指标未生成。')
            content=point_csv_bytes(point,month)
        return StreamingResponse(iter([content]),media_type='text/csv; charset=utf-8',
            headers={'Content-Disposition':f'attachment; filename="point_{metric_of(point)}_{sequence}.csv"'})

    @web.post("/api/reset")
    def reset(request:Request,response:Response):
        _,state=session(request,response)
        with lock:state.update(state={},active=None,point=None,selection=None,query_revision=state.get("query_revision",0)+1)
        return {"ok":True}

    @web.post('/api/selection/clear')
    def clear_point(request:Request,response:Response):
        _,state=session(request,response)
        with lock:state.update(selection=None,point=None,point_seq=state['point_seq']+1)
        return {'ok':True}

    web.mount("/static",StaticFiles(directory=BASE/"static"),name="static")
    return web


def load_configuration():
    for file in (BASE/"server.env",Path("/home/ubuntu/research2-city/server.env"),BASE.parent/"server"/"server.env"):
        if file.is_file():load_dotenv(file,override=True);return


def main():
    import uvicorn
    parser=argparse.ArgumentParser()
    parser.add_argument("--demo",action="store_true",help="显式合成数据演示；不调用真实卫星取数")
    parser.add_argument("--port",type=int,default=7862)
    parser.add_argument("--host",default="127.0.0.1")
    args=parser.parse_args();load_configuration()
    model=os.getenv("ZHIPU_MODEL","glm-4.7-flash").strip()
    client=None
    if not args.demo and os.getenv("ZHIPU_API_KEY","").strip():
        from zhipuai import ZhipuAI
        client=ZhipuAI(api_key=os.environ["ZHIPU_API_KEY"].strip(),timeout=30,max_retries=0)
    app=create_app(backend=DemoWorker() if args.demo else None,client=client,model=model)
    uvicorn.run(app,host=args.host,port=args.port,log_level="warning")


if __name__=="__main__":main()
