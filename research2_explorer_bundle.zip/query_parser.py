"""自然语言的明确条件本地解析；所有查询统一经过时间、组合数量验证。"""
import calendar
import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

CATALOG = json.loads(Path(__file__).with_name("city_catalog.json").read_text(encoding="utf-8"))
MAX_CASES = 8


def month_period(year, month):
    first = date(year, month, 1)
    return {"start": first.isoformat(), "end": date(year, month, calendar.monthrange(year, month)[1]).isoformat()}


def normalize_plan(locations, periods, today=None):
    today = today or datetime.now(ZoneInfo("Asia/Shanghai")).date()
    clean_locations, clean_periods = [], []
    for loc in locations:
        city = str(loc.get("city") or "").strip().removesuffix("市")
        city = CATALOG["aliases"].get(city.lower(), city)
        district = str(loc.get("district") or "").strip() or None
        if not city or city.endswith(("区", "县")):
            raise ValueError("请写明所属城市，例如“合肥蜀山区”。")
        if len(city) > 40 or (district and (not district.endswith("区") or len(district) > 20)):
            raise ValueError("请核对城市和市辖区名称。")
        item = {"city": city, "district": district}
        if item not in clean_locations:
            clean_locations.append(item)
    for period in periods:
        start, end = date.fromisoformat(str(period["start"])), date.fromisoformat(str(period["end"]))
        if start < date(2000, 2, 24) or end < start:
            raise ValueError("日期需从2000-02-24开始，结束日期不能早于开始日期。")
        if (end-start).days > 92:
            raise ValueError("单个时段最多93天；比较多个月时请分别列出月份。")
        if start > today:
            raise ValueError("不能查询尚未发生的日期。")
        item = {"start": start.isoformat(), "end": end.isoformat()}
        if item not in clean_periods:
            clean_periods.append(item)
    if not clean_locations or not clean_periods:
        raise ValueError("请补充城市或市辖区，以及具体年份和日期/月。")
    if len(clean_locations) > 4 or len(clean_periods) > 6 or len(clean_locations)*len(clean_periods) > MAX_CASES:
        raise ValueError("一次最多4个区域、6个时段，共8组结果，请减少比较数量。")
    cases = [{**loc, **period} for loc in clean_locations for period in clean_periods]
    return {"action": "query", "locations": clean_locations, "periods": clean_periods, "cases": cases}


def find_locations(text, previous):
    patterns = sorted(CATALOG["cities"] + list(CATALOG["aliases"]), key=len, reverse=True)
    city_re = re.compile("|".join(re.escape(x) for x in patterns), re.I)
    occurrences = []
    for match in city_re.finditer(text):
        name = CATALOG["aliases"].get(match.group().lower(), match.group())
        if match.group().isascii() and ((match.start() and re.fullmatch(r"[A-Za-z]",text[match.start()-1])) or
                                       (match.end()<len(text) and re.fullmatch(r"[A-Za-z]",text[match.end()]))):
            continue
        occurrences.append((match.start(), match.end(), name))
    previous_cities = {x["city"] for x in previous.get("locations", [])}
    default_city = occurrences[0][2] if len({x[2] for x in occurrences}) == 1 else (
        next(iter(previous_cities)) if len(previous_cities) == 1 else None)
    # 去掉数字时间单位，避免“2026年蜀山区”被提取成“年蜀山区”。
    cleaned = re.sub(r"\d{4}\s*年|\d{1,2}\s*[月日号]", " ", text)
    district_re = re.compile(r"([\u4e00-\u9fff]{1,12}?区)")
    districts = []
    for match in district_re.finditer(cleaned):
        name = match.group(1)
        for word in sorted(CATALOG["cities"], key=len, reverse=True):
            name = name.replace(word, "")
        name = re.sub(r"^(?:(?:请|帮我|查询|查|查看|看看|比较|对比|换成|再看|再|和|与|以及|及|的|在|市))+", "", name)
        if name in {"这个区", "该区", "各区", "区域", "区", "整个区", "一个区"} or len(name) < 2:
            continue
        # 坐标采用原始字符串区名末尾定位，避免清理时间后偏移。
        position = text.find(name)
        before = [x for x in occurrences if x[0] < position]
        owner = before[-1][2] if before else default_city
        districts.append({"city": owner, "district": name})
    if districts:
        if any(not x["city"] for x in districts):
            return districts, "请补充这些区所属的城市，例如“合肥蜀山区和包河区”。"
        locations = list(districts)
        # 混合“合肥蜀山区和南京”时保留南京全市。
        for i, (_, end, name) in enumerate(occurrences):
            stop = occurrences[i+1][0] if i+1<len(occurrences) else len(text)
            if "区" not in text[end:stop] and not any(x["city"] == name for x in districts):
                locations.append({"city": name, "district": None})
        return locations, None
    if occurrences:
        return [{"city": x[2], "district": None} for x in occurrences], None
    return previous.get("locations", []), None


def parse_query(text, previous=None, today=None):
    previous = previous or {}
    today = today or datetime.now(ZoneInfo("Asia/Shanghai")).date()
    text = text.strip()
    if not text:
        return {"action": "clarify", "reply": "请输入城市或市辖区，以及年份和日期/月。", "state": previous}
    text = text.replace("今年", f"{today.year}年").replace("去年", f"{today.year-1}年")
    chinese_numbers={"一":1,"二":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9}
    def chinese_date(match):
        value=match[1]
        if '十' in value:
            left,right=value.split('十',1)
            number=(chinese_numbers.get(left,1))*10+chinese_numbers.get(right,0)
        else:number=chinese_numbers[value]
        return str(number)+match[2]
    text=re.sub(r"([一二三四五六七八九十]{1,3})(月|日|号)",chinese_date,text)
    if previous.get('pending_time') and re.search(r'\d{4}\s*年',text) and not re.search(r'\d{1,2}\s*月',text):
        text=text+' '+previous['pending_time']
    locations, location_question = find_locations(text, previous)
    explicit_years = list(re.finditer(r"(?<!\d)(\d{4})\s*年", text))
    year = int(explicit_years[0][1]) if explicit_years else previous.get("pending_year")
    if not year and re.search(r"再|换|改|同年", text) and previous.get("periods"):
        year = int(previous["periods"][0]["start"][:4])
    periods = []
    has_time = bool(explicit_years or re.search(r"\d{1,2}\s*[月日号]|\d{4}-", text))
    iso = list(re.finditer(r"(?<!\d)(\d{4}-\d{1,2}-\d{1,2})(?!\d)", text))
    try:
        for raw in re.finditer(r"(?<!\d)(\d{1,2})\s*月(?:\s*(\d{1,2})\s*[日号])?",text):
            if not 1<=int(raw[1])<=12 or (raw[2] and not 1<=int(raw[2])<=31):
                raise ValueError("invalid month/day")
        if iso:
            for match in iso:
                parts = [int(v) for v in match[1].split("-")]
                day = date(*parts).isoformat()
                periods.append({"start": day, "end": day})
            if len(iso)==2 and re.search(r"至|到|~|～|—", text[iso[0].end():iso[1].start()]):
                periods = [{"start": periods[0]["start"], "end": periods[-1]["end"]}]
        else:
            matches = list(re.finditer(r"(?<!\d)(?:(\d{4})\s*年\s*)?(1[0-2]|0?[1-9])\s*月(?:\s*(3[01]|[12]\d|0?[1-9])\s*[日号])?", text))
            for index, match in enumerate(matches):
                preceding_years = [x for x in explicit_years if x.start()<match.start()]
                use_year = int(match[1]) if match[1] else (int(preceding_years[-1][1]) if preceding_years else year)
                if not use_year:
                    pending_time=text[matches[0].start():]
                    for loc in locations:
                        pending_time=pending_time.replace(loc.get('city') or '\0','').replace(loc.get('district') or '\0','')
                    return {"action":"clarify", "reply":"已记下地点和月份，请问是哪一年？",
                            "state":{"locations": locations, "pending_months":[int(x[2]) for x in matches],"pending_time":pending_time}}
                month = int(match[2])
                if match[3]:
                    day = date(use_year, month, int(match[3])).isoformat()
                    periods.append({"start":day,"end":day})
                    rest_end = matches[index+1].start() if index+1<len(matches) else len(text)
                    rest = text[match.end():rest_end]
                    following = list(re.finditer(r"(?:、|和|与|及|,|，|至|到|~|～|—)\s*(\d{1,2})\s*[日号]", rest))
                    for follow in following:
                        end_day = date(use_year, month, int(follow[1])).isoformat()
                        if re.match(r"至|到|~|～|—", follow.group()):
                            periods[-1]["end"] = end_day
                        else:
                            periods.append({"start":end_day,"end":end_day})
                else:
                    periods.append(month_period(use_year, month))
            if len(matches)==2 and not re.search(r"比较|对比|分别|各月", text) and re.search(
                    r"至|到|~|～|—", text[matches[0].end():matches[1].start()]):
                periods = [{"start":periods[0]["start"], "end":periods[-1]["end"]}]
            if not matches:
                english = re.finditer(r"\b(?:(\d{1,2})\s+)?(" + "|".join(
                    [calendar.month_name[i] for i in range(1,13)] + [calendar.month_abbr[i] for i in range(1,13)]) +
                    r")\s+(\d{4})\b", text, re.I)
                month_names = {name.lower(): i for i in range(1,13) for name in (calendar.month_name[i],calendar.month_abbr[i])}
                for match in english:
                    y, m = int(match[3]), month_names[match[2].lower()]
                    if match[1]:
                        day = date(y,m,int(match[1])).isoformat()
                        periods.append({"start":day,"end":day})
                    else:
                        periods.append(month_period(y,m))
                if not periods:
                    for match in re.finditer(r"(?<!\d)(\d{4})-(\d{1,2})(?![-\d])", text):
                        periods.append(month_period(int(match[1]),int(match[2])))
        if not periods and year and previous.get("pending_months"):
            periods = [month_period(year, m) for m in previous["pending_months"]]
    except ValueError:
        return {"action":"clarify", "reply":"日期不存在，请核对月份和日期后重试。",
                "state":{"locations":locations, "pending_year":year}}
    if not periods and not has_time:
        periods = previous.get("periods", [])
    state = {"locations":locations, "periods":periods, "pending_year":year}
    if location_question or not locations or not periods:
        if location_question:
            reply = location_question
        elif not locations:
            reply = "时间已记下，请问要查询哪个城市或市辖区？"
        elif year:
            reply = f"已记下{year}年，请问要查询哪一月，或者具体哪一天？"
        else:
            reply = "请补充具体年份和月份，或完整日期。"
        return {"action":"clarify", "reply":reply, "state":state}
    try:
        plan = normalize_plan(locations,periods,today)
    except ValueError as error:
        return {"action":"clarify", "reply":str(error), "state":state}
    plan["state"] = {"locations":plan["locations"], "periods":plan["periods"]}
    return plan


def case_label(case):
    location = case["city"] + (case.get("district") or "全市")
    start,end = date.fromisoformat(case["start"]),date.fromisoformat(case["end"])
    if start.day==1 and start.year==end.year and start.month==end.month and end.day==calendar.monthrange(end.year,end.month)[1]:
        window=f"{start.year}年{start.month}月"
    else:
        window=case["start"] if start==end else f"{case['start']} 至 {case['end']}"
    return f"{location} · {window}"


def parse_with_model(text,previous,client,model):
    """明确问句与缺项追问不依赖模型；复杂相对日期允许真实AI解析。"""
    parsed=parse_query(text,previous)
    complex_time=bool(re.search(r"本月|上月|上个月|最近|过去|昨天|前天|今天|上周|last month|yesterday|last week",text,re.I))
    if not complex_time:return parsed
    if client is None:
        return {"action":"clarify","reply":"这类相对时间需要AI解析；目前未配置模型，请直接写明年份和日期/月。","state":{"locations":parsed.get("state",{}).get("locations",[])}}
    rules=("解析城市白天地表温度查询，只输出JSON。action=query或clarify。query含locations数组"
           "（city中文城市名,district完整市辖区名或null）、periods数组（start/end为YYYY-MM-DD）。"
           "单月首日到末日，单日start=end，多个区域和时段各自列出，组合由程序生成。"
           "只解释用户明确提供的地点和时间及可理解的相对日期，不能猜缺少年份月份。"
           "明确指定新年份却未说月份时必须clarify，不得沿用旧完整日期。"
           "不完整时action=clarify,reply用中文问一个缺项。不能输出温度数值。")
    try:
        response=client.chat.completions.create(model=model,temperature=.1,messages=[
            {"role":"system","content":rules+"今天（Asia/Shanghai）"+datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()},
            {"role":"user","content":json.dumps({"question":text,"previous":previous},ensure_ascii=False)}])
        raw=response.choices[0].message.content
        result=json.loads(raw[raw.index('{'):raw.rindex('}')+1])
        if result.get("action")!="query":
            return {"action":"clarify","reply":str(result.get("reply") or "请写明地点和具体日期。"),"state":previous}
        plan=normalize_plan(result["locations"],result["periods"])
        plan["state"]={"locations":plan["locations"],"periods":plan["periods"]}
        return plan
    except Exception:
        return {"action":"clarify","reply":"AI暂未完成相对时间解析。请写成具体年份和日期/月后查询。","state":{"locations":previous.get("locations",[])}}
