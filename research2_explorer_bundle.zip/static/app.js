'use strict';
const $=id=>document.getElementById(id);
const state={job:null,results:[],selected:0,generation:0,sequence:Date.now()%10000000,controller:null,point:null,seen:'',mode:null,comparison:'violin'};
const colors=['#197c9b','#e28344','#7a76ac','#50a48c','#c76b84','#a18b41','#6a93c4','#648479'];
const scale=[[0,'#173f96'],[.2,'#53b8e8'],[.4,'#9fe3cb'],[.6,'#ffe68a'],[.8,'#ef754e'],[1,'#bb2847']];
const num=(v,d=2)=>v===null||v===undefined||!Number.isFinite(v)?'缺测':v.toFixed(d);
const temp=v=>v===null||v===undefined?'缺测':`${num(v)} ℃`;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;};
let map,boundary,overlay,pin,circle,pixel,imageRevision=0;

async function api(url,body,signal){
 const response=await fetch(url,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal});
 let data;try{data=await response.json();}catch{throw Error('服务器暂未返回可读取的结果。');}
 if(!response.ok){const error=Error(typeof data.detail==='string'?data.detail:`请求未完成（HTTP ${response.status}）`);error.status=response.status;throw error;}
 return data;
}
function errorMessage(text){$('errors').append(node('p',text,'error'));}
function conversation(who,text){$('conversation').append(node('p',`${who}：${text}`));}
function current(){return state.results.find(r=>r.id===state.selected);}
function clearSelection(){
 state.sequence++;if(state.controller)state.controller.abort();state.point=null;
 for(const layer of [pin,circle,pixel])if(layer&&map)map.removeLayer(layer);
 pin=circle=pixel=null;$('pointPanel').hidden=true;$('pointStatus').textContent='在左侧地图双击，可进一步查询任意位置。';
}
function stats(target,entries){
 const el=$(target);el.replaceChildren();
 for(const [title,value,detail] of entries){const item=node('div',undefined,'stat');item.append(node('span',title),node('strong',value));if(detail)item.append(node('small',detail));el.append(item);}
}
function plot(id,traces,layout={}){
 if(!window.Plotly){$(id).textContent='图表资源未加载，请刷新页面。';return;}
 return Plotly.react(id,traces,{font:{family:'Microsoft YaHei, Arial, sans-serif',size:12,color:'#354657'},
  margin:{l:65,r:22,t:20,b:65},paper_bgcolor:'#fff',plot_bgcolor:'#fff',hovermode:'closest',...layout},
  {responsive:true,displaylogo:false,toImageButtonOptions:{format:'png',filename:'temperature_chart',scale:2}});
}
function emptyPlot(id,text){plot(id,[],{xaxis:{visible:false},yaxis:{visible:false},annotations:[{text,x:.5,y:.5,xref:'paper',yref:'paper',showarrow:false,font:{color:'#657487'}}]});}
function renderImage(data,title,caption){
 $('imageTitle').textContent=title;$('imageCaption').textContent=caption;
 const revision=++imageRevision,url=data.png_url; $('temperatureImage').hidden=true;$('imageEmpty').hidden=false;$('downloadImage').hidden=!url;
 $('imageEmpty').textContent='当前范围没有可用影像，缺测位置不显示为0℃。';
 if(url){$('imageEmpty').textContent='正在加载本次影像…';
  $('temperatureImage').onload=()=>{if(revision===imageRevision){$('temperatureImage').hidden=false;$('imageEmpty').hidden=true;}};
  $('temperatureImage').onerror=()=>{if(revision===imageRevision)$('imageEmpty').textContent='本次影像暂未加载，可重试或下载PNG查看。';};
  $('temperatureImage').src=url;$('downloadImage').href=url;
 }
 else{$('temperatureImage').removeAttribute('src');$('downloadImage').removeAttribute('href');}
}
function initMap(){
 if(map)return;
 if(!window.L)throw Error('地图资源加载失败，请刷新页面。');
 map=L.map('map',{doubleClickZoom:false,tapHold:false}).setView([31.85,117.22],11);
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
 L.control.scale({imperial:false}).addTo(map);
 map.on('dblclick',event=>{if(event.originalEvent)L.DomEvent.stop(event.originalEvent);selectPoint(event.latlng);});
 // 可供自动化检查真实Leaflet事件；生产交互仍来自用户在地图任意位置双击。
 window.temperatureMap=map;
}
function renderMap(result){
 initMap();if(boundary)map.removeLayer(boundary);if(overlay)map.removeLayer(overlay);
 boundary=L.geoJSON(result.feature,{style:{color:'#197c9b',weight:2.2,fillOpacity:.025}}).addTo(map);
 overlay=result.png_url?L.imageOverlay(result.png_url,result.bounds,{opacity:.65,interactive:false}):null;
 if(overlay&&$('overlayToggle').checked)overlay.addTo(map);
 map.fitBounds(result.bounds,{padding:[18,18]});setTimeout(()=>map.invalidateSize(),60);
}
function renderCalendar(result){
 $('calendarChart').closest('article').querySelector('.caption').textContent=`${result.label} · NASA MOD11A1 V6.1 · 逐日区域均温（℃）。×表示缺测；灰色背景不代表0℃。`;
 const rows=result.daily||[];if(!rows.length)return emptyPlot('calendarChart','没有逐日记录');
 const start=new Date(rows[0].date+'T00:00:00Z'),day=86400000;
 const monday=+start-((start.getUTCDay()+6)%7)*day;
 const weeks=Math.floor((+new Date(rows.at(-1).date+'T00:00:00Z')-monday)/day/7)+1;
 const z=Array.from({length:weeks},()=>Array(7).fill(null)),text=z.map(r=>r.map(()=>'')),missing=[];
 for(const r of rows){const offset=Math.round((+new Date(r.date+'T00:00:00Z')-monday)/day),w=Math.floor(offset/7),d=offset%7;
  z[w][d]=r.mean;text[w][d]=`${r.date}<br>区域均温 ${temp(r.mean)}<br>空间覆盖率 ${num(r.coverage,1)}%`;
  if(r.mean===null)missing.push({w,d,date:r.date});}
 const weekday=['周一','周二','周三','周四','周五','周六','周日'];
 const y=Array.from({length:weeks},(_,i)=>new Date(monday+i*7*day).toISOString().slice(5,10)+' 起');
 const traces=[{type:'heatmap',x:weekday,y,z,text,hovertemplate:'%{text}<extra></extra>',hoverongaps:false,
  colorscale:scale,zmin:-20,zmax:50,xgap:3,ygap:3,colorbar:{title:{text:'℃'},thickness:10}}];
 traces.push({type:'scatter',mode:'markers',x:missing.map(r=>weekday[r.d]),y:missing.map(r=>y[r.w]),
  text:missing.map(r=>r.date+' 缺测'),marker:{symbol:'x',size:9,color:'#a9b1b8'},showlegend:false,hovertemplate:'%{text}<extra></extra>'});
 plot('calendarChart',traces,{margin:{l:82,r:30,t:18,b:40},plot_bgcolor:'#f1f3f5',yaxis:{autorange:'reversed',type:'category'},xaxis:{side:'top'}});
}
function kde(values){
 const xs=values.filter(Number.isFinite);if(xs.length<20)return null;
 const mean=xs.reduce((a,b)=>a+b,0)/xs.length,sd=Math.sqrt(xs.reduce((a,b)=>a+(b-mean)**2,0)/(xs.length-1));
 if(sd<.00001)return null;
 const h=Math.max(.12,1.06*sd*Math.pow(xs.length,-.2));
 const min=Math.min(...xs),max=Math.max(...xs),x=Array.from({length:140},(_,i)=>min+(max-min)*i/139);
 const y=x.map(v=>xs.reduce((sum,s)=>sum+Math.exp(-.5*((v-s)/h)**2),0)/(xs.length*h*Math.sqrt(2*Math.PI)));
 return {x,y};
}
function renderDistribution(result){
 const samples=result.samples||[],density=kde(samples);
 $('distributionCaption').textContent=`${result.label} · NASA MOD11A1 V6.1。时段像元均值影像中的有效空间像元样本 n=${samples.length}；完整有效像元 ${result.summary.count} 个。最多3000个固定种子样本，非逐日区域均温。`;
 if(!samples.length)return emptyPlot('distributionChart','没有有效像元，不能绘制分布');
 if(density)plot('distributionChart',[{type:'scatter',x:density.x,y:density.y,mode:'lines',fill:'tozeroy',
  line:{color:'#197c9b',width:2},fillcolor:'#197c9b30',hovertemplate:'%{x:.2f}℃<br>样本密度 %{y:.3f}<extra></extra>'}],
  {xaxis:{title:{text:'白天地表温度（℃）'}},yaxis:{title:{text:'估计概率密度（1/℃）'},rangemode:'tozero'}});
 else plot('distributionChart',[{type:'scatter',mode:'markers',x:samples,y:samples.map(()=>0),marker:{color:'#197c9b',size:8},
  hovertemplate:'%{x:.2f}℃<extra>有效像元样本</extra>'}],{xaxis:{title:{text:'白天地表温度（℃）'}},yaxis:{visible:false},
  annotations:[{text:'样本较少或数值相同，仅展示真实观测点',x:.5,y:.95,xref:'paper',yref:'paper',showarrow:false}]});
}
function renderComparison(){
 const groups=state.results.filter(r=>r.samples?.length);$('comparisonPanel').hidden=state.results.length<2;
 if(state.results.length<2)return;
 if(!groups.length)return emptyPlot('comparisonChart','各组均没有有效空间样本');
 const traces=[];let description='NASA MOD11A1 V6.1白天地表温度（℃），各组使用时段合成影像中的有效空间像元样本。';
 if(state.comparison==='ridge'){
  groups.forEach((r,i)=>{const density=kde(r.samples),color=colors[i%colors.length];
   if(density){const peak=Math.max(...density.y);traces.push({type:'scatter',mode:'lines',x:[density.x[0],...density.x,density.x.at(-1)],
    y:[i,...density.y.map(v=>i+v/peak*.78),i],fill:'toself',fillcolor:color+'45',line:{color,width:1.6},name:r.label,
    text:Array(density.x.length+2).fill(`${r.label} · 样本n=${r.samples.length}`),hovertemplate:'%{text}<br>%{x:.2f}℃<extra></extra>'});}
   else traces.push({type:'scatter',mode:'markers',x:r.samples,y:r.samples.map(()=>i),name:r.label,marker:{color,size:6}});
  });
  description+=' 岭线密度按各组峰值缩放，比较形状，不表示样本数量；小样本显示真实点。';
  plot('comparisonChart',traces,{showlegend:false,xaxis:{title:{text:'白天地表温度（℃）'}},
   yaxis:{tickvals:groups.map((_,i)=>i),ticktext:groups.map(r=>r.label),range:[-.3,groups.length]},margin:{l:200,r:25,t:15,b:55}});
 }else{
  groups.forEach((r,i)=>{const density=kde(r.samples),type=state.comparison==='violin'&&density?'violin':'box';
   traces.push({type,orientation:'h',x:r.samples,y:r.samples.map(()=>r.label),name:r.label,
    box:{visible:true},meanline:{visible:true},spanmode:'hard',points:false,boxpoints:false,
    marker:{color:colors[i%colors.length]},line:{color:colors[i%colors.length]},hoverinfo:'all'});});
  plot('comparisonChart',traces,{showlegend:false,xaxis:{title:{text:'白天地表温度（℃）'}},yaxis:{type:'category'},margin:{l:200,r:25,t:15,b:55}});
  description+=' 样本不足或全部相同的组使用箱线/真实观测，不强行估计小提琴密度。';
 }
 $('comparisonCaption').textContent=description+' '+groups.map(r=>`${r.label}：n=${r.samples.length}，覆盖率${num(r.summary.coverage,1)}%`).join('；');
 document.querySelectorAll('[data-chart]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chart===state.comparison)));
}
function renderDailyTrend(result){
 plot('dailyTrendChart',[{type:'scatter',mode:'lines+markers',x:result.daily.map(r=>r.date),y:result.daily.map(r=>r.mean),
  connectgaps:false,line:{color:'#197c9b'},marker:{size:5},hovertemplate:'%{x}<br>区域均温 %{y:.2f}℃<extra></extra>'}],
  {xaxis:{title:{text:'日期'}},yaxis:{title:{text:'区域均温（℃）'}}});
}
function renderTables(){
 const container=$('tables');container.replaceChildren();
 for(const result of state.results)for(const table of result.tables){
  const details=node('details',undefined,'data-table');details.append(node('summary',table.title));
  const head=node('div',undefined,'table-head');head.append(node('span',`共${table.rows.length}条记录`,'caption'));
  const link=node('a','下载本表CSV','table-download');link.href=`/api/csv/${state.job}/${result.id}?month=${table.month}`;link.download='temperature.csv';head.append(link);details.append(head);
  const scroll=node('div',undefined,'table-scroll'),el=node('table'),thead=node('thead'),tr=node('tr');
  ['日期','空间最低℃','区域均温℃','空间最高℃','有效像元','覆盖率%'].forEach(s=>tr.append(node('th',s)));thead.append(tr);el.append(thead);
  const tbody=node('tbody');for(const row of table.rows){const line=node('tr');
   for(const key of ['date','min','mean','max','count','coverage']){const value=row[key];line.append(node('td',value===null?'缺测':typeof value==='number'?(key==='count'?String(value):num(value)):value,value===null?'missing':''));}
   tbody.append(line);}el.append(tbody);scroll.append(el);details.append(scroll);container.append(details);
 }
}
function renderGallery(){
 const target=$('imageGallery');target.replaceChildren();if(state.results.length<2)return;
 for(const result of state.results){const card=node('article',undefined,'gallery-item');card.append(node('h3',result.label),node('p',`均温 ${temp(result.summary.mean)} · 覆盖率 ${num(result.summary.coverage,1)}%`,'caption'));
  if(result.png_url){const img=node('img');img.src=result.png_url;img.alt=result.label+'卫星温度图';card.append(img);}else card.append(node('p','影像缺测','caption'));
  card.append(node('p','NASA MOD11A1 V6.1 · 白天地表温度℃ · 统一色标−20至50℃','caption'));
  const button=node('button','在地图中查看／双击查询');button.type='button';button.onclick=()=>{state.selected=result.id;$('casePicker').value=String(result.id);renderCurrent();$('map').scrollIntoView({behavior:'smooth',block:'center'});};card.append(button);target.append(card);
 }
}
function renderSources(){
 $('sourceList').replaceChildren();for(const r of state.results){$('sourceList').append(node('p',`${r.label}：边界文件 ${r.boundary_file}；${r.quality}。`));}
}
function renderPointTables(data){
 const target=$('pointTables');target.replaceChildren();const byDay=new Map(data.point.daily.map(r=>[r.date,r.value]));
 const groups={};for(const row of data.neighborhood.daily)(groups[row.date.slice(0,7)]??=[]).push(row);
 for(const [month,rows] of Object.entries(groups)){
  const details=node('details',undefined,'data-table');details.append(node('summary',`查看更多：选点 ${data.longitude.toFixed(5)}, ${data.latitude.toFixed(5)} · ${month} · 逐日数据`));
  const link=node('a','下载本表CSV','table-download');link.href=`/api/point-csv/${state.job}/${data.sequence}?month=${month}`;link.download='point_temperature.csv';details.append(link);
  const scroll=node('div',undefined,'table-scroll'),table=node('table'),head=node('thead'),hr=node('tr');
  ['日期','所在像元℃','周边最低℃','周边均温℃','周边最高℃','周边有效像元','周边覆盖率%'].forEach(s=>hr.append(node('th',s)));head.append(hr);table.append(head);
  const body=node('tbody');for(const row of rows){const tr=node('tr');
   for(const value of [row.date,byDay.get(row.date),row.min,row.mean,row.max,row.count,row.coverage])tr.append(node('td',value==null?'缺测':typeof value==='number'?num(value):value,value==null?'missing':''));
   body.append(tr);}table.append(body);scroll.append(table);details.append(scroll);target.append(details);
 }
}
function renderCurrent(){
 const r=current();if(!r)return;clearSelection();$('resultTitle').textContent=r.label;
 renderMap(r);renderImage(r,'区域卫星温度图',`${r.label} · NASA MOD11A1 V6.1 · 白天地表温度（℃）${state.mode==='demo'?' · 合成演示数据':''}`);
 stats('regionStats',[['空间最低温',temp(r.summary.min)],['区域均温',temp(r.summary.mean)],['空间最高温',temp(r.summary.max)]]);
 const valid=r.daily.filter(d=>d.count>0).length;
 $('regionFootnote').textContent=`有效像元${r.summary.count}/${r.total}个，空间覆盖率${num(r.summary.coverage,1)}%；有值日期${valid}/${r.daily.length}天。时段基于逐像元有效观测均值合成；空间极值不是日内气象极值。`;
 renderCalendar(r);renderDistribution(r);renderDailyTrend(r);$('historyChart').hidden=true;$('historyStatus').textContent='';
}
function renderAnalysis(target,data){
 const prefix=target==='point'?'point':'region';
 $(prefix+'AnalysisTitle').textContent=data.kind==='model'?(prefix==='point'?'选点AI分析':'AI趋势与比较分析'):'数据概况（自动统计，非AI模型分析）';
 $(prefix+'AnalysisNotice').textContent=data.notice||'';$(prefix+'Analysis').textContent=data.text;
}
async function requestAnalysis(point=false){
 const job=state.job,gen=state.generation,seq=state.sequence,button=$(point?'retryPointAI':'retryRegionAI');
 if(!job)return;button.disabled=true;
 const target=point?'point':'region';$(target+'AnalysisNotice').textContent='正在分析真实数据，请稍候。';
 try{const data=await api('/api/analysis',{job_id:job,...(point?{sequence:seq}:{})});
  if(gen!==state.generation||job!==state.job||(point&&seq!==state.sequence))return;
  renderAnalysis(target,data);
 }catch(error){if(gen===state.generation&&(!point||seq===state.sequence))$(target+'AnalysisNotice').textContent=error.message;}
 finally{button.disabled=false;}
}
async function selectPoint(latlng){
 const r=current();if(!r||!state.job)return;
 const gen=state.generation,seq=++state.sequence,caseId=r.id,job=state.job;
 if(state.controller)state.controller.abort();state.controller=new AbortController();state.point=null;
 for(const layer of [pin,circle,pixel])if(layer)map.removeLayer(layer);
 pin=L.marker(latlng,{icon:L.divIcon({className:'selection-pin',iconSize:[17,17],iconAnchor:[8,8]})}).addTo(map);
 circle=L.circle(latlng,{radius:1000,color:'#e86c22',weight:2,fillOpacity:.035}).addTo(map);pixel=null;
 $('pointPanel').hidden=true;$('pointStatus').textContent=`正在读取双击位置 ${latlng.lng.toFixed(5)}, ${latlng.lat.toFixed(5)} 的像元与周边数据…`;
 try{
  const data=await api('/api/point',{job_id:job,case_id:caseId,longitude:latlng.lng,latitude:latlng.lat,sequence:seq},state.controller.signal);
  if(seq!==state.sequence||gen!==state.generation||state.selected!==caseId)return;
  state.point=data;$('pointPanel').hidden=false;$('pointStatus').textContent='选点数据已更新；双击其他位置可继续查询。';
  if(data.point.pixel_geometry)pixel=L.geoJSON(data.point.pixel_geometry,{style:{color:'#34495d',weight:2,dashArray:'5,4',fillOpacity:0}}).addTo(map);
  $('pointLocation').textContent=`${r.label} · 经度${data.longitude.toFixed(5)}，纬度${data.latitude.toFixed(5)} · ${data.within_selected_region?'所选区域边界内':'所选区域边界外，以点击坐标为准'}`;
  stats('pointStats',[['所在像元温度',temp(data.point.value),'原生像元，缺测不使用邻近值替代'],
   ['周边区域均温',temp(data.neighborhood.summary.mean),'以选点为中心，半径1公里'],
   ['周边空间覆盖率',`${num(data.neighborhood.summary.coverage,1)}%`,`有效像元 ${data.neighborhood.summary.count}/${data.neighborhood.total}`]]);
  $('pointFootnote').textContent=`橙色圆为半径1公里查询范围，虚线框为所在像元。周边最低${temp(data.neighborhood.summary.min)}，最高${temp(data.neighborhood.summary.max)}。点位不限制为固定地点；可选原查询区外位置，结果属于所点坐标。${state.mode==='demo'?' 当前为合成演示，虚线是示意网格。':' NASA MOD11A1 V6.1 · 白天地表温度 · ℃。'}`;
  renderImage(data.neighborhood,'选点周边卫星温度图',`${r.label} · 选点周边半径1公里 · NASA MOD11A1 V6.1 · ℃${state.mode==='demo'?' · 合成演示':''}`);
  plot('pointChart',[{type:'scatter',mode:'lines+markers',name:'所在像元',x:data.point.daily.map(d=>d.date),y:data.point.daily.map(d=>d.value),connectgaps:false,line:{color:'#e86c22'},marker:{size:5}},
   {type:'scatter',mode:'lines+markers',name:'周边圆内区域均温',x:data.neighborhood.daily.map(d=>d.date),y:data.neighborhood.daily.map(d=>d.mean),connectgaps:false,line:{color:'#197c9b'},marker:{size:4}}],
   {xaxis:{title:{text:'日期'}},yaxis:{title:{text:'白天地表温度（℃）'}},legend:{orientation:'h',y:1.15}});
  renderPointTables(data);
  $('pointAnalysis').textContent='';$('pointAnalysisNotice').textContent=$('autoAI').checked?'数据已显示，正在准备选点分析。':'可点击“重新分析选点”生成分析。';
  if($('autoAI').checked)await requestAnalysis(true);
 }catch(error){if(error.name!=='AbortError'&&seq===state.sequence&&gen===state.generation){$('pointStatus').textContent=error.message;}}
}
async function poll(job,gen){
 while(state.job===job&&state.generation===gen){
  const data=await api('/api/jobs/'+job);if(state.generation!==gen)return;
  $('progress').textContent=data.progress;
  const signature=data.results.map(r=>r.id).join(',');
  if(signature!==state.seen){
   const wasEmpty=!state.results.length;state.results=data.results;state.seen=signature;
   if(state.results.length){$('results').hidden=false;
    $('casePicker').replaceChildren(...state.results.map(r=>{const option=node('option',r.label);option.value=String(r.id);return option;}));
    if(wasEmpty||!current()){state.selected=state.results[0].id;renderCurrent();}
    $('casePicker').value=String(state.selected);renderGallery();renderTables();renderSources();renderComparison();
   }
  }
  $('errors').replaceChildren(...data.errors.map(e=>node('p',`${e.label}：${e.message}`,'error')));
  if(data.analysis)renderAnalysis('region',data.analysis);
  if(data.status==='done'){conversation('系统',data.progress+` 共${data.results.length}组结果。`);return;}
  await pause(650);
 }
}
async function submit(text){
 if(!text.trim())return;
 const gen=++state.generation;clearSelection();state.results=[];state.seen='';state.job=null;
 $('queryButton').disabled=true;$('results').hidden=true;$('errors').replaceChildren();$('progress').textContent='正在识别地点和时间…';
 $('regionAnalysis').textContent=$('autoAI').checked?'数据和图表会先显示，随后生成分析。':'本次未自动生成AI分析，可在结果中单独触发。';$('regionAnalysisNotice').textContent='';
 conversation('你',text);
 try{const data=await api('/api/query',{text,auto_ai:$('autoAI').checked});
  if(gen!==state.generation)return;
  if(data.kind==='clarify'){$('progress').textContent=data.reply;conversation('系统',data.reply);$('conversationDetails').open=true;return;}
  state.job=data.job_id;conversation('系统','已识别：'+data.labels.join('；'));await poll(state.job,gen);
 }catch(error){if(gen===state.generation){$('progress').textContent='本次查询未完成。';errorMessage(error.message);}}
 finally{if(gen===state.generation)$('queryButton').disabled=false;}
}
async function init(){
 const pointTables=node('div');pointTables.id='pointTables';$('pointPanel').append(pointTables);
 try{const status=await api('/api/status');state.mode=status.mode;$('modeTag').textContent=status.mode==='demo'?'合成数据交互演示':'真实卫星数据';$('demoBanner').hidden=status.mode!=='demo';
  if(!status.worker_configured)$('progress').textContent='服务已启动，尚未读取Worker配置。可沿用旧网页的server.env后启动真实查询。';
 }catch(error){$('modeTag').textContent='连接失败';errorMessage(error.message);}
 $('queryForm').addEventListener('submit',e=>{e.preventDefault();submit($('question').value);});
 document.querySelectorAll('[data-query]').forEach(b=>b.onclick=()=>{$('question').value=b.dataset.query;$('question').focus();});
 $('casePicker').onchange=()=>{state.selected=Number($('casePicker').value);renderCurrent();};
 $('overlayToggle').onchange=()=>{if(overlay){if($('overlayToggle').checked)overlay.addTo(map);else map.removeLayer(overlay);}};
 $('restoreRegion').onclick=()=>{const r=current();clearSelection();renderImage(r,'区域卫星温度图',`${r.label} · NASA MOD11A1 V6.1 · 白天地表温度（℃）`);};
 $('retryRegionAI').onclick=()=>requestAnalysis(false);$('retryPointAI').onclick=()=>requestAnalysis(true);
 $('resetButton').onclick=async()=>{state.generation++;state.job=null;state.results=[];clearSelection();await api('/api/reset',{});$('queryButton').disabled=false;$('results').hidden=true;$('conversation').replaceChildren();$('progress').textContent='已清空地点和时间条件，请输入新的问题。';};
 document.querySelectorAll('[data-chart]').forEach(b=>b.onclick=()=>{state.comparison=b.dataset.chart;renderComparison();});
 $('historyButton').onclick=async()=>{const r=current();if(!r)return;const gen=state.generation,id=r.id;$('historyButton').disabled=true;$('historyStatus').textContent='正在加载近十年同期数据…';
  try{const data=await api('/api/history',{job_id:state.job,case_id:r.id});if(gen!==state.generation||state.selected!==id)return;
   $('historyChart').hidden=false;plot('historyChart',[{type:'scatter',mode:'lines+markers',x:data.history.map(r=>r.year),y:data.history.map(r=>r.mean),connectgaps:false,line:{color:'#197c9b'}}],
    {xaxis:{title:{text:'年份'},dtick:1},yaxis:{title:{text:'同期区域均温（℃）'}}});$('historyStatus').textContent=data.label+' · 查询年份往前9年，共10个位置；缺测断开。';
  }catch(error){if(gen===state.generation&&state.selected===id)$('historyStatus').textContent=error.message;}finally{$('historyButton').disabled=false;}};
 $('dailyTrendDetails').addEventListener('toggle',()=>{if($('dailyTrendDetails').open){Plotly.Plots.resize($('dailyTrendChart'));if(!$('historyChart').hidden)Plotly.Plots.resize($('historyChart'));}});
 $('fullImage').onclick=()=>{if(!$('temperatureImage').hidden){$('largeImage').src=$('temperatureImage').src;$('imageDialog').showModal();}};
 $('closeImage').onclick=()=>$('imageDialog').close();
}
init();
