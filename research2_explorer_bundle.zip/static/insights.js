/* 图表用途、数据可用性与真正的配对关系分析。由主界面调用。 */
function renderTemporalChart(r){
 if(metricOf(r)==='temperature'){$('calendarChart').style.height='330px';renderTemperatureCalendar(r);$('calendarCaption').textContent='用途：按日期查看区域均温，发现偏热日期与缺测。每格是当天的区域均值；×为缺测，不是0℃。';return;}
 const rows=series(r),valid=rows.filter(row=>row.mean!=null),labels=rows.map(row=>`${row.period_start}—${row.period_end}`);
 $('calendarTitle').textContent='植被观测范围与有效数据';$('calendarCaption').textContent='用途：查看查询范围内哪些观测段有数据、NDVI是多少。绿色点为有效观测，缺测单独标明；不是每日植被图，也不把一个值铺成一大片色块。';
 $('calendarChart').style.height=Math.min(330,150+rows.length*35)+'px';
 if(!rows.length)return emptyPlot('calendarChart','所选日期内没有可用的产品选中观测。');
 plot('calendarChart',[{type:'scatter',mode:'markers+text',x:valid.map(row=>row.mean),y:valid.map(row=>`${row.period_start}—${row.period_end}`),
  text:valid.map(row=>num(row.mean,3)),textposition:valid.map(row=>row.mean>.8?'middle left':'middle right'),
  marker:{size:9,color:'#398354'},hovertemplate:'%{y}<br>NDVI %{x:.3f}<extra></extra>'}],
  {showlegend:false,xaxis:{title:{text:'NDVI（无量纲）'},range:[-.2,1]},yaxis:{type:'category',categoryarray:labels,tickvals:labels,ticktext:rows.map(row=>row.period_start.slice(5)+'—'+row.period_end.slice(5)),automargin:true},
   margin:{l:100,r:35,t:15,b:55},annotations:rows.filter(row=>row.mean==null).map(row=>({xref:'paper',x:.95,yref:'y',y:`${row.period_start}—${row.period_end}`,text:'缺测',showarrow:false,font:{color:'#89939b'}}))});
}
function renderTrendChart(id,r,pointData=null){
 const metric=metricOf(r),info=def(r),rows=pointData?series(pointData.neighborhood,metric):series(r);
 const own=pointData?series(pointData.point,metric):[],valid=rows.filter(row=>row.mean!=null),ownValid=own.filter(row=>row.value!=null);
 $(id).style.height=valid.length<3&&ownValid.length<3?'190px':'310px';
 if(!valid.length&&!ownValid.length)return emptyPlot(id,`所选范围没有有效${metric==='ndvi'?'植被观测':'温度日期'}，不生成虚假变化曲线。`);
 const sparse=Math.max(valid.length,ownValid.length)<3;
 const trace=(data,key,name,color)=>({type:'scatter',mode:sparse?'markers+text':'lines+markers',name,
   x:data.map(row=>row.date),y:data.map(row=>row[key]),text:sparse?data.map(row=>row[key]==null?'':value(row[key],r)):undefined,
   textposition:'top center',connectgaps:false,line:{color},marker:{color,size:7},hovertemplate:`%{x}<br>%{y:.3f} ${info.unit}<extra>%{fullData.name}</extra>`});
 const traces=[trace(sparse?valid:rows,'mean',pointData?'周边1公里均值':'区域均值',info.color)];
 if(pointData)traces.unshift(trace(sparse?ownValid:own,'value','所在像元','#e86c22'));
 plot(id,traces,{showlegend:Boolean(pointData),xaxis:{type:sparse?'category':'date',title:{text:metric==='ndvi'?'纳入查询范围的观测段起始日期':'日期'}},yaxis:{title:{text:info.name+'（'+info.unit+'）'},automargin:true,...(metric==='ndvi'?{range:[-.2,1]}:{})},margin:{l:65,r:25,t:sparse?35:20,b:55},
  annotations:sparse?[{text:`仅${Math.max(valid.length,ownValid.length)}个有效时点，展示观测值，不判断时间趋势`,xref:'paper',yref:'paper',x:.5,y:1.25,showarrow:false}]:[]});
}
function renderAllComparisons(){
 const rows=visible(),metric=metricOf(current()),groups=rows.filter(r=>metricOf(r)===metric&&r.samples?.length),peers=state.view==='both'?rows.filter(r=>metricOf(r)!==metric&&r.samples?.length):[];
 $('comparisonPanel').hidden=false;$('comparisonChart').style.height=Math.max(330,groups.length*65)+'px';comparisonFor(groups,'comparisonChart');$('peerComparisonChart').hidden=!peers.length;if(peers.length){$('peerComparisonChart').style.height=Math.max(330,peers.length*65)+'px';comparisonFor(peers,'peerComparisonChart');}
 const guide={violin:'小提琴图：宽处代表更多像元集中在这一数值附近，用于比较分布形状。',box:'箱线图：比较中位数、中央50%范围与离散程度；横轴是指标值，不是日期。',ridge:'岭线图：比较多个月份或区域的分布如何移动；各组峰高归一，不代表像元数量。'};
 $('comparisonCaption').textContent=guide[state.comparison]+(groups.length===1?' 当前只有一组，展示这一组的空间分布；查询多个区域或多个月份后可直接比较。':'')+' 分布来自有效空间像元，样本不足时只展示真实点／箱线。';
 document.querySelectorAll('[data-chart]').forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.chart===state.comparison));b.title=guide[b.dataset.chart];});
}
let relationshipRevision=0;
function renderRelationship(r,pointData=null){
 let coverage=$('coverageNotice');if(!coverage){coverage=node('p',undefined,'notice');coverage.id='coverageNotice';$('regionFootnote').after(coverage);}
 const vegetation=[r,peerOf(r)].find(item=>item&&metricOf(item)==='ndvi');
 coverage.hidden=!vegetation||vegetation.summary.coverage>=30;
 coverage.textContent=vegetation?`本次NDVI有效覆盖率为${num(vegetation.summary.coverage,1)}%。覆盖较少时，统计和关系图只代表有效观测区域；影像空白为缺测，不能当成全区完整植被情况。`:'';
 let panel=$('relationshipPanel');
 if(!panel){panel=node('section',undefined,'section-block');panel.id='relationshipPanel';panel.innerHTML='<div class="panel-heading"><h2>温度与植被分布的关系</h2><button id="queryRelationship" type="button">分析当前范围的关系</button></div><p id="relationshipNotice" class="caption"></p><div id="relationshipContent" hidden><div id="relationshipStats" class="stats"></div><div class="chart-grid"><article><h3>NDVI—温度散点与拟合</h3><p class="caption">每个点是同一温度网格中的一对有效数值。横轴越右NDVI越高，纵轴越高温度越高；拟合线只描述这组样本。</p><div id="relationshipScatter" class="chart"></div></article><article><h3>不同NDVI水平的温度箱线图</h3><p class="caption">按NDVI从低到高将同一批配对网格分四组，查看温度分布是否随植被指数变化。</p><div id="relationshipBox" class="chart"></div></article></div><details><summary>查看高低NDVI与高低温的空间分布图</summary><img id="relationshipImage" alt="以配对样本中位数划分的NDVI和温度组合分布" hidden><p class="caption">蓝灰：低NDVI／低温；橙：低NDVI／高温；绿：高NDVI／低温；黄绿：高NDVI／高温。高低以本次有效配对样本的中位数划分，不是生态质量等级。</p></details></div>';
  $('chartGrid').before(panel);$('queryRelationship').onclick=()=>switchMetric('both');}
 const source=metricOf(r)==='temperature'?r:peerOf(r),data=pointData?.relationship||(!pointData?source?.relationship:null),revision=++relationshipRevision;
 $('queryRelationship').hidden=state.view==='both';$('relationshipContent').hidden=!data;
 if(!data){$('relationshipNotice').textContent=pointData?.relationship_error||source?.relationship_error||(state.view==='both'?'关系计算中；已完成的影像和数据仍可查看。':'选择“分析当前范围的关系”，将对同一地区、时段的温度与NDVI计算配对关系。');return;}
 const n=data.sample_count||0,ready=data.status==='ready';
 $('relationshipNotice').textContent=(state.mode==='demo'?'合成演示，不能作为真实研究结论。 ':'')+(ready?`本次${n}个配对样本中，NDVI与温度呈${data.pearson_r<0?'负向':'正向'}空间关联（r=${num(data.pearson_r,3)}）。`:'')+data.note+(ready?'':` 仅${n}个配对样本，或样本值缺少变化，不足以判断稳定关系；可返回区域查看更大范围。`);
 stats('relationshipStats',[['有效配对样本',String(n),'同一温度原生网格、共同有效像元'],['Pearson r',ready?num(data.pearson_r,3):'样本不足','只描述空间关联，不代表因果'],['拟合变化率',ready?num(data.slope_c_per_ndvi,2)+' ℃/NDVI':'不拟合','不是植被降温效果估计']]);
 const pairs=data.pairs||[],traces=[{type:'scattergl',mode:'markers',x:pairs.map(p=>p.ndvi),y:pairs.map(p=>p.temperature),marker:{size:5,color:'#197c9b',opacity:.55},name:'配对网格',hovertemplate:'NDVI %{x:.3f}<br>温度 %{y:.2f}℃<extra></extra>'}];
 if(ready){const x=[Math.min(...pairs.map(p=>p.ndvi)),Math.max(...pairs.map(p=>p.ndvi))];traces.push({type:'scatter',mode:'lines',x,y:x.map(v=>data.intercept_c+data.slope_c_per_ndvi*v),line:{color:'#c6723e'},name:'样本拟合'});}
 if(n)plot('relationshipScatter',traces,{xaxis:{title:{text:'NDVI（无量纲）'}},yaxis:{title:{text:'白天地表温度（℃）'}},legend:{orientation:'h',y:1.15}});else emptyPlot('relationshipScatter','没有共同有效的配对网格，不编造关系点。');
 const bins=data.bins||[];$('relationshipBox').style.height=bins.length?'330px':'170px';
 if(bins.length)plot('relationshipBox',bins.map((b,i)=>({type:'box',name:b.label,y:b.temperatures,boxpoints:false,marker:{color:colors[i]},showlegend:false})),{xaxis:{title:{text:'按NDVI排序的四组配对样本'}},yaxis:{title:{text:'白天地表温度（℃）'}},margin:{l:65,r:20,t:20,b:95}});
 else emptyPlot('relationshipBox','少于20个有效配对样本，不强行分组画箱线。');
 $('relationshipImage').hidden=true;if(data.png_url){$('relationshipImage').onload=()=>{if(revision===relationshipRevision)$('relationshipImage').hidden=false;};$('relationshipImage').src=data.png_url;}
}
