/* 图表用途、数据可用性与真正的配对关系分析。由主界面调用。 */
// 单月详情与跨月总览共用原始结果；总览必须包含尚在读取／失败的请求月份。
function collectTimeline(cases,results,metric,errors=[],finished=false){
 const key=q=>q.start+'|'+q.end,queries=[...new Map(cases.map(q=>[key(q),q])).values()].sort((a,b)=>a.start.localeCompare(b.start));
 const byPeriod=new Map(results.map(r=>[key(r.query),r])),failed=new Set(errors.map(e=>e.id));
 const periods=queries.map(q=>{const result=byPeriod.get(key(q));return {query:q,result,status:result?(Number.isFinite(result.summary.mean)?'ready':'missing'):failed.has(q.id)||finished?'error':'pending'};});
 const unique=new Map();
 for(const p of periods)if(p.result)for(const row of series(p.result,metric)){
  if(row.date<p.query.start||row.date>p.query.end)continue;
  const id=metric==='ndvi'?row.date+'|'+row.period_end:row.date;
  if(!unique.has(id)||!Number.isFinite(unique.get(id).mean))unique.set(id,{...row,status:Number.isFinite(row.mean)?'ready':'missing'});
 }
 const observations=[...unique.values()].sort((a,b)=>a.date.localeCompare(b.date)),start=queries[0]?.start,end=queries.map(q=>q.end).sort().at(-1);
 let rows=observations,expectedDays=0;
 if(metric==='temperature'&&start&&end){
  rows=[];const days=new Map(observations.map(row=>[row.date,row]));
  for(let t=Date.parse(start+'T00:00:00Z');t<=Date.parse(end+'T00:00:00Z');t+=86400000){
   const date=new Date(t).toISOString().slice(0,10),period=periods.find(p=>date>=p.query.start&&date<=p.query.end);
   if(period)expectedDays++;
   rows.push(days.get(date)||{date,mean:null,status:!period?'unqueried':period.status==='ready'?'missing':period.status});
  }
 }else if(metric==='ndvi'){
  rows=[...observations];
  for(const p of periods)if(!p.result||!series(p.result,metric).length)rows.push({date:p.query.start,period_start:p.query.start,period_end:p.query.end,mean:null,status:p.status==='ready'?'missing':p.status,placeholder:true});
  rows.sort((a,b)=>a.date.localeCompare(b.date));
  const withGaps=[];
  for(const row of rows){const prev=withGaps.at(-1);if(prev&&Date.parse(row.date)-Date.parse(prev.period_end||prev.date)>86400000)withGaps.push({date:new Date(Date.parse(prev.period_end||prev.date)+86400000).toISOString().slice(0,10),mean:null,status:'unqueried'});withGaps.push(row);}
  rows=withGaps;
 }
 return {periods,rows,observations,start,end,expectedDays,valid:observations.filter(row=>Number.isFinite(row.mean)).length,
  products:new Set(observations.map(row=>row.source_period_start).filter(Boolean)).size};
}
let timelineJob=null;
function arrangeResults(){
 const queries=state.cases.length?state.cases:state.results.map(r=>r.query);
 const groups=new Set(queries.map(q=>JSON.stringify([q.city,q.district,q.start,q.end])));
 const multi=groups.size>1;$('overallVisuals').hidden=!multi;
 const destination=$(multi?'overallComparisons':'singlePeriodComparisons');
 if($('comparisonPanel').parentElement!==destination)destination.append($('comparisonPanel'));
 $('selectedPeriodNote').hidden=!multi;
 return multi;
}
function renderPeriodAnalyses(){
 const groups=(state.summary?.groups||[]).filter(g=>state.view==='both'||g.metrics[state.view]);
 $('periodAnalyses').replaceChildren();$('periodAnalysisDetails').hidden=!groups.length;
 const both=state.view==='both';$('periodAnalysisSummary').textContent=(both?'按月／时段查看温度与植被的联合解读':'按月／时段查看'+definitions[state.view].short+'解读')+`（${groups.length}组）`;
 const scope=state.analysis?.scope_metrics||[],modelScope=both?scope.length===2:scope.length===1&&scope[0]===state.view;
 const model=new Map((modelScope?state.analysis?.period_analyses||[]:[]).map(p=>[p.id,p]));
 for(const group of groups){
  const detail=node('details',undefined,'period-analysis'),summary=node('summary',group.label),entry=model.get(group.id);
  summary.append(node('span',entry?'AI解读':'自动统计','tag'));detail.append(summary,node('p',entry?.text||(both?group.text:group.by_metric?.[state.view])||'该时段尚未取得足够数据。','analysis-text'));
  $('periodAnalyses').append(detail);
 }
}
function renderQueryTimeline(){
 const selected=current();if(!selected)return;const multiQuery=arrangeResults();
 const sameLocation=q=>q.city===selected.query.city&&(q.district||'')===(selected.query.district||'');
 const cases=(state.cases.length?state.cases:state.results.map(r=>({...r.query,id:r.id}))).filter(sameLocation);
 const periods=[...new Set(cases.map(q=>q.start+'|'+q.end))];
 const multi=periods.length>1||cases.some(q=>q.start.slice(0,7)!==q.end.slice(0,7));
 $('annualOverview').hidden=!multi;
 $('selectedTrendSummary').textContent='查看更多：'+selected.label+' · 观测与历史数据';
 $('selectedTrendCaption').textContent='这里是当前选中时段的观测记录；缺测保留。上方整体图表汇总本次查询的全部时段。';
 $('historyButton').textContent='加载当前所选时段的近十年同期数据';
 if(timelineJob!==state.job){timelineJob=state.job;$('dailyTrendDetails').open=false;}
 if(multiQuery)$('selectedPeriodNote').textContent='选择一个月份或时段，查看对应影像、统计和空间关系。整体变化图保留在上方。';
 if(!multi)return;
 const start=cases.map(q=>q.start).sort()[0],end=cases.map(q=>q.end).sort().at(-1),year=start.slice(0,4);
 const location=selected.query.city+(selected.query.district||'全市');
 $('timelineTitle').textContent=start===year+'-01-01'&&end===year+'-12-31'?year+'年全年变化':'本次查询的全部时段';
 $('timelineScope').textContent=`${selected.scope==='point'?'选点周边1公里 · ':''}${location} · ${start}—${end}`;
 $('timelineStatus').replaceChildren();const draws=[];
 for(const metric of ['temperature','ndvi']){
  const metricCases=cases.filter(q=>metricOf(q)===metric),active=(state.view==='both'||state.view===metric)&&metricCases.length;
  $(metric+'MonthlyArticle').hidden=!active;if(!active)continue;
  const data=collectTimeline(metricCases,state.results.filter(r=>sameLocation(r.query)&&metricOf(r)===metric),metric,state.errors,state.finished),info=definitions[metric];
  const read=data.periods.filter(p=>p.result).length,failed=data.periods.filter(p=>p.status==='error').length,pending=data.periods.filter(p=>p.status==='pending').length;
  const status=node('div',undefined,'timeline-metric-status');
  const count=metric==='temperature'?`${data.valid}/${data.expectedDays}天有值`:`${data.valid}/${data.observations.length}个观测段有值`;
  status.append(node('strong',info.short+'：'),node('span',`${read}/${data.periods.length}个时段已读取；${count}${pending?'，'+pending+'个时段读取中':''}${failed?'，'+failed+'个读取失败':''}。`));$('timelineStatus').append(status);
  const mode=state.timelineModes[metric]||'monthly',monthly=data.periods.every(p=>p.query.start.endsWith('-01')&&p.query.start.slice(0,7)===p.query.end.slice(0,7));
  $(metric+'MonthlyTitle').textContent=location+' · '+info.short+'变化';
  document.querySelectorAll(`[data-series-metric="${metric}"]`).forEach(button=>{button.setAttribute('aria-pressed',String(button.dataset.seriesMode===mode));if(button.dataset.seriesMode==='monthly')button.textContent=monthly?'月度均值':'时段均值';});
  const statuses={ready:'有值',missing:'缺测',pending:'读取中',error:'读取失败',unqueried:'未查询'};
  let traces,axis,missing;
  const compact=window.innerWidth<600;
  if(mode==='monthly'){
   const labels=data.periods.map(p=>monthly?p.query.start.slice(0,7):p.query.start+(p.query.start===p.query.end?'':'—'+p.query.end));
   const means=data.periods.map(p=>p.status==='ready'?p.result.summary.mean:null);
   traces=[{type:'scatter',mode:'lines+markers',name:info.short+'时段均值',x:labels,y:means,connectgaps:false,line:{color:info.color},marker:{size:7},customdata:data.periods.map(p=>p.query.start+'—'+p.query.end),hovertemplate:`%{customdata}<br>均值 %{y:.3f} ${info.unit}<extra></extra>`}];
   missing=labels.map((label,i)=>({date:label,status:data.periods[i].status,mean:means[i]})).filter(row=>row.mean===null);
   const step=compact?Math.max(1,Math.ceil(labels.length/4)):1;
   const ticks=labels.filter((_,i)=>i%step===0||i===labels.length-1),shortMonth=monthly&&start.slice(0,4)===end.slice(0,4);
   axis={type:'category',categoryorder:'array',categoryarray:labels,tickmode:'array',tickvals:ticks,ticktext:ticks.map(label=>shortMonth?Number(label.slice(5,7))+'月':label),tickangle:shortMonth?0:-35,automargin:true,tickfont:{size:11}};
   $(metric+'SeriesCaption').textContent=info.product+'。用途：比较各查询时段的区域平均'+(metric==='temperature'?'地表温度，查看冷暖变化。切换“逐日观测”可在这张图中查看每天的变化与缺测。':'NDVI，查看植被指数变化。切换“实际观测段”可查看更细的观测记录；NDVI不是植被覆盖百分比。');
  }else{
   traces=[{type:'scatter',mode:data.valid<3?'markers':'lines+markers',name:info.short+'有效观测',x:data.rows.map(row=>row.date),y:data.rows.map(row=>row.mean),customdata:data.rows.map(row=>metric==='ndvi'?(row.period_start||row.date)+'—'+(row.period_end||row.date):row.date),connectgaps:false,line:{color:info.color,width:1.6},marker:{size:metric==='ndvi'?6:4},hovertemplate:`%{customdata}<br>%{y:.3f} ${info.unit}<extra></extra>`}];
   missing=data.rows.filter(row=>!Number.isFinite(row.mean));
   const months=(Number(end.slice(0,4))-Number(year))*12+Number(end.slice(5,7))-Number(start.slice(5,7)),ticks=[];
   for(let month=0;month<=months;month+=compact?3:1){const date=new Date(Date.UTC(Number(year),Number(start.slice(5,7))-1+month,1)).toISOString().slice(0,10);if(date>=start&&date<=end)ticks.push(date);}
   axis={type:'date',range:[start+'T00:00:00',end+'T23:59:59'],...(months>1?{tickmode:'array',tickvals:ticks,ticktext:ticks.map(date=>start.slice(0,4)===end.slice(0,4)?Number(date.slice(5,7))+'月':date.slice(0,7)),tickangle:0,tickfont:{size:11}}:{})};
   $(metric+'SeriesCaption').textContent=info.product+'。用途：'+(metric==='temperature'?`查看全部月份的逐日区域均温。当前${data.valid}天有值，缺测处断开；连线连接观测值，不是预测或拟合。`:`查看全部月份的实际NDVI观测段。当前${data.valid}段有值；16天源产品按查询月份内的实际观测筛选，跨月产品可能分段。连线表示观测变化，不复制为每日数据。`);
  }
  if(missing.length)traces.push({type:'scatter',mode:'markers',name:'缺测／未取得',x:missing.map(row=>row.date),y:missing.map(()=>.04),yaxis:'y2',customdata:missing.map(row=>statuses[row.status]||'缺测'),marker:{symbol:'line-ns-open',size:6,color:'#9da9af'},hovertemplate:'%{x} %{customdata}<extra></extra>'});
  draws.push(plot(metric+'MonthlyChart',traces,{showlegend:Boolean(missing.length),legend:{orientation:'h',y:1.16},xaxis:axis,yaxis:{title:{text:info.unit},...(metric==='ndvi'?{range:[-.2,1]}:{})},yaxis2:{overlaying:'y',range:[0,1],visible:false,fixedrange:true},margin:{l:55,r:20,t:missing.length?40:20,b:75},autosize:true}));
 }
 Promise.all(draws).then(()=>requestAnimationFrame(()=>{for(const metric of ['temperature','ndvi']){const chart=$(metric+'MonthlyChart');if(chart.offsetParent&&chart.data)Plotly.Plots.resize(chart);}}));
}
function renderTemporalChart(r){
 if(metricOf(r)==='temperature'){$('calendarChart').style.height='330px';renderTemperatureCalendar(r);$('calendarCaption').textContent='用途：按日期查看区域均温，发现偏热日期与缺测。每格是当天的区域均值；×为缺测，不是0℃。';return;}
 const rows=series(r),valid=rows.filter(row=>row.mean!=null),labels=rows.map(row=>`${row.period_start}—${row.period_end}`);
 $('calendarTitle').textContent='植被观测范围与有效数据';$('calendarCaption').textContent='用途：查看查询范围内哪些观测段有数据、NDVI是多少。绿色点为有效观测，缺测单独标明；不是每日植被图，也不把一个值铺成一大片色块。';
 $('calendarChart').style.height=Math.min(330,150+rows.length*35)+'px';
 if(!rows.length)return emptyPlot('calendarChart','所选日期内没有可用的产品选中观测。');
 plot('calendarChart',[{type:'scatter',mode:'markers+text',x:valid.map(row=>row.mean),y:valid.map(row=>`${row.period_start}—${row.period_end}`),
  text:valid.map(row=>num(row.mean,3)),textposition:valid.map(row=>row.mean>.8?'middle left':'middle right'),
  marker:{size:9,color:'#398354'},hovertemplate:'%{y}<br>NDVI %{x:.3f}<extra></extra>'}],
  {showlegend:false,xaxis:{title:{text:'NDVI（无量纲）'},range:[-.2,1]},yaxis:{type:'category',categoryarray:labels,tickvals:labels,ticktext:rows.map(row=>row.period_start.slice(5)+'—'+row.period_end.slice(5)),automargin:true},
   margin:{l:100,r:35,t:15,b:55},annotations:rows.filter(row=>row.mean==null).map(row=>({xref:'paper',x:.95,yref:'y',y:`${row.period_start}—${row.period_end}`,text:'缺测',showarrow:false,font:{color:'#89939b'}}))});
}
function renderTrendChart(id,r,pointData=null){
 const metric=metricOf(r),info=def(r),rows=pointData?series(pointData.neighborhood,metric):series(r);
 const own=pointData?series(pointData.point,metric):[],valid=rows.filter(row=>row.mean!=null),ownValid=own.filter(row=>row.value!=null);
 $(id).style.height=valid.length<3&&ownValid.length<3?'190px':'310px';
 if(!valid.length&&!ownValid.length)return emptyPlot(id,`所选范围没有有效${metric==='ndvi'?'植被观测':'温度日期'}，不生成虚假变化曲线。`);
 const sparse=Math.max(valid.length,ownValid.length)<3;
 const trace=(data,key,name,color)=>({type:'scatter',mode:sparse?'markers+text':'lines+markers',name,
   x:data.map(row=>row.date),y:data.map(row=>row[key]),text:sparse?data.map(row=>row[key]==null?'':value(row[key],r)):undefined,
   textposition:'top center',connectgaps:false,line:{color},marker:{color,size:7},hovertemplate:`%{x}<br>%{y:.3f} ${info.unit}<extra>%{fullData.name}</extra>`});
 const traces=[trace(sparse?valid:rows,'mean',pointData?'周边1公里均值':'区域均值',info.color)];
 if(pointData)traces.unshift(trace(sparse?ownValid:own,'value','所在像元','#e86c22'));
 plot(id,traces,{showlegend:Boolean(pointData),xaxis:{type:sparse?'category':'date',title:{text:metric==='ndvi'?'纳入查询范围的观测段起始日期':'日期'}},yaxis:{title:{text:info.name+'（'+info.unit+'）'},automargin:true,...(metric==='ndvi'?{range:[-.2,1]}:{})},margin:{l:65,r:25,t:sparse?35:20,b:55},
  annotations:sparse?[{text:`仅${Math.max(valid.length,ownValid.length)}个有效时点，展示观测值，不判断时间趋势`,xref:'paper',yref:'paper',x:.5,y:1.25,showarrow:false}]:[]});
}
function renderAllComparisons(){
 const rows=visible(),metric=metricOf(current()),groups=rows.filter(r=>metricOf(r)===metric&&r.samples?.length),peers=state.view==='both'?rows.filter(r=>metricOf(r)!==metric&&r.samples?.length):[];
 $('comparisonPanel').hidden=false;$('peerComparisonChart').hidden=!peers.length;$('peerComparisonArticle').hidden=!peers.length;
 const draws=[comparisonFor(groups,'comparisonChart')];if(peers.length)draws.push(comparisonFor(peers,'peerComparisonChart'));
 Promise.all(draws).then(()=>requestAnimationFrame(()=>{for(const id of ['comparisonChart','peerComparisonChart'])if($(id).data&&$(id).offsetParent)Plotly.Plots.resize($(id));}));
 const guide={violin:'小提琴图：宽处代表更多像元集中在这一数值附近，用于比较分布形状。',box:'箱线图：比较中位数、中央50%范围与离散程度；横轴是指标值，不是日期。',ridge:'岭线图：比较多个月份或区域的分布如何移动；各组峰高归一，不代表像元数量。'};
 $('comparisonCaption').textContent=guide[state.comparison]+(groups.length===1?' 当前只有一组，展示这一组的空间分布；查询多个区域或多个月份后可直接比较。':'')+' 分布来自有效空间像元，样本不足时只展示真实点／箱线。';
 document.querySelectorAll('[data-chart]').forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.chart===state.comparison));b.title=guide[b.dataset.chart];});
}
let relationshipRevision=0;
function renderRelationship(r,pointData=null){
 let coverage=$('coverageNotice');if(!coverage){coverage=node('p',undefined,'notice');coverage.id='coverageNotice';$('regionFootnote').after(coverage);}
 const vegetation=[r,peerOf(r)].find(item=>item&&metricOf(item)==='ndvi');
 coverage.hidden=!vegetation||vegetation.summary.coverage>=30;
 coverage.textContent=vegetation?`本次NDVI有效覆盖率为${num(vegetation.summary.coverage,1)}%。覆盖较少时，统计和关系图只代表有效观测区域；影像空白为缺测，不能当成全区完整植被情况。`:'';
 let panel=$('relationshipPanel');
 if(!panel){panel=node('section',undefined,'section-block');panel.id='relationshipPanel';panel.innerHTML='<div class="panel-heading"><h2>温度与植被分布的关系</h2><button id="queryRelationship" type="button">分析当前范围的关系</button></div><p id="relationshipNotice" class="caption"></p><div id="relationshipContent" hidden><div id="relationshipStats" class="stats"></div><div class="chart-grid"><article><h3>NDVI—温度散点与拟合</h3><div id="relationshipScatter" class="chart"></div><p id="relationshipScatterHelp" class="chart-help">用途：查看植被指数较高的网格，温度是否也偏高或偏低。每个蓝点是一对同网格观测；橙色直线概括这些点的线性关系。线向上／向下表示正向／负向关联，点很分散时关系较弱。这是空间关系图，不是时间趋势或预测。</p></article><article><h3>不同NDVI水平的温度箱线图</h3><div id="relationshipBox" class="chart"></div><p id="relationshipBoxHelp" class="chart-help">用途：把同一批网格按NDVI从低到高分成四组，比较各组的典型温度和离散程度。箱内横线是中位数，箱体包含中央50%的温度值。若各组箱子差别很小，说明分组后的温度差异较小；这不是植被降温效果。</p><p id="relationshipBinRanges" class="caption"></p></article></div><details><summary>查看配对与统计口径</summary><p id="relationshipMethodNote" class="caption"></p></details><details><summary>查看高低NDVI与高低温的空间分布图</summary><img id="relationshipImage" alt="以配对样本中位数划分的NDVI和温度组合分布" hidden><p class="caption">蓝灰：低NDVI／低温；橙：低NDVI／高温；绿：高NDVI／低温；黄绿：高NDVI／高温。高低以本次有效配对样本的中位数划分，不是生态质量等级。</p></details></div>';
  $('chartGrid').before(panel);$('queryRelationship').onclick=()=>switchMetric('both');}
 panel.querySelector('h2').textContent='当前时段的温度与植被关系';
 const source=metricOf(r)==='temperature'?r:peerOf(r),data=pointData?.relationship||(!pointData?source?.relationship:null),revision=++relationshipRevision;
 $('queryRelationship').hidden=state.view==='both';$('relationshipContent').hidden=!data;
 if(!data){$('relationshipNotice').textContent=pointData?.relationship_error||source?.relationship_error||(state.view==='both'?'关系计算中；已完成的影像和数据仍可查看。':'选择“分析当前范围的关系”，将对同一地区、时段的温度与NDVI计算配对关系。');return;}
 const n=data.sample_count||0,ready=data.status==='ready';
 $('relationshipNotice').textContent=r.label+(pointData?' · 选点周边1公里。':'。')+(state.mode==='demo'?'合成演示，不能作为真实研究结论。 ':'')+(ready?`本次${n}个配对样本中，NDVI与温度呈${data.pearson_r<0?'负向':'正向'}空间关联（r=${num(data.pearson_r,3)}）。`:'')+(ready?'':` 仅${n}个配对样本，或样本值缺少变化，不足以判断稳定关系；可返回区域查看更大范围。`);
 $('relationshipMethodNote').textContent=data.note||'同一查询时段内，将NDVI聚合到温度原生网格后，取共同有效样本。';
 stats('relationshipStats',[['有效配对样本',String(n),'同一温度原生网格、共同有效像元'],['Pearson r',ready?num(data.pearson_r,3):'样本不足','只描述空间关联，不代表因果'],['拟合变化率',ready?num(data.slope_c_per_ndvi,2)+' ℃/NDVI':'不拟合','不是植被降温效果估计']]);
 const pairs=data.pairs||[],traces=[{type:'scattergl',mode:'markers',x:pairs.map(p=>p.ndvi),y:pairs.map(p=>p.temperature),marker:{size:5,color:'#197c9b',opacity:.55},name:'配对网格',hovertemplate:'NDVI %{x:.3f}<br>温度 %{y:.2f}℃<extra></extra>'}];
 if(ready){const x=[Math.min(...pairs.map(p=>p.ndvi)),Math.max(...pairs.map(p=>p.ndvi))];traces.push({type:'scatter',mode:'lines',x,y:x.map(v=>data.intercept_c+data.slope_c_per_ndvi*v),line:{color:'#c6723e'},name:'样本拟合'});}
 if(n)plot('relationshipScatter',traces,{xaxis:{title:{text:'NDVI（无量纲）'}},yaxis:{title:{text:'白天地表温度（℃）'}},legend:{orientation:'h',y:1.15}});else emptyPlot('relationshipScatter','没有共同有效的配对网格，不编造关系点。');
 const bins=data.bins||[];$('relationshipBox').style.height=bins.length?'330px':'170px';
 $('relationshipBinRanges').textContent=bins.map(b=>b.label).join('；');
 if(bins.length)plot('relationshipBox',bins.map((b,i)=>({type:'box',name:'第'+(i+1)+'组',y:b.temperatures,boxpoints:false,marker:{color:colors[i]},showlegend:false,hoverinfo:'y+name'})),{xaxis:{title:{text:'NDVI从低到高 →'},tickvals:bins.map((_,i)=>'第'+(i+1)+'组'),ticktext:['1（低）','2','3','4（高）']},yaxis:{title:{text:'白天地表温度（℃）'}},margin:{l:60,r:15,t:20,b:60}});
 else emptyPlot('relationshipBox','少于20个有效配对样本，不强行分组画箱线。');
 $('relationshipImage').hidden=true;if(data.png_url){$('relationshipImage').onload=()=>{if(revision===relationshipRevision)$('relationshipImage').hidden=false;};$('relationshipImage').src=data.png_url;}
}
