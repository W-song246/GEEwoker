"""每个指标独立的数据产品、单位和时间口径。"""
METRICS = {
    'temperature': {'name': '白天地表温度', 'short': '温度', 'unit': '℃',
                    'dataset': 'MODIS/061/MOD11A1', 'product': 'NASA MOD11A1 V6.1',
                    'resolution_m': 1000, 'cadence': '每日', 'minimum': -20, 'maximum': 50},
    'ndvi': {'name': '植被指数 NDVI', 'short': '植被指数', 'unit': 'NDVI（无量纲）',
             'dataset': 'MODIS/061/MOD13Q1', 'product': 'NASA MOD13Q1 V6.1',
             'resolution_m': 250, 'cadence': '16天合成', 'minimum': -.2, 'maximum': 1},
}


def metric_of(data):
    return data.get('metric', data.get('query', {}).get('metric', 'temperature'))


def rows_of(data, metric=None):
    return data.get('observations', []) if (metric or metric_of(data)) == 'ndvi' else data.get('daily', [])


def definition(data):
    return METRICS[metric_of(data)]
