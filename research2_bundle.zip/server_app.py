"""服务器上的第二个独立网页，不连接 Colab，也不在本机初始化 GEE。"""

import os
from pathlib import Path

from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / "server.env", override=True)
os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")
os.environ.setdefault("MPLBACKEND", "Agg")

import research2_simple_ai as ui
from remote_backend import RemoteBackend
from zhipuai import ZhipuAI


def main():
    key = os.getenv("ZHIPU_API_KEY", "").strip()
    client = ZhipuAI(api_key=key, timeout=25, max_retries=0) if key else None
    ui.MODEL = os.getenv("ZHIPU_MODEL", ui.MODEL).strip()
    backend = RemoteBackend(os.getenv("GEE_WORKER_URL", "https://geewoker.onrender.com"),
                            os.getenv("WORKER_TOKEN", ""))
    app = ui.make_interface(client, backend=backend)
    app.queue(default_concurrency_limit=1, max_size=8).launch(
        share=False, server_name="0.0.0.0", server_port=int(os.getenv("PORT", "7861")),
        ssr_mode=False, show_error=False)


if __name__ == "__main__":
    main()
