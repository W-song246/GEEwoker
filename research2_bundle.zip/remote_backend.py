"""把服务器网页的取数请求交给 Render；所有地图像素也通过服务器返回。"""

import base64
import os
from html import escape
from io import BytesIO
from pathlib import Path

import folium
import requests
from branca.colormap import LinearColormap
from PIL import Image


SCHEMA = "city-boundary-temperature-v1"
PALETTE = ["173f96", "53b8e8", "9fe3cb", "ffe68a", "ef754e", "bb2847"]


class RemoteBackend:
    def __init__(self, url, token):
        self.url = url.rstrip("/")
        self.token = token.strip()

    def request(self, path, payload):
        if not self.token:
            raise ValueError("新版尚未配置取数口令，请检查 server.env 中的 WORKER_TOKEN。")
        try:
            response = requests.post(self.url + path, json=payload,
                                     headers={"Authorization": "Bearer " + self.token},
                                     timeout=(15, 240))
        except requests.Timeout:
            raise ValueError("取数服务等待超时，已显示的结果仍可查看；请稍后重试。") from None
        except requests.RequestException:
            raise ValueError("暂时无法连接 Render 取数服务，请检查网络后重试。") from None
        if response.status_code == 401:
            raise ValueError("取数口令不匹配，请检查服务器的 WORKER_TOKEN。")
        if response.status_code == 429:
            raise ValueError("卫星取数服务正在处理另一项查询，请稍后再试。")
        if response.status_code == 404:
            raise ValueError("Render 尚未更新城市边界接口，请先完成取数服务部署。")
        if response.status_code != 200:
            try:
                detail = response.json().get("detail")
            except ValueError:
                detail = None
            if response.status_code == 422 and isinstance(detail, str):
                raise ValueError(detail)
            raise ValueError(f"取数服务暂未完成查询（HTTP {response.status_code}），请稍后再试。")
        result = response.json()
        if result.get("schema") != SCHEMA:
            raise ValueError("取数服务返回了不同版本的数据，请检查部署版本。")
        return result

    def boundary(self, city, district=None):
        data = self.request("/research2/boundary", {"city": city, "district": district})
        return data["feature"], data["boundary_file"]

    def operation(self, query, name):
        payload = {"city": query["city"], "district": query.get("district"),
                   "start": query["start"].isoformat(),
                   "end": query["end"].isoformat(), "operation": name}
        data = self.request("/research2/query", payload)
        if (data.get("dataset") != "MODIS/061/MOD11A1" or data.get("operation") != name
                or any(data.get(key) != payload[key] for key in ("city", "district", "start", "end"))):
            raise ValueError("返回结果与本次城市、日期或指标不一致。")
        return data

    def summary(self, query, feature):
        data = self.operation(query, "summary")
        data["query"] = query
        return data

    def daily(self, query, data):
        return self.operation(query, "daily")["daily"]

    def history(self, query, data):
        return self.operation(query, "history")["history"]

    def map(self, data, feature, folder):
        if data["summary"]["mean"] is None:
            return None, None, None
        result = self.operation(data["query"], "map")
        encoded = result.get("map_png_base64")
        if not encoded:
            return None, None, None
        if len(encoded) > 6 * 1024 * 1024:
            raise ValueError("温度图文件超过限制。")
        content = base64.b64decode(encoded, validate=True)
        if not content.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("取数服务返回的温度图格式不正确。")
        png = Path(folder) / "city_temperature_map.png"
        png.write_bytes(content)
        preview = png
        with Image.open(BytesIO(content)) as image:
            webp = Path(folder) / "city_temperature_mobile.webp"
            image.save(webp, format="WEBP", quality=80, method=4)
            if webp.stat().st_size < png.stat().st_size:
                preview = webp
        bounds = result["bounds"]
        m = folium.Map(location=[(bounds[0][0] + bounds[1][0]) / 2,
                                 (bounds[0][1] + bounds[1][1]) / 2],
                       tiles="OpenStreetMap", zoom_start=8, control_scale=True)
        m.fit_bounds(bounds)
        folium.raster_layers.ImageOverlay(
            image="data:image/png;base64," + encoded, bounds=bounds,
            name="卫星温度图", opacity=0.82, interactive=True).add_to(m)
        folium.GeoJson(feature, name="查询区域边界", style_function=lambda _: {
            "color": "#07558e", "weight": 2.5, "fillOpacity": 0}).add_to(m)
        LinearColormap(["#" + item for item in PALETTE], vmin=-20, vmax=50,
                       caption="白天地表温度 (°C)").add_to(m)
        folium.LayerControl().add_to(m)
        html = ('<iframe id="temperature-map" title="城市温度地图" allowfullscreen '
                'style="width:100%;height:min(68vh,590px);border:0" srcdoc="'
                + escape(m.get_root().render(), quote=True) + '"></iframe>')
        return html, str(png), str(preview)
