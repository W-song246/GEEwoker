"""研究2：在 Colab 中用智谱对话查询城市白天地表温度。"""

# ===== 沿用原来的智谱客户端和 GEE 会话；新会话使用下面的配置 =====
ZHIPU_API_KEY = ""  # 原笔记本已创建 zhipu_client 时留空；独立运行时可在此放已有 Key。
EE_KEY_PATH = "/content/drive/MyDrive/xusong-gee-99acd5cea33f.json"
# ================================

import calendar
import csv
import json
import math
import os
import re
import tempfile
from datetime import date, datetime, timedelta
from functools import lru_cache
from html import escape
from pathlib import Path
from urllib.request import urlopen
from zoneinfo import ZoneInfo

import ee
import folium
import gradio as gr
import matplotlib.pyplot as plt
import requests
from branca.colormap import LinearColormap
from PIL import Image
from zhipuai import ZhipuAI


DATASET = "MODIS/061/MOD11A1"
MODEL = "glm-4.7-flash"
BOUNDARY_ROOT = "https://raw.githubusercontent.com/junwang23/geoCN/master/geojson/"
ADMIN_ROOT = "https://raw.githubusercontent.com/modood/Administrative-divisions-of-China/master/dist/"
DISTRICT_ROOT = "https://raw.githubusercontent.com/pamaforce/geojson/main/geojson_wgs84/100000/"
VIS = {"min": -20, "max": 50,
       "palette": ["173f96", "53b8e8", "9fe3cb", "ffe68a", "ef754e", "bb2847"]}
MUNICIPALITIES = {"北京": "Beijing", "天津": "Tianjin", "上海": "Shanghai", "重庆": "Chongqing"}
ENGLISH_CITY_NAMES = {
    "beijing": "北京", "tianjin": "天津", "shanghai": "上海", "chongqing": "重庆",
    "hefei": "合肥", "guangzhou": "广州", "shenzhen": "深圳", "wuhan": "武汉",
    "chengdu": "成都", "nanjing": "南京", "hangzhou": "杭州", "xi'an": "西安",
    "xian": "西安", "harbin": "哈尔滨", "sanya": "三亚", "urumqi": "乌鲁木齐",
    "lhasa": "拉萨",
}
MOBILE_MAP_MAX_PIXELS = 720
# geoCN 随项目保存的城市名称快照，供快速解析和页面检索；查询时仍读取相应边界。
SUPPORTED_CITY_NAMES = (
    "七台河", "万宁", "万州区", "万盛区", "三亚", "三明", "三门峡", "上海",
    "上饶", "东丽区", "东城区", "东方", "东莞", "东营", "中卫", "中山",
    "丰台区", "丰都县", "临夏回族自治州", "临汾", "临沂", "临沧", "临高县", "丹东",
    "丽水", "丽江", "乌兰察布", "乌海", "乌鲁木齐", "乐东黎族自治县", "乐山", "九江",
    "九龙坡区", "云浮", "云阳县", "五家渠", "五指山", "亳州", "仙桃", "伊春",
    "伊犁哈萨克自治州", "佛山", "佳木斯", "保亭黎族苗族自治县", "保定", "保山", "信阳", "儋州",
    "克孜勒苏柯尔克孜自治州", "克拉玛依", "六安", "六盘水", "兰州", "兴安盟", "内江", "凉山彝族自治州",
    "包头", "北京", "北海", "北碚区", "北辰区", "十堰", "南京", "南充",
    "南宁", "南岸区", "南川区", "南平", "南开区", "南昌", "南汇区", "南通",
    "南阳", "博尔塔拉蒙古自治州", "卢湾区", "厦门", "双桥区", "双鸭山", "台州", "台湾",
    "合川区", "合肥", "吉安", "吉林", "吐鲁番地区", "吕梁", "吴忠", "周口",
    "呼伦贝尔", "呼和浩特", "和平区", "和田地区", "咸宁", "咸阳", "哈密地区", "哈尔滨",
    "唐山", "商丘", "商洛", "喀什地区", "嘉兴", "嘉定区", "嘉峪关", "四平",
    "固原", "图木舒克", "垫江县", "城口县", "塔城地区", "塘沽区", "大兴区", "大兴安岭地区",
    "大同", "大庆", "大渡口区", "大港区", "大理白族自治州", "大足县", "大连", "天水",
    "天津", "天门", "太原", "奉节县", "奉贤区", "威海", "娄底", "孝感",
    "宁德", "宁河县", "宁波", "安庆", "安康", "安阳", "安顺", "定安县",
    "定西", "宜宾", "宜昌", "宜春", "宝坻区", "宝山区", "宝鸡", "宣城",
    "宣武区", "宿州", "宿迁", "密云县", "屯昌县", "山南地区", "岳阳", "崇左",
    "崇文区", "崇明县", "巢湖", "巫山县", "巫溪县", "巴中", "巴南区", "巴彦淖尔",
    "巴音郭楞蒙古自治州", "常州", "常德", "平凉", "平谷区", "平顶山", "广元", "广安",
    "广州", "庆阳", "廊坊", "延安", "延庆县", "延边朝鲜族自治州", "开县", "开封",
    "张家口", "张家界", "张掖", "彭水苗族土家族自治县", "徐州", "徐汇区", "德宏傣族景颇族自治州", "德州",
    "德阳", "忠县", "忻州", "怀化", "怀柔区", "怒江傈僳族自治州", "恩施土家族苗族自治州", "惠州",
    "成都", "房山区", "扬州", "承德", "抚州", "抚顺", "拉萨", "揭阳",
    "攀枝花", "文山壮族苗族自治州", "文昌", "新乡", "新余", "无锡", "日喀则地区", "日照",
    "昆明", "昌吉回族自治州", "昌平区", "昌江黎族自治县", "昌都地区", "昭通", "晋中", "晋城",
    "普洱", "普陀区", "景德镇", "曲靖", "朔州", "朝阳", "朝阳区", "本溪",
    "来宾", "杨浦区", "杭州", "松原", "松江区", "林芝地区", "果洛藏族自治州", "枣庄",
    "柳州", "株洲", "桂林", "梁平县", "梅州", "梧州", "楚雄彝族自治州", "榆林",
    "武威", "武汉", "武清区", "武隆县", "毕节地区", "永川区", "永州", "汉中",
    "汉沽区", "汕头", "汕尾", "江北区", "江津区", "江门", "池州", "沈阳",
    "沙坪坝区", "沧州", "河东区", "河北区", "河池", "河源", "河西区", "泉州",
    "泰安", "泰州", "泸州", "洛阳", "津南区", "济南", "济宁", "浦东新区",
    "海东地区", "海北藏族自治州", "海南藏族自治州", "海口", "海淀区", "海西蒙古族藏族自治州", "涪陵区", "淄博",
    "淮北", "淮南", "淮安", "深圳", "清远", "渝中区", "渝北区", "温州",
    "渭南", "湖州", "湘潭", "湘西土家族苗族自治州", "湛江", "滁州", "滨州", "漯河",
    "漳州", "潍坊", "潜江", "潮州", "潼南县", "澄迈县", "澳门", "濮阳",
    "烟台", "焦作", "牡丹江", "玉林", "玉树藏族自治州", "玉溪", "珠海", "琼中黎族苗族自治县",
    "琼海", "璧山县", "甘南藏族自治州", "甘孜藏族自治州", "白城", "白山", "白沙黎族自治县", "白银",
    "百色", "益阳", "盐城", "盘锦", "眉山", "石嘴山", "石家庄", "石景山区",
    "石柱土家族自治县", "石河子", "神农架林区", "福州", "秀山土家族苗族自治县", "秦皇岛", "綦江县", "红桥区",
    "红河哈尼族彝族自治州", "绍兴", "绥化", "绵阳", "聊城", "肇庆", "自贡", "舟山",
    "芜湖", "苏州", "茂名", "荆州", "荆门", "荣昌县", "莆田", "莱芜",
    "菏泽", "萍乡", "营口", "葫芦岛", "蓟县", "虹口区", "蚌埠", "衡水",
    "衡阳", "衢州", "襄樊", "西双版纳傣族自治州", "西城区", "西宁", "西安", "西青区",
    "许昌", "贵港", "贵阳", "贺州", "资阳", "赣州", "赤峰", "辽源",
    "辽阳", "达州", "运城", "连云港", "迪庆藏族自治州", "通化", "通州区", "通辽",
    "遂宁", "遵义", "邢台", "那曲地区", "邯郸", "邵阳", "郑州", "郴州",
    "鄂尔多斯", "鄂州", "酉阳土家族苗族自治县", "酒泉", "重庆", "金华", "金山区", "金昌",
    "钦州", "铁岭", "铜仁地区", "铜川", "铜梁县", "铜陵", "银川", "锡林郭勒盟",
    "锦州", "镇江", "长宁区", "长寿区", "长春", "长沙", "长治", "门头沟区",
    "闵行区", "闸北区", "阜新", "阜阳", "防城港", "阳江", "阳泉", "阿克苏地区",
    "阿勒泰地区", "阿坝藏族羌族自治州", "阿拉善盟", "阿拉尔", "阿里地区", "陇南", "陵水黎族自治县", "随州",
    "雅安", "青岛", "青浦区", "静安区", "静海县", "鞍山", "韶关", "顺义区",
    "香港", "马鞍山", "驻马店", "鸡西", "鹤壁", "鹤岗", "鹰潭", "黄冈",
    "黄南藏族自治州", "黄山", "黄浦区", "黄石", "黑河", "黔东南苗族侗族自治州", "黔南布依族苗族自治州", "黔江区",
    "黔西南布依族苗族自治州", "齐齐哈尔", "龙岩",
)
SUPPORTED_CITY_NAMES = tuple(name for name in SUPPORTED_CITY_NAMES
                             if not name.endswith(("区", "县")))

SOURCE_TEXT = (
    "**数据来源**  \n"
    "温度：[NASA MOD11A1 V6.1 白天地表温度](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD11A1)，"
    "通过 Google Earth Engine 读取 `MODIS/061/MOD11A1`，约 1 公里分辨率。  \n"
    "边界：城市使用 [geoCN](https://github.com/junwang23/geoCN)，市辖区使用"
    "[2024 年整理的区界](https://github.com/pamaforce/geojson)；区界由 GCJ-02 转为 WGS84。"
    "这些第三方边界不能当作最新官方行政区划。  \n"
    "智谱 GLM 在配置且可用时用于理解复杂提问和可选文字解读；"
    "**温度数值来自卫星数据，不由 AI 生成**。"
)


@lru_cache(maxsize=2)
def boundary_file(filename):
    url = BOUNDARY_ROOT + filename
    response = requests.get(url, timeout=45)
    response.raise_for_status()
    return response.json()["features"]


def normalize_city(city):
    name = city.strip().removesuffix("市")
    return ENGLISH_CITY_NAMES.get(name.casefold(), name)


def extract_district(text, city=None):
    tail = text
    if city and city in text:
        tail = text.split(city, 1)[1]
    tail = re.sub(r"^(?:市|的|在|内|里|帮我|请|查询|查一下|查|看看|看|问|一下)+", "", tail)
    match = re.search(r"([\u4e00-\u9fff]{2,8}区)", tail)
    return match.group(1) if match else None


def parse_simple_query(user_text, previous):
    """明确的城市和日期直接解析；复杂说法仍交给对话模型。"""
    text = user_text.strip()
    matches = {name for name in SUPPORTED_CITY_NAMES if name in text}
    matches.update(chinese for english, chinese in ENGLISH_CITY_NAMES.items()
                   if re.search(rf"(?<![A-Za-z]){re.escape(english)}(?![A-Za-z])", text, re.I))
    explicit_city = bool(matches)
    if matches:
        longest = max(map(len, matches))
        cities = [name for name in matches if len(name) == longest]
        if len(cities) != 1:
            return None
        city = cities[0]
    else:
        city = previous.get("city")
    if not city:
        return None

    iso_dates = re.findall(r"(?<!\d)(\d{4}-\d{1,2}-\d{1,2})(?!\d)", text)
    if len(iso_dates) in (1, 2):
        try:
            start = date.fromisoformat(iso_dates[0])
            end = date.fromisoformat(iso_dates[-1])
        except ValueError:
            return None
    elif iso_dates:
        return None
    else:
        chinese = re.search(r"(?<!\d)(\d{4})\s*年\s*(1[0-2]|0?[1-9])\s*月"
                            r"(?:\s*(3[01]|[12]\d|0?[1-9])\s*[日号]?)?", text)
        if chinese:
            year, month = int(chinese.group(1)), int(chinese.group(2))
            if len(re.findall(r"\d{1,2}\s*月", text)) > 1:
                return None
            try:
                if chinese.group(3):
                    start = date(year, month, int(chinese.group(3)))
                    rest = text[chinese.end():]
                    following = re.match(r"\s*(?:至|到|~|～|—|-)\s*(\d{1,2})\s*[日号]", rest)
                    if following:
                        end = date(year, month, int(following.group(1)))
                    elif re.match(r"\s*(?:至|到|~|～|—|-)", rest):
                        return None
                    else:
                        end = start
                else:
                    start = date(year, month, 1)
                    end = date(year + month // 12, month % 12 + 1, 1) - timedelta(days=1)
            except ValueError:
                return None
        else:
            months = {word.lower(): i for i in range(1, 13)
                      for word in (calendar.month_name[i], calendar.month_abbr[i])}
            names = "|".join(sorted(map(re.escape, months), key=len, reverse=True))
            english = re.search(rf"\b(?:(\d{{1,2}})\s+)?({names})\s+(\d{{4}})\b", text, re.I)
            if not english:
                return None
            year, month = int(english.group(3)), months[english.group(2).lower()]
            try:
                if english.group(1):
                    start = end = date(year, month, int(english.group(1)))
                else:
                    start = date(year, month, 1)
                    end = date(year + month // 12, month % 12 + 1, 1) - timedelta(days=1)
            except ValueError:
                return None
    district = extract_district(text, city)
    if district is None and not explicit_city:
        district = previous.get("district")
    return {"action": "query", "city": city, "district": district,
            "start": start.isoformat(), "end": end.isoformat(), "reply": ""}


def missing_conditions(text, previous):
    """标准问句缺少地点或时间时先追问，保留已给出的条件。"""
    matches = {name for name in SUPPORTED_CITY_NAMES if name in text}
    matches.update(chinese for english, chinese in ENGLISH_CITY_NAMES.items()
                   if re.search(rf"(?<![A-Za-z]){re.escape(english)}(?![A-Za-z])", text, re.I))
    city = max(matches, key=len) if matches else previous.get("city")
    district = extract_district(text, city)
    if not district and (not matches or (not previous.get("city") and previous.get("district"))):
        district = previous.get("district")
    year_match = re.search(r"(?<!\d)(\d{4})\s*年", text)
    month_match = re.search(r"(?<!\d)(1[0-2]|0?[1-9])\s*月", text)
    year = int(year_match.group(1)) if year_match else previous.get("pending_year")
    month = int(month_match.group(1)) if month_match else previous.get("pending_month")
    dates = parse_simple_query(text, {"city": city or "合肥"})
    if not dates and year and month:
        dates = parse_simple_query(f"{city or '合肥'}{year}年{month}月", {"city": city or "合肥"})
    start = dates.get("start") if dates else previous.get("start")
    end = dates.get("end") if dates else previous.get("end")
    if city and start and end:
        return {"action": "query", "city": city, "district": district,
                "start": start, "end": end, "reply": ""}
    if not city and not start:
        reply = "请问你想查询哪个城市或市辖区、哪一年哪一月？例如“合肥蜀山区2025年9月温度”。"
    elif not city:
        reply = "时间已记下。请问你想查询哪个城市？也可以直接说“合肥蜀山区”。"
    elif month and not year:
        reply = f"已记下{city + (district or '')}的{month}月。请问是哪一年？"
    elif year and not month:
        reply = f"已记下{city + (district or '')}的{year}年。请问是哪一月？"
    else:
        reply = f"已记下{city + (district or '')}。请问要查询哪一年、哪一月或具体哪一天？"
    return {"action": "clarify", "city": city, "district": district,
            "start": start, "end": end, "pending_year": year,
            "pending_month": month, "reply": reply}


@lru_cache(maxsize=1)
def administrative_index():
    cities = requests.get(ADMIN_ROOT + "cities.json", timeout=45)
    areas = requests.get(ADMIN_ROOT + "areas.json", timeout=45)
    cities.raise_for_status()
    areas.raise_for_status()
    return cities.json(), areas.json()


def get_district_feature(city, district):
    if not district.endswith("区"):
        raise ValueError("目前支持市辖区，请写完整区名，例如“蜀山区”。")
    cities, areas = administrative_index()
    if city in MUNICIPALITIES:
        province = {"北京":"11", "天津":"12", "上海":"31", "重庆":"50"}[city]
        codes = {str(item["code"]) for item in cities
                 if str(item["provinceCode"]) == province and item["name"] == "市辖区"}
    else:
        codes = {str(item["code"]) for item in cities
                 if item["name"].removesuffix("市") == city}
    matches = [item for item in areas if str(item["cityCode"]) in codes and item["name"] == district]
    if len(matches) != 1:
        raise ValueError(f"未找到“{city}{district}”的唯一区界，请核对城市与区名。")
    code = str(matches[0]["code"])
    province = code[:2] + "0000"
    parts = [province, code] if code[:2] in {"11", "12", "31", "50"} else [province, code[:4] + "00", code]
    filename = "geojson_wgs84/100000/" + "/".join(parts) + "/" + code + ".json"
    response = requests.get(DISTRICT_ROOT + "/".join(parts) + "/" + code + ".json", timeout=45)
    if response.status_code == 404:
        raise ValueError(f"{city}{district}暂缺可用区界，未返回全市数据。")
    response.raise_for_status()
    features = response.json().get("features", [])
    if len(features) != 1 or str(features[0]["properties"].get("adcode")) != code:
        raise ValueError("区界文件与所选行政区代码不一致。")
    feature = {**features[0], "properties": {**features[0]["properties"], "name": district}}
    return feature, filename


def get_city_feature(city, district=None):
    name = normalize_city(city)
    if district:
        return get_district_feature(name, district)
    if name in MUNICIPALITIES:
        for item in boundary_file("china_provinces.json"):
            if item["properties"]["name"] == MUNICIPALITIES[name]:
                return item, "china_provinces.json"
    matches = [item for item in boundary_file("china_cities.json")
               if item["properties"]["name"].removesuffix("市") == name]
    if len(matches) == 1:
        return matches[0], "china_cities.json"
    if len(matches) > 1:
        raise ValueError(f"找到多个名为{name}的边界，请写完整城市名称。")
    raise ValueError(f"geoCN 没有找到“{city}”的城市边界；请使用地级市或直辖市名称。")


def ai_json(client, user_text, previous, history):
    today = datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
    rules = (
        "你是城市地表温度查询的中文对话助手。只解析用户的问题，不编造温度或声称已经查询。"
        "只输出一个 JSON 对象，字段必须为 action、city、district、start、end、reply。"
        "action 只能为 query 或 clarify；city 用中文城市名；district 为用户指定的区县名，未指定填 null。"
        "接受中文和英文提问，把英文城市名译成中文，例如 Hefei→合肥、Beijing→北京；"
        "'temperature in Hefei on 8 September 2026' 应识别为合肥 2026-09-08 的单日查询。"
        "start/end 是 YYYY-MM-DD；单日两者相同；整月填该月首日和末日；时间段填起止日。"
        "缺少年份、月份或日期且历史条件也没有时，必须 clarify，不要猜当前年份或月份。"
        "没说城市且历史条件也没有时，应 clarify 并在 reply 询问城市。"
        "后续追问可以参考上一轮条件；用户提到区县时务必填 district，不要把区县冒充全市。"
        f"今天是 {today}。上一轮条件：{json.dumps(previous, ensure_ascii=False)}。"
    )
    messages = [{"role": "system", "content": rules}]
    messages += [{"role": item["role"], "content": str(item["content"])[:500]}
                 for item in (history or [])[-4:] if item.get("role") in ("user", "assistant")]
    messages.append({"role": "user", "content": user_text})
    response = client.chat.completions.create(
        model=MODEL, temperature=0.1,
        messages=messages,
    )
    raw = response.choices[0].message.content.strip()
    try:
        data = json.loads(raw[raw.index("{"):raw.rindex("}") + 1])
    except (ValueError, json.JSONDecodeError):
        raise ValueError("智谱本次没有返回可识别的查询条件，请换一种说法重试。")
    return data


def validate_query(parsed, previous):
    if parsed.get("action") == "clarify":
        return None, str(parsed.get("reply") or "请补充城市和日期。")
    if parsed.get("action") != "query":
        raise ValueError("智谱没有识别到查询请求，请写明城市和日期。")
    city = normalize_city(str(parsed.get("city") or previous.get("city") or ""))
    if not city:
        return None, "请问要查询哪个城市？如果是市辖区，也请写出所属城市。"
    if city.endswith(("区", "县")):
        return None, "请补充所属城市，例如“合肥蜀山区”。"
    district_value = parsed.get("district")
    if "district" not in parsed and city == previous.get("city"):
        district_value = previous.get("district")
    district = str(district_value or "").strip() or None
    if district and not district.endswith("区"):
        raise ValueError("目前只支持市辖区查询，请输入完整区名。")
    try:
        start = date.fromisoformat(str(parsed["start"]))
        end = date.fromisoformat(str(parsed["end"]))
    except (KeyError, TypeError, ValueError):
        return None, f"已记下{city + (district or '')}。请问要查询哪一年、哪一月或具体哪一天？"
    if end < start:
        raise ValueError("结束日期不能早于开始日期。")
    if (end - start).days > 92:
        raise ValueError("一次最多查询 93 天，请缩短时间段。")
    if start < date(2000, 2, 24):
        raise ValueError("MOD11A1 数据从 2000 年 2 月开始，请选择之后的日期。")
    return {"city": city, "district": district, "start": start, "end": end}, None


def prepare(image):
    qa = image.select("QC_Day")
    good = qa.bitwiseAnd(3).eq(0).And(qa.rightShift(6).bitwiseAnd(3).lte(1))
    return (image.select("LST_Day_1km").multiply(0.02).subtract(273.15)
            .rename("LST_C").updateMask(good)
            .copyProperties(image, ["system:time_start"]))


def images(start, end, geometry):
    return (ee.ImageCollection(DATASET)
            .filterDate(start.isoformat(), (end + timedelta(days=1)).isoformat())
            .filterBounds(geometry).map(prepare).sort("system:time_start"))


def stats_from(raw, total):
    raw = raw or {}
    count = int(raw.get("LST_C_count") or 0)
    return {"count": count, "coverage": round(100 * count / total, 1) if total else 0,
            **{name: float(raw["LST_C_" + name]) if count and raw.get("LST_C_" + name) is not None else None
               for name in ("min", "mean", "max")}}


def reduce_stats(image, geometry, projection):
    reducer = (ee.Reducer.mean().combine(ee.Reducer.minMax(), sharedInputs=True)
               .combine(ee.Reducer.count(), sharedInputs=True))
    return image.reduceRegion(reducer=reducer, geometry=geometry, crs=projection,
                              scale=1000, maxPixels=1e9, tileScale=4)


def daily_stats(collection, start, end, geometry, projection, total):
    def attach(image):
        raw = reduce_stats(image, geometry, projection)
        return image.set("daily", ee.Dictionary({
            "date": image.date().format("YYYY-MM-dd"),
            "LST_C_min": raw.get("LST_C_min"),
            "LST_C_mean": raw.get("LST_C_mean"),
            "LST_C_max": raw.get("LST_C_max"),
            "LST_C_count": raw.get("LST_C_count"),
        }))
    received = collection.map(attach).aggregate_array("daily").getInfo() or []
    found = {item["date"]: item for item in received}
    rows = []
    for i in range((end - start).days + 1):
        day = (start + timedelta(days=i)).isoformat()
        rows.append({"date": day, **stats_from(found.get(day), total)})
    return rows


def same_date_history(query, geometry, projection, total):
    start, end = query["start"], query["end"]
    items = []
    for year in range(start.year - 9, start.year + 1):
        try:
            old_start = start.replace(year=year)
            old_end = end.replace(year=year + end.year - start.year)
        except ValueError:  # 例如 2 月 29 日在平年没有对应日期
            items.append({"year": year, **stats_from({}, total)})
            continue
        if old_start < date(2000, 2, 24) or old_start > datetime.now(ZoneInfo("Asia/Shanghai")).date():
            items.append({"year": year, **stats_from({}, total)})
            continue
        collection = images(old_start, old_end, geometry)
        empty = ee.Image.constant(0).rename("LST_C").updateMask(ee.Image.constant(0))
        composite = ee.Image(ee.Algorithms.If(collection.size().gt(0), collection.mean(), empty))
        raw = reduce_stats(composite, geometry, projection)
        items.append(ee.Dictionary({"year": year,
                                    "LST_C_mean": raw.get("LST_C_mean"),
                                    "LST_C_count": raw.get("LST_C_count")}))
    # 一次请求回收历年结果，避免十次网络往返。
    received = ee.List([item for item in items if not isinstance(item, dict)]).getInfo() or []
    lookup = {int(item["year"]): stats_from(item, total) for item in received}
    return [{"year": year, **lookup.get(year, stats_from({}, total))}
            for year in range(start.year - 9, start.year + 1)]


def query_earth_engine(query, feature, include_daily=True, include_history=True):
    geometry = ee.Geometry(feature["geometry"])
    projection = ee.ImageCollection(DATASET).first().select("LST_Day_1km").projection()
    denominator = ee.Image.constant(1).rename("n").reduceRegion(
        reducer=ee.Reducer.count(), geometry=geometry, crs=projection,
        scale=1000, maxPixels=1e9, tileScale=4).getInfo()
    total = int(denominator.get("n") or 0)
    if not total:
        raise ValueError("该城市边界在卫星 1 公里网格上没有有效范围。")
    collection = images(query["start"], query["end"], geometry)
    image_count = int(collection.size().getInfo())
    if image_count:
        composite = collection.mean().clip(geometry)
        summary = stats_from(reduce_stats(composite, geometry, projection).getInfo(), total)
    else:
        composite = None
        summary = stats_from({}, total)
    if query["start"] == query["end"]:
        # 单日汇总已经包含当天的统计，避免重复提交一次 Earth Engine 逐日任务。
        daily = [{"date": query["start"].isoformat(), **summary}]
    elif include_daily:
        daily = daily_stats(collection, query["start"], query["end"], geometry, projection, total)
    else:
        daily = []
    history = same_date_history(query, geometry, projection, total) if include_history else []
    return {"geometry": geometry, "image": composite, "summary": summary,
            "daily": daily, "history": history, "image_count": image_count,
            "projection": projection, "total": total, "collection": collection}


def save_figure(fig, folder, name):
    path = os.path.join(folder, name + ".png")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def bar_chart(stats, folder):
    if stats["mean"] is None:
        return None
    values = [stats[k] for k in ("min", "mean", "max")]
    fig, ax = plt.subplots(figsize=(7, 4))
    bars = ax.bar(["Spatial min", "Spatial mean", "Spatial max"], values,
                  color=["#8bd5ed", "#31a9df", "#087eb9"], width=0.55)
    for bar, value in zip(bars, values):
        ax.annotate(f"{value:.2f} °C", (bar.get_x() + bar.get_width() / 2, value),
                    xytext=(0, 5 if value >= 0 else -18), textcoords="offset points", ha="center")
    ax.set_ylim(min(0, min(values)) - 2, max(0, max(values)) + 4)
    ax.set_ylabel("Daytime land surface temperature (°C)")
    ax.grid(axis="y", alpha=0.2)
    return save_figure(fig, folder, "day_min_mean_max")


def line_chart(rows, xkey, title, folder, name):
    xs = [row[xkey] for row in rows]
    ys = [row["mean"] if row["mean"] is not None else math.nan for row in rows]
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(xs, ys, marker="o", markersize=4, color="#168bcb", linewidth=1.7)
    weak = [row for row in rows if row["mean"] is not None and row["coverage"] < 20]
    if weak:
        ax.scatter([row[xkey] for row in weak], [row["mean"] for row in weak],
                   color="#f39730", s=45, zorder=3, label="Coverage < 20%")
        ax.legend()
    if xkey == "year":
        ax.set_xticks(xs)
    else:
        step = max(1, len(xs) // 8)
        ax.set_xticks(xs[::step])
    ax.tick_params(axis="x", rotation=45)
    ax.set_title(title)
    ax.set_ylabel("City daytime LST (°C)")
    ax.grid(alpha=0.25)
    return save_figure(fig, folder, name)


def coordinate_bounds(geometry):
    points = []
    def walk(node):
        if isinstance(node, list) and len(node) >= 2 and all(isinstance(v, (int, float)) for v in node[:2]):
            points.append((node[0], node[1]))
        elif isinstance(node, list):
            for child in node:
                walk(child)
    walk(geometry["coordinates"])
    return min(p[0] for p in points), min(p[1] for p in points), max(p[0] for p in points), max(p[1] for p in points)


def make_map(data, feature, folder):
    if data["image"] is None or data["summary"]["mean"] is None:
        return None, None, None
    west, south, east, north = coordinate_bounds(feature["geometry"])
    m = folium.Map(location=[(south + north) / 2, (west + east) / 2],
                   tiles="OpenStreetMap", zoom_start=8, control_scale=True)
    m.fit_bounds([[south, west], [north, east]])
    layer_url = data["image"].getMapId(VIS)["tile_fetcher"].url_format
    folium.TileLayer(tiles=layer_url, attr="NASA MODIS / Google Earth Engine",
                     name="白天地表温度", overlay=True, opacity=0.8).add_to(m)
    folium.GeoJson(feature, name="查询区域边界", style_function=lambda _: {
        "color": "#07558e", "weight": 2.5, "fillOpacity": 0}).add_to(m)
    LinearColormap(["#" + c for c in VIS["palette"]], vmin=-20, vmax=50,
                   caption="白天地表温度 (°C)").add_to(m)
    folium.LayerControl().add_to(m)
    html = ('<iframe id="temperature-map" title="城市温度地图" allowfullscreen loading="lazy" '
            'style="width:100%;height:min(68vh,590px);border:0" srcdoc="'
            + escape(m.get_root().render(), quote=True) + '"></iframe>')
    png_path = os.path.join(folder, "city_temperature_map.png")
    preview_path = None
    try:
        url = data["image"].getThumbURL({**VIS, "region": data["geometry"].bounds(),
                                          "dimensions": MOBILE_MAP_MAX_PIXELS, "format": "png"})
        with urlopen(url, timeout=90) as response, open(png_path, "wb") as file:
            file.write(response.read())
    except Exception:
        png_path = None  # 交互地图仍能显示；单独的 PNG 下载可能临时失败。
    if png_path:
        preview_path = png_path
        webp_path = os.path.join(folder, "city_temperature_mobile.webp")
        try:
            with Image.open(png_path) as image:
                image.save(webp_path, format="WEBP", quality=80, method=4)
            if os.path.getsize(webp_path) < os.path.getsize(png_path):
                preview_path = webp_path
        except Exception:
            pass  # WebP 不可用时，手机仍可查看较小的 PNG。
    return html, png_path, preview_path


def save_csv(rows, folder):
    path = os.path.join(folder, "daily_temperature.csv")
    with open(path, "w", encoding="utf-8-sig", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["日期", "城市空间最低℃", "城市空间均温℃", "城市空间最高℃", "有效像元", "覆盖率%"])
        for row in rows:
            writer.writerow([row["date"], row["min"], row["mean"], row["max"],
                             row["count"], row["coverage"]])
    return path


def number(value):
    return "缺测" if value is None else f"{value:.2f} ℃"


def source_for(filename):
    return SOURCE_TEXT + f"  \n本次边界文件：`{filename}`。"


def ai_explanation(client, query, data):
    if client is None:
        return None, "未配置智谱客户端；卫星数据与图表仍可正常查询。"
    stats = data["summary"]
    facts = {"city": query["city"], "district": query.get("district"),
             "start": query["start"].isoformat(),
             "end": query["end"].isoformat(), "spatial_temperature_c": {
                 key: stats[key] for key in ("min", "mean", "max")},
             "valid_pixel_coverage_pct": stats["coverage"],
             "valid_days": (sum(row["count"] > 0 for row in data["daily"])
                            if data["daily"] else None),
             "requested_days": (query["end"] - query["start"]).days + 1}
    try:
        response = client.chat.completions.create(
            model=MODEL, temperature=0.1,
            messages=[{"role": "system", "content": (
                "根据下列真实卫星统计，用中文作不超过两句的简短解读。"
                "只能引用给出的数值；缺测不能当作 0；低覆盖率时提醒谨慎。"
                "不得称为气温、24小时最高最低温、天气预报或证明热岛成因。")},
                {"role": "user", "content": json.dumps(facts, ensure_ascii=False)}])
        content = response.choices[0].message.content
        if not content or not content.strip():
            return None, "智谱未返回文字说明；卫星数据与图表不受影响。"
        return content.strip(), None
    except Exception as error:
        if "429" in str(error) or type(error).__name__ == "APIReachLimitError":
            return None, "智谱当前模型限流（429）；稍后可单独重试文字解读。卫星数据不受影响。"
        return None, f"智谱文字解读失败（{type(error).__name__}）；卫星数据不受影响。"


def result_markdown(query, data, boundary_name, explanation):
    stats = data["summary"]
    window = (query["start"].isoformat() if query["start"] == query["end"] else
              f"{query['start'].isoformat()} 至 {query['end'].isoformat()}")
    days_text = (f"有值日期 {sum(row['count'] > 0 for row in data['daily'])}/{len(data['daily'])} 天"
                 if data["daily"] else "逐日有效天数正在统计")
    place = query["city"] + (query.get("district") or "")
    body = (f"### {place} · {window}\n"
            f"区域内白天地表温度：**最低 {number(stats['min'])} · 平均 {number(stats['mean'])} · 最高 {number(stats['max'])}**。  \n"
            f"有效像元 {stats['count']} 个，空间覆盖率 {stats['coverage']:.1f}%；"
            f"{days_text}。  \n"
            "这里的最高/最低是**卫星过境时有效像元的空间极值**，不是一天的最高/最低气温。")
    if query["start"] != query["end"]:
        body += " 时段统计基于各日有效影像的像元均值。"
    if stats["mean"] is None:
        body += "  \n**这段时间没有可用的有效温度像元。**"
    elif stats["coverage"] < 20:
        body += "  \n**覆盖率低于 20%，请谨慎解读。**"
    if explanation:
        body += f"\n\n**智谱解读：** {explanation}"
    return body + "\n\n" + source_for(boundary_name)


def public_error(error):
    if "429" in str(error) or type(error).__name__ == "APIReachLimitError":
        return ("智谱当前模型访问量过大（429）。明确的城市与日期仍可直接查询，"
                "例如“合肥2025年7月温度”；复杂说法请稍后再试。")
    if isinstance(error, ValueError):
        return str(error)
    return f"查询未完成（{type(error).__name__}）。请稍后重试，卫星和边界服务有时响应较慢。"


class DirectEarthEngineBackend:
    """Colab 中继续直接访问 GEE；服务器部署可以换成远程取数。"""

    def boundary(self, city, district=None):
        return get_city_feature(city, district)

    def summary(self, query, feature):
        return query_earth_engine(query, feature, include_daily=False, include_history=False)

    def daily(self, query, data):
        return daily_stats(data["collection"], query["start"], query["end"],
                           data["geometry"], data["projection"], data["total"])

    def history(self, query, data):
        return same_date_history(query, data["geometry"], data["projection"], data["total"])

    def map(self, data, feature, folder):
        return make_map(data, feature, folder)


def make_interface(client, backend=None):
    backend = backend or DirectEarthEngineBackend()
    with gr.Blocks(title="AI 城市温度可视化") as app:
        gr.Markdown("# 城市温度可视化\n可查询城市或市辖区的卫星地表温度；复杂说法可交给智谱理解。")
        chat = gr.Chatbot(label="查询记录", height=300)
        with gr.Row():
            question = gr.Textbox(label="你的问题", placeholder="合肥2026年9月8日温度；或 Hefei temperature on 8 September 2026")
            ask = gr.Button("查询并画图", variant="primary")
        gr.Markdown("中文、英文都可以提问。标准格式如“北京市2026年7月温度”；结果会分步出现。")
        with gr.Accordion(f"可查询城市（当前名称快照 {len(SUPPORTED_CITY_NAMES)} 个）", open=False):
            gr.Dropdown(choices=SUPPORTED_CITY_NAMES, label="输入城市名检索；这里只查看名单，不会自动查询")
            gr.Markdown("包括北京、天津、上海、重庆、合肥等；区级查询需写明城市和区，例如“合肥蜀山区”。")
        state = gr.State({})
        result = gr.Markdown("输入城市和日期后查询。\n\n" + SOURCE_TEXT)
        explain_button = gr.Button("可选：让智谱解读本次数据", size="sm")
        with gr.Column(visible=False) as day_panel:
            gr.Markdown("### 单日图表")
            with gr.Row():
                bars = gr.Image(label="当日空间最低、均温、最高", interactive=False,
                                buttons=["fullscreen", "download"])
                day_history = gr.Image(label="近十年同日城市均温", interactive=False,
                                       buttons=["fullscreen", "download"])
        with gr.Column(visible=False) as period_panel:
            gr.Markdown("### 整月或时间段图表")
            map_preview = gr.Image(label="卫星温度图", interactive=False,
                                   buttons=["fullscreen", "download"])
            with gr.Accordion("可缩放的交互地图", open=True):
                fullscreen_map = gr.Button("⛶ 全屏地图", size="sm")
                map_view = gr.HTML()
            with gr.Row():
                map_download = gr.DownloadButton("下载地图 PNG", size="sm")
            with gr.Row():
                daily_plot = gr.Image(label="逐日城市均温", interactive=False,
                                      buttons=["fullscreen", "download"])
                period_history = gr.Image(label="近十年同一日历时段城市均温", interactive=False,
                                          buttons=["fullscreen", "download"])
            table = gr.Dataframe(headers=["日期", "空间最低℃", "均温℃", "空间最高℃", "有效像元", "覆盖率%"],
                                 interactive=False, label="逐日明细")
            csv_download = gr.DownloadButton("下载逐日 CSV")

        outputs = [chat, result, day_panel, bars, day_history, period_panel,
                   map_preview, map_view, map_download, daily_plot, period_history,
                   table, csv_download, state]

        def empty_reply(history, user_text, message, state):
            history = list(history or []) + [{"role": "user", "content": user_text},
                                              {"role": "assistant", "content": message}]
            state = dict(state or {})
            for key in ("last_query", "last_data", "base_result"):
                state.pop(key, None)
            return (history, message + "\n\n" + SOURCE_TEXT,
                    gr.update(visible=False), None, None, gr.update(visible=False),
                    None, None, None, None, None, [], None, state)

        def run(question_text, history, previous):
            previous = previous or {}
            text = (question_text or "").strip()
            if not text:
                yield empty_reply(history, "", "请先输入一个问题，例如“合肥2026年9月8日温度”。", previous)
                return
            pending = list(history or []) + [
                {"role": "user", "content": text},
                {"role": "assistant", "content": "正在读取城市边界与卫星温度；文字和图表会分步出现。"}]
            yield (pending, "正在查询卫星数据，请稍候。\n\n" + SOURCE_TEXT,
                   gr.update(visible=False), None, None, gr.update(visible=False),
                   None, None, None, None, None, [], None, previous)
            try:
                parsed = parse_simple_query(text, previous)
                if parsed is None:
                    if client is not None and re.search(r"今年|去年|明年|本月|上月|下月|最近|过去|前天|昨天|今天|明天|上周|下周|对比|比较", text):
                        parsed = ai_json(client, text, previous, history)
                    else:
                        parsed = missing_conditions(text, previous)
                query, ask_more = validate_query(parsed, previous)
                if ask_more:
                    partial = dict(previous)
                    for key in ("city", "district", "start", "end", "pending_year", "pending_month"):
                        if parsed.get(key) is not None:
                            partial[key] = parsed[key]
                    yield empty_reply(history, text, ask_more, partial)
                    return
                feature, boundary_name = backend.boundary(query["city"], query.get("district"))
                data = backend.summary(query, feature)
                folder = tempfile.mkdtemp(prefix="city_lst_")
                summary = result_markdown(query, data, boundary_name, None)
                place = query["city"] + (query.get("district") or "")
                reply = (f"已查询 {place} {query['start']} 至 {query['end']}。"
                         f" 区域均温：{number(data['summary']['mean'])}。图表正在继续生成。")
                updated_history = list(history or []) + [
                    {"role": "user", "content": text}, {"role": "assistant", "content": reply}]
                next_state = {"city": query["city"], "district": query.get("district"),
                              "start": query["start"].isoformat(),
                              "end": query["end"].isoformat(), "last_data": {
                                  "summary": data["summary"], "daily": data["daily"]},
                              "base_result": summary}
                if query["start"] == query["end"]:
                    bars_path = bar_chart(data["summary"], folder)
                    current = [updated_history, summary, gr.update(visible=True), bars_path, None,
                               gr.update(visible=False), None, None, None, None, None, [], None, next_state]
                else:
                    current = [updated_history, summary, gr.update(visible=False), None, None,
                               gr.update(visible=True), None, None, None, None, None,
                               [], None, next_state]
                yield tuple(current)  # 先显示城市均温，不等待逐日、十年图和地图。

                if query["start"] != query["end"]:
                    try:
                        data["daily"] = backend.daily(query, data)
                        current[9] = line_chart(data["daily"], "date", "Daily city mean daytime LST",
                                                folder, "daily_mean")
                        current[12] = save_csv(data["daily"], folder)
                        current[11] = [[r["date"], "缺测" if r["min"] is None else round(r["min"], 2),
                                        "缺测" if r["mean"] is None else round(r["mean"], 2),
                                        "缺测" if r["max"] is None else round(r["max"], 2),
                                        r["count"], r["coverage"]] for r in data["daily"]]
                        current[1] = result_markdown(query, data, boundary_name, None)
                        next_state["last_data"]["daily"] = data["daily"]
                        next_state["base_result"] = current[1]
                        current[0] = updated_history[:-1] + [{
                            "role": "assistant", "content": "城市均温和逐日数据已显示，正在生成对比图与地图。"}]
                        yield tuple(current)
                    except Exception as error:
                        current[1] += f"\n\n逐日图表暂未生成（{type(error).__name__}）；城市均温仍可使用。"
                        next_state["base_result"] = current[1]
                        yield tuple(current)

                try:
                    history_data = backend.history(query, data)
                    history_plot = line_chart(history_data, "year", "Same calendar date/window by year",
                                              folder, "ten_year_history")
                    current[4 if query["start"] == query["end"] else 10] = history_plot
                    current[0] = updated_history[:-1] + [{
                        "role": "assistant", "content": (
                            "城市统计和近十年图已完成。" if query["start"] == query["end"]
                            else "城市统计与近十年图已完成，正在生成温度地图。") }]
                    yield tuple(current)
                except Exception as error:
                    current[1] += f"\n\n近十年对比图暂未生成（{type(error).__name__}）；已显示的卫星统计仍可使用。"
                    current[0] = updated_history[:-1] + [{
                        "role": "assistant", "content": (
                            "城市统计已完成，近十年图未生成。" if query["start"] == query["end"]
                            else "城市统计已完成，近十年图未生成；正在生成温度地图。") }]
                    yield tuple(current)

                if query["start"] != query["end"]:
                    try:
                        html, png, preview = backend.map(data, feature, folder)
                        current[6], current[7], current[8] = preview, html, png
                        if html and not png:
                            current[1] += "\n\n地图轻量图暂未生成；交互地图仍可查看。"
                        current[0] = updated_history[:-1] + [{
                            "role": "assistant", "content": "本次城市温度查询已完成；请查看下方图表。"}]
                        yield tuple(current)
                    except Exception as error:
                        current[1] += f"\n\n温度地图暂未生成（{type(error).__name__}）；其他图表仍可使用。"
                        current[0] = updated_history[:-1] + [{
                            "role": "assistant", "content": "城市统计已完成，温度地图未生成。"}]
                        yield tuple(current)
            except Exception as error:
                yield empty_reply(history, text, public_error(error), previous)

        def explain(history, state):
            state = state or {}
            data = state.get("last_data")
            if not data:
                return history, "请先完成一次卫星温度查询。\n\n" + SOURCE_TEXT
            query = {"city": state["city"], "district": state.get("district"),
                     "start": date.fromisoformat(state["start"]),
                     "end": date.fromisoformat(state["end"])}
            explanation, warning = ai_explanation(client, query, data)
            message = explanation or warning
            updated_history = list(history or []) + [{"role": "assistant", "content": message}]
            result_text = state["base_result"] + (f"\n\n**智谱解读：** {explanation}" if explanation
                                                  else f"\n\n**说明：** {warning}")
            return updated_history, result_text

        ask.click(run, inputs=[question, chat, state], outputs=outputs, concurrency_limit=1)
        explain_button.click(explain, inputs=[chat, state], outputs=[chat, result], concurrency_limit=1)
        fullscreen_map.click(fn=None, js="""() => {
            const frame = document.getElementById('temperature-map');
            if (frame && frame.requestFullscreen) frame.requestFullscreen();
        }""")
    return app


def initialize_earth_engine_from_json(key_path):
    path = Path(key_path)
    if str(path).startswith("/content/drive/"):
        from google.colab import drive
        drive.mount("/content/drive", force_remount=False)
    if not path.is_file():
        raise FileNotFoundError(
            f"找不到 GEE 密钥文件：{path}。请将 JSON 放到 Google Drive 的 MyDrive 根目录，"
            "或修改代码开头的 EE_KEY_PATH。")
    info = json.loads(path.read_text(encoding="utf-8"))
    email, project = info.get("client_email"), info.get("project_id")
    if not email or not project:
        raise ValueError("GEE JSON 缺少 client_email 或 project_id，请确认它是服务账号密钥文件。")
    credentials = ee.ServiceAccountCredentials(email, str(path))
    ee.Initialize(credentials, project=project)
    return project


def resolve_zhipu_client():
    existing = globals().get("zhipu_client")
    if existing is not None:
        return existing
    key = ZHIPU_API_KEY.strip() or os.getenv("ZHIPU_API_KEY", "").strip()
    if not key:
        try:
            from google.colab import userdata
            key = (userdata.get("ZHIPU_API_KEY") or "").strip()
        except Exception:
            pass
    if not key:
        return None  # 标准城市日期查询无需 AI，也不要求用户输入 Key。
    return ZhipuAI(api_key=key)


def main():
    print("研究2：标准问法直接解析；复杂问法可由智谱理解；温度来自 NASA MODIS，边界来自 geoCN。")
    client = resolve_zhipu_client()
    if client is None:
        print("未配置智谱客户端：标准城市日期查询仍可使用，AI 解读暂不可用。")
    if ee.data.is_initialized():
        print("沿用当前 Colab 会话中已初始化的 Earth Engine。")
    else:
        project = initialize_earth_engine_from_json(EE_KEY_PATH)
        print(f"Earth Engine 已用云盘 JSON 初始化，项目：{project}")
    app = make_interface(client)
    app.queue(default_concurrency_limit=1, max_size=8).launch(
        share=True, ssr_mode=False, show_error=False)


if __name__ == "__main__":
    main()
