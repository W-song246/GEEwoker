"""只读取旧站的三个连接设置，生成新版自己的配置，不修改旧站。"""

import json
import os
import tempfile
from pathlib import Path

from dotenv import dotenv_values


def configure(folder, old_path=Path("/home/ubuntu/temperature-platform/platform.env")):
    folder = Path(folder)
    path = folder / "server.env"
    old = dict(dotenv_values(old_path)) if old_path.is_file() else {}
    saved = dict(dotenv_values(path)) if path.is_file() else {}
    config = {
        "GEE_WORKER_URL": saved.get("GEE_WORKER_URL") or old.get("GEE_WORKER_URL") or "https://geewoker.onrender.com",
        "WORKER_TOKEN": saved.get("WORKER_TOKEN") or old.get("WORKER_TOKEN") or "",
        "ZHIPU_API_KEY": saved.get("ZHIPU_API_KEY") or old.get("ZHIPU_API_KEY") or "",
        # 新页面所用模型与 Colab 相同，不沿用旧站可能已过时的型号。
        "ZHIPU_MODEL": saved.get("ZHIPU_MODEL") or "glm-4.7-flash",
        "PORT": "7861",
        "GRADIO_ANALYTICS_ENABLED": "False",
    }
    descriptor, temporary = tempfile.mkstemp(prefix=".settings_", dir=folder)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as file:
            file.write("".join(f"{key}={json.dumps(value, ensure_ascii=False)}\n"
                               for key, value in config.items()))
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print("新版配置已保存；原站点配置未修改。")
    print("取数口令：" + ("已沿用" if config["WORKER_TOKEN"] else "缺少，请编辑 server.env"))
    print("智谱 Key：" + ("已沿用" if config["ZHIPU_API_KEY"] else "原站未配置，请在 server.env 填写"))
    return config


if __name__ == "__main__":
    configure(Path(__file__).resolve().parent)
