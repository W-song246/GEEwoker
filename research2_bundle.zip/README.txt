研究2独立网页部署说明

目录：/home/ubuntu/research2-city
端口：7861
服务名称：research2-city
页面和所有图表与当前 Colab 版共用 Python 源码，GEE 计算通过 Render 执行。
原站 /home/ubuntu/temperature-platform、原服务和 Nginx 配置均保留。

先确认 Render 的 /health capabilities 包含 city-boundary-temperature-v1。
在服务器 ubuntu 用户终端运行安装脚本即可创建新版环境和开机服务。
如果腾讯云防火墙未放行，需要在控制台添加 TCP 7861 入站规则。
网页无需账户密码，网址为 http://服务器公网IP:7861。

安装时自动复制旧 platform.env 中的 GEE_WORKER_URL、WORKER_TOKEN、ZHIPU_API_KEY。
不会读取、修改或打印旧站点的网页登录密码；不会修改原取数接口。
若智谱 Key 原来为空，用 nano /home/ubuntu/research2-city/server.env 填入一次，
然后 sudo systemctl restart research2-city；Key 不要发在聊天或公开仓库里。
GEE 服务账号 JSON 继续保存在 Render；国内服务器不需要复制该文件。

查看运行状态：sudo systemctl status research2-city --no-pager
查看最近日志：sudo journalctl -u research2-city -n 30 --no-pager
重启新版：sudo systemctl restart research2-city
停止新版：sudo systemctl stop research2-city
原网页的服务名是 temperature-platform，请不要停止这个原服务。

图像和查询结果仍在本次会话内保留，不是永久数据档案。
服务器试用到期后需要续费或迁移；Render 休眠后的首次取数可能较慢。
